import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Marker } from '@maplibre/maplibre-react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS } from '../../constants/colors';
import { toLngLat } from '../../utils/geo';

/**
 * Marqueur de carte pour maraude ou signalement.
 * - Maraude : vert, icône "walk"
 * - Signalement : rouge, icône "alert"
 */
export function EventMarker({ event, type, onPress }) {
  const isMaraude = type === 'maraude';
  const color = isMaraude ? COLORS.markerMaraude : COLORS.markerSignalement;
  const icon = isMaraude ? 'walk' : 'alert';

  return (
    <Marker
      lngLat={toLngLat(event.latitude, event.longitude)}
      onPress={onPress}
      id={`${type}-${event.id}`}
    >
      <View accessibilityLabel={`${isMaraude ? 'Maraude' : 'Signalement'} : ${event.titre}`}>
        <View style={[styles.marker, { backgroundColor: color }]}>
          <MaterialCommunityIcons name={icon} size={18} color="#FFFFFF" />
        </View>
        <View style={[styles.pointer, { borderTopColor: color }]} />
      </View>
    </Marker>
  );
}

const styles = StyleSheet.create({
  marker: {
    width: 34,
    height: 34,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  pointer: {
    alignSelf: 'center',
    width: 0,
    height: 0,
    borderLeftWidth: 6,
    borderRightWidth: 6,
    borderTopWidth: 8,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    marginTop: -1,
  },
});