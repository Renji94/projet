import React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Chip, Text } from 'react-native-paper';
import { COLORS } from '../../constants/colors';
import { URGENCES } from '../../constants/enums';
import { CONFIG } from '../../constants/config';
import { SPACING, RADIUS } from '../../styles/theme';

/**
 * Panneau de filtres de la carte :
 * - type d'événement (maraudes / signalements)
 * - urgence
 * - rayon de distance
 */
export function MapFilters({ filters, onChange }) {
  const toggleType = (type) => {
    onChange({ ...filters, [type]: !filters[type] });
  };

  const setUrgence = (urgence) => {
    onChange({ ...filters, urgence: filters.urgence === urgence ? null : urgence });
  };

  const setRayon = (rayon) => {
    onChange({ ...filters, rayonKm: rayon });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Type</Text>
      <View style={styles.row}>
        <Chip
          icon="walk"
          selected={filters.showMaraudes}
          onPress={() => toggleType('showMaraudes')}
          style={[styles.chip, filters.showMaraudes && styles.chipSelected]}
        >
          Maraudes
        </Chip>
        <Chip
          icon="alert"
          selected={filters.showSignalements}
          onPress={() => toggleType('showSignalements')}
          style={[styles.chip, filters.showSignalements && styles.chipSelected]}
        >
          Signalements
        </Chip>
      </View>

      <Text style={styles.label}>Urgence</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View style={styles.row}>
          {Object.entries(URGENCES).map(([key, config]) => (
            <Chip
              key={key}
              selected={filters.urgence === key}
              onPress={() => setUrgence(key)}
              style={[
                styles.chip,
                filters.urgence === key && { backgroundColor: config.color },
              ]}
              textStyle={filters.urgence === key ? styles.textWhite : undefined}
            >
              {config.label}
            </Chip>
          ))}
        </View>
      </ScrollView>

      <Text style={styles.label}>Distance</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View style={styles.row}>
          {CONFIG.RADIUS_OPTIONS.map((rayon) => (
            <Chip
              key={rayon}
              selected={filters.rayonKm === rayon}
              onPress={() => setRayon(rayon)}
              style={[styles.chip, filters.rayonKm === rayon && styles.chipSelected]}
            >
              {rayon} km
            </Chip>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
  },
  label: {
    fontWeight: '600',
    color: COLORS.text,
    marginTop: SPACING.sm,
    marginBottom: SPACING.xs,
    fontSize: 13,
  },
  row: {
    flexDirection: 'row',
    gap: SPACING.sm,
    flexWrap: 'wrap',
  },
  chip: {
    backgroundColor: COLORS.surface,
  },
  chipSelected: {
    backgroundColor: COLORS.primaryLight,
  },
  textWhite: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
});