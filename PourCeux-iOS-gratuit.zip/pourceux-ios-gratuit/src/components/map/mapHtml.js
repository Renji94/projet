// Page HTML autonome chargée dans la WebView (voir MapWebView.js).
// MapLibre GL JS est chargé depuis unpkg en version exacte (JS et CSS
// identiques) pour éviter toute dérive entre les deux fichiers.
const MAPLIBRE_GL_VERSION = '5.24.0';
const MAPLIBRE_GL_JS_URL = `https://unpkg.com/maplibre-gl@${MAPLIBRE_GL_VERSION}/dist/maplibre-gl.js`;
const MAPLIBRE_GL_CSS_URL = `https://unpkg.com/maplibre-gl@${MAPLIBRE_GL_VERSION}/dist/maplibre-gl.css`;

/**
 * Construit le HTML de la carte. Seules des valeurs de configuration
 * contrôlées par l'app (couleurs, style, centre/zoom par défaut) sont
 * injectées ici — aucune donnée Supabase/utilisateur. Les données réellement
 * dynamiques (position, maraudes, signalements) transitent uniquement par
 * postMessage une fois la page chargée (voir MapWebView.js).
 */
export function buildMapHtml({ styleUrl, colors, center, zoom, debug }) {
  const config = JSON.stringify({ styleUrl, colors, center, zoom, debug: Boolean(debug) });

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <link rel="stylesheet" href="${MAPLIBRE_GL_CSS_URL}" />
  <style>
    html, body, #map {
      width: 100%;
      height: 100%;
      margin: 0;
      padding: 0;
      overflow: hidden;
    }
    .event-marker {
      display: flex;
      flex-direction: column;
      align-items: center;
      cursor: pointer;
    }
    .event-marker-pin {
      width: 34px;
      height: 34px;
      border-radius: 17px;
      border: 2px solid #FFFFFF;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 3px rgba(0,0,0,0.3);
      font-size: 16px;
      line-height: 1;
    }
    .event-marker-pointer {
      width: 0;
      height: 0;
      border-left: 6px solid transparent;
      border-right: 6px solid transparent;
      border-top: 8px solid transparent;
      margin-top: -1px;
    }
    .user-marker {
      width: 22px;
      height: 22px;
      border-radius: 11px;
      background: rgba(22, 163, 74, 0.3);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .user-marker-inner {
      width: 12px;
      height: 12px;
      border-radius: 6px;
      border: 2px solid #FFFFFF;
    }
  </style>
</head>
<body>
  <div id="map"></div>
  <script src="${MAPLIBRE_GL_JS_URL}"></script>
  <script>
    (function () {
      var CONFIG = ${config};

      function post(type, payload) {
        if (window.ReactNativeWebView) {
          window.ReactNativeWebView.postMessage(JSON.stringify({ type: type, payload: payload || null }));
        }
      }

      function log() {
        if (!CONFIG.debug) return;
        try {
          post('log', { args: Array.prototype.slice.call(arguments).map(String) });
        } catch (e) {
          // ignore
        }
      }

      window.onerror = function (message) {
        post('error', { message: String(message) });
        return false;
      };

      var map;
      try {
        map = new maplibregl.Map({
          container: 'map',
          style: CONFIG.styleUrl,
          center: CONFIG.center,
          zoom: CONFIG.zoom,
        });
      } catch (e) {
        post('error', { message: 'Impossible d\\'initialiser la carte : ' + (e && e.message) });
        return;
      }

      map.on('error', function (e) {
        post('error', { message: (e && e.error && e.error.message) || 'Erreur de chargement de la carte.' });
      });

      map.on('load', function () {
        log('map load');
        // L'attribution s'ouvre dans le navigateur externe du téléphone,
        // jamais en navigant la WebView elle-même.
        var attribLinks = document.querySelectorAll('.maplibregl-ctrl-attrib a');
        for (var i = 0; i < attribLinks.length; i++) {
          attribLinks[i].addEventListener('click', function (evt) {
            evt.preventDefault();
            post('openLink', { url: evt.currentTarget.href });
          });
        }
        post('ready');
      });

      map.on('moveend', function () {
        var c = map.getCenter();
        post('centerChanged', { center: [c.lng, c.lat], zoom: map.getZoom() });
      });

      var userMarker = null;
      var eventMarkers = {};

      function createEventMarkerElement(color, glyph, title) {
        var el = document.createElement('div');
        el.className = 'event-marker';
        if (title) el.setAttribute('title', title);

        var pin = document.createElement('div');
        pin.className = 'event-marker-pin';
        pin.style.backgroundColor = color;
        pin.textContent = glyph;

        var pointer = document.createElement('div');
        pointer.className = 'event-marker-pointer';
        pointer.style.borderTopColor = color;

        el.appendChild(pin);
        el.appendChild(pointer);
        return el;
      }

      function syncMarkers(kind, items, color, glyph) {
        var seenIds = {};
        (items || []).forEach(function (item) {
          var key = kind + '-' + item.id;
          seenIds[key] = true;
          var existing = eventMarkers[key];
          if (existing) {
            existing.setLngLat([item.longitude, item.latitude]);
            return;
          }
          var el = createEventMarkerElement(color, glyph, item.titre || '');
          el.addEventListener('click', function () {
            post('markerSelected', { id: item.id, kind: kind });
          });
          var marker = new maplibregl.Marker({ element: el, anchor: 'bottom' })
            .setLngLat([item.longitude, item.latitude])
            .addTo(map);
          eventMarkers[key] = marker;
        });
        Object.keys(eventMarkers).forEach(function (key) {
          if (key.indexOf(kind + '-') === 0 && !seenIds[key]) {
            eventMarkers[key].remove();
            delete eventMarkers[key];
          }
        });
      }

      function setUserLocation(location) {
        if (!location) return;
        var lngLat = [location.longitude, location.latitude];
        if (userMarker) {
          userMarker.setLngLat(lngLat);
          return;
        }
        var el = document.createElement('div');
        el.className = 'user-marker';
        var inner = document.createElement('div');
        inner.className = 'user-marker-inner';
        inner.style.backgroundColor = CONFIG.colors.user;
        el.appendChild(inner);
        userMarker = new maplibregl.Marker({ element: el, anchor: 'center' })
          .setLngLat(lngLat)
          .addTo(map);
      }

      function handleMessage(raw) {
        var msg;
        try {
          msg = JSON.parse(raw);
        } catch (e) {
          return;
        }
        switch (msg.type) {
          case 'setUserLocation':
            setUserLocation(msg.payload);
            break;
          case 'setMaraudes':
            syncMarkers('maraude', msg.payload, CONFIG.colors.maraude, '\\uD83D\\uDEB6');
            break;
          case 'setSignalements':
            syncMarkers('signalement', msg.payload, CONFIG.colors.signalement, '\\u26A0');
            break;
          case 'flyTo':
            if (msg.payload && msg.payload.center) {
              map.flyTo({ center: msg.payload.center, zoom: msg.payload.zoom, duration: 600 });
            }
            break;
          default:
            break;
        }
      }

      document.addEventListener('message', function (e) {
        handleMessage(e.data);
      });
      window.addEventListener('message', function (e) {
        handleMessage(e.data);
      });
    })();
  </script>
</body>
</html>`;
}
