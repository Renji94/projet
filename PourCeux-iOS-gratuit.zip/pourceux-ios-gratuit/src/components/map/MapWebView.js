import React, { forwardRef, useCallback, useEffect, useImperativeHandle, useRef } from 'react';
import { StyleSheet, Linking } from 'react-native';
import { WebView } from 'react-native-webview';
import { CONFIG } from '../../constants/config';
import { COLORS } from '../../constants/colors';
import { DEFAULT_CENTER, DEFAULT_ZOOM } from '../../utils/geo';
import { buildMapHtml } from './mapHtml';

const MAP_HTML = buildMapHtml({
  styleUrl: CONFIG.MAP_STYLE_URL,
  colors: {
    maraude: COLORS.markerMaraude,
    signalement: COLORS.markerSignalement,
    user: COLORS.markerUser,
  },
  center: DEFAULT_CENTER,
  zoom: DEFAULT_ZOOM,
  debug: __DEV__,
});

/**
 * Carte MapLibre GL JS + OpenFreeMap rendue dans une WebView.
 * Le pont RN <-> page web passe uniquement par postMessage : aucune donnée
 * dynamique n'est injectée dans le HTML lui-même.
 */
export const MapWebView = forwardRef(function MapWebView(
  { userLocation, maraudes, signalements, onReady, onError, onMarkerPress },
  ref
) {
  const webviewRef = useRef(null);
  const readyRef = useRef(false);
  const hasLoadedOnceRef = useRef(false);
  const pendingRef = useRef({});

  const send = useCallback((type, payload) => {
    if (!readyRef.current) {
      // Tant que la page n'a pas signalé "ready", on ne garde que le
      // dernier état connu par type (pas d'historique complet à rejouer).
      pendingRef.current[type] = payload;
      return;
    }
    webviewRef.current?.postMessage(JSON.stringify({ type, payload }));
  }, []);

  useImperativeHandle(ref, () => ({
    flyTo: (payload) => send('flyTo', payload),
  }));

  useEffect(() => {
    send('setUserLocation', userLocation || null);
  }, [userLocation, send]);

  useEffect(() => {
    send('setMaraudes', maraudes || []);
  }, [maraudes, send]);

  useEffect(() => {
    send('setSignalements', signalements || []);
  }, [signalements, send]);

  const handleMessage = useCallback(
    (event) => {
      let msg;
      try {
        msg = JSON.parse(event.nativeEvent.data);
      } catch {
        return;
      }

      switch (msg.type) {
        case 'ready': {
          readyRef.current = true;
          const pending = pendingRef.current;
          pendingRef.current = {};
          Object.entries(pending).forEach(([type, payload]) => {
            webviewRef.current?.postMessage(JSON.stringify({ type, payload }));
          });
          onReady?.();
          break;
        }
        case 'error':
          onError?.(msg.payload?.message || 'Erreur de la carte.');
          break;
        case 'markerSelected':
          onMarkerPress?.(msg.payload?.kind, msg.payload?.id);
          break;
        case 'openLink':
          if (msg.payload?.url) Linking.openURL(msg.payload.url).catch(() => {});
          break;
        case 'log':
          if (__DEV__) console.warn('[MapWebView]', ...(msg.payload?.args || []));
          break;
        default:
          break;
      }
    },
    [onReady, onError, onMarkerPress]
  );

  const handleShouldStartLoad = useCallback((request) => {
    // Seule la toute première charge (le HTML local injecté) est autorisée.
    // Toute navigation ultérieure (clic sur un lien, redirection) est bloquée.
    if (!hasLoadedOnceRef.current) {
      hasLoadedOnceRef.current = true;
      return true;
    }
    return false;
  }, []);

  return (
    <WebView
      ref={webviewRef}
      style={styles.webview}
      source={{ html: MAP_HTML }}
      onMessage={handleMessage}
      onShouldStartLoadWithRequest={handleShouldStartLoad}
      onError={(e) => onError?.(e.nativeEvent?.description || 'Erreur de chargement.')}
      onHttpError={(e) => onError?.(`Erreur réseau (${e.nativeEvent?.statusCode || '?'}).`)}
      javaScriptEnabled
      domStorageEnabled
      geolocationEnabled={false}
      allowsInlineMediaPlayback
      startInLoadingState={false}
    />
  );
});

const styles = StyleSheet.create({
  webview: {
    flex: 1,
    backgroundColor: 'transparent',
  },
});
