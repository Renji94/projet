import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import { COLORS } from '../../constants/colors';
import { RADIUS, SPACING, SHADOW } from '../../styles/theme';

export function SettingsSection({ title, children }) {
  const items = React.Children.toArray(children).filter(Boolean);

  return (
    <View style={styles.section}>
      <Text style={styles.title}>{title}</Text>
      <View style={styles.card}>
        {items.map((child, index) => (
          <React.Fragment key={index}>
            {index > 0 ? <Divider /> : null}
            {child}
          </React.Fragment>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    marginBottom: SPACING.lg,
  },
  title: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.textOnDarkSecondary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: SPACING.sm,
    marginHorizontal: SPACING.md,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    overflow: 'hidden',
    ...SHADOW.card,
  },
});
