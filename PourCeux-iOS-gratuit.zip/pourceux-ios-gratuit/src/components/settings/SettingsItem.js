import React from 'react';
import { View, StyleSheet } from 'react-native';
import { TouchableRipple, Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS } from '../../constants/colors';
import { SPACING } from '../../styles/theme';

export function SettingsItem({ icon, label, value, onPress, disabled = false }) {
  const content = (
    <View style={[styles.row, disabled && styles.rowDisabled]}>
      <MaterialCommunityIcons
        name={icon}
        size={22}
        color={disabled ? COLORS.disabled : COLORS.primary}
      />
      <Text style={[styles.label, disabled && styles.labelDisabled]} numberOfLines={1}>
        {label}
      </Text>
      {value ? (
        <Text style={styles.value} numberOfLines={1}>
          {value}
        </Text>
      ) : null}
      {onPress && !disabled ? (
        <MaterialCommunityIcons name="chevron-right" size={20} color={COLORS.textLight} />
      ) : null}
    </View>
  );

  if (!onPress) return content;

  return (
    <TouchableRipple onPress={onPress} disabled={disabled} borderless={false}>
      {content}
    </TouchableRipple>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.md,
  },
  rowDisabled: {
    opacity: 0.5,
  },
  label: {
    flex: 1,
    fontSize: 15,
    color: COLORS.text,
  },
  labelDisabled: {
    color: COLORS.textSecondary,
  },
  value: {
    fontSize: 13,
    color: COLORS.textSecondary,
    maxWidth: 140,
  },
});
