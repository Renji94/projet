import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  TouchableOpacity,
  Linking,
  Pressable,
  Animated,
  AccessibilityInfo,
} from 'react-native';
import { Text, Portal, Modal } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS } from '../../constants/colors';
import { formatMessageTime } from '../../utils/date';
import { getItineraireUrl } from '../../utils/geo';
import { RADIUS, SPACING } from '../../styles/theme';

function replyPreviewLabel(message) {
  if (!message.reply_to) return null;
  const reply = message.reply;
  if (!reply) return 'Message indisponible';
  if (reply.is_deleted) return 'Message supprimé';
  if (reply.type === 'localisation') return 'Position partagée';
  return reply.contenu;
}

export function MessageBubble({ message, isOwn, canDelete, isHighlighted, onReply, onDelete, onQuotePress }) {
  const [menuVisible, setMenuVisible] = useState(false);
  const [highlightAnim] = useState(() => new Animated.Value(0));

  useEffect(() => {
    if (!isHighlighted) return;
    AccessibilityInfo.isReduceMotionEnabled().then((reduceMotion) => {
      if (reduceMotion) {
        Animated.sequence([
          Animated.timing(highlightAnim, { toValue: 1, duration: 0, useNativeDriver: false }),
          Animated.timing(highlightAnim, { toValue: 0, duration: 0, delay: 800, useNativeDriver: false }),
        ]).start();
        return;
      }
      Animated.sequence([
        Animated.timing(highlightAnim, { toValue: 1, duration: 150, useNativeDriver: false }),
        Animated.timing(highlightAnim, { toValue: 0, duration: 700, delay: 400, useNativeDriver: false }),
      ]).start();
    });
  }, [isHighlighted, highlightAnim]);

  const highlightColor = highlightAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['rgba(179, 227, 199, 0)', 'rgba(179, 227, 199, 0.55)'],
  });

  const openLocation = () => {
    const url = getItineraireUrl(message.latitude, message.longitude);
    Linking.openURL(url).catch(() => {});
  };

  const handleLongPress = () => {
    if (message.is_deleted) return;
    setMenuVisible(true);
  };

  const handleReply = () => {
    setMenuVisible(false);
    onReply?.(message);
  };

  const handleDelete = () => {
    setMenuVisible(false);
    onDelete?.(message.id);
  };

  const replyLabel = replyPreviewLabel(message);
  const reply = message.reply;

  return (
    <>
      <Pressable onLongPress={handleLongPress} delayLongPress={350}>
        <Animated.View
          style={[
            styles.wrapper,
            isOwn ? styles.wrapperOwn : styles.wrapperOther,
            { backgroundColor: highlightColor },
          ]}
        >
          {!isOwn && !message.is_deleted && (
            <Text style={styles.pseudo}>{message.auteur?.pseudo || 'Utilisateur'}</Text>
          )}

          <View style={[styles.bubble, isOwn ? styles.bubbleOwn : styles.bubbleOther]}>
            {message.is_deleted ? (
              <Text style={[styles.deletedText, isOwn && styles.textOwn]}>Message supprimé</Text>
            ) : (
              <>
                {replyLabel ? (
                  <TouchableOpacity
                    style={[styles.replyQuote, isOwn ? styles.replyQuoteOwn : styles.replyQuoteOther]}
                    onPress={() => reply && onQuotePress?.(reply.id)}
                    disabled={!reply}
                    accessibilityRole={reply ? 'button' : undefined}
                    accessibilityLabel="Aller au message cité"
                  >
                    <Text style={[styles.replyAuthor, isOwn && styles.textOwn]} numberOfLines={1}>
                      {reply?.auteur?.pseudo || 'Utilisateur'}
                    </Text>
                    <Text style={[styles.replyExcerpt, isOwn && styles.textOwn]} numberOfLines={1}>
                      {replyLabel}
                    </Text>
                  </TouchableOpacity>
                ) : null}

                {message.type === 'localisation' ? (
                  <TouchableOpacity
                    style={styles.locationContent}
                    onPress={openLocation}
                    accessibilityRole="button"
                    accessibilityLabel="Ouvrir la position partagée sur la carte"
                  >
                    <MaterialCommunityIcons
                      name="map-marker"
                      size={20}
                      color={isOwn ? '#FFFFFF' : COLORS.primary}
                    />
                    <Text style={[styles.locationText, isOwn && styles.textOwn]}>
                      Position partagée{'\n'}
                      <Text style={[styles.coords, isOwn && styles.textOwn]}>
                        {message.latitude?.toFixed(5)}, {message.longitude?.toFixed(5)}
                      </Text>
                    </Text>
                  </TouchableOpacity>
                ) : (
                  <Text style={[styles.contenu, isOwn && styles.textOwn]}>{message.contenu}</Text>
                )}
              </>
            )}
          </View>

          <Text style={styles.time}>{formatMessageTime(message.created_at)}</Text>
        </Animated.View>
      </Pressable>

      <Portal>
        <Modal
          visible={menuVisible}
          onDismiss={() => setMenuVisible(false)}
          contentContainerStyle={styles.actionModal}
        >
          <TouchableOpacity style={styles.actionRow} onPress={handleReply}>
            <MaterialCommunityIcons name="reply" size={22} color={COLORS.primary} />
            <Text style={styles.actionText}>Répondre</Text>
          </TouchableOpacity>
          {canDelete ? (
            <TouchableOpacity style={styles.actionRow} onPress={handleDelete}>
              <MaterialCommunityIcons name="delete-outline" size={22} color={COLORS.danger} />
              <Text style={[styles.actionText, styles.actionTextDanger]}>Supprimer</Text>
            </TouchableOpacity>
          ) : null}
        </Modal>
      </Portal>
    </>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    marginVertical: 4,
    marginHorizontal: SPACING.md,
    maxWidth: '80%',
    borderRadius: RADIUS.md,
  },
  wrapperOwn: {
    alignSelf: 'flex-end',
    alignItems: 'flex-end',
  },
  wrapperOther: {
    alignSelf: 'flex-start',
    alignItems: 'flex-start',
  },
  pseudo: {
    fontSize: 11,
    color: COLORS.textOnDarkSecondary,
    marginBottom: 2,
    marginLeft: 4,
  },
  bubble: {
    borderRadius: RADIUS.lg,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
  },
  bubbleOwn: {
    backgroundColor: COLORS.primary,
    borderBottomRightRadius: 4,
  },
  bubbleOther: {
    backgroundColor: COLORS.surface,
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  contenu: {
    color: COLORS.text,
    fontSize: 15,
  },
  deletedText: {
    color: COLORS.textSecondary,
    fontSize: 15,
    fontStyle: 'italic',
  },
  textOwn: {
    color: '#FFFFFF',
  },
  replyQuote: {
    borderLeftWidth: 3,
    borderLeftColor: COLORS.secondary,
    paddingLeft: SPACING.sm,
    marginBottom: SPACING.xs,
  },
  replyQuoteOwn: {
    borderLeftColor: COLORS.secondary,
  },
  replyQuoteOther: {
    borderLeftColor: COLORS.primary,
  },
  replyAuthor: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.textSecondary,
  },
  replyExcerpt: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  locationContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  locationText: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.text,
  },
  coords: {
    fontSize: 11,
    fontWeight: '400',
    color: COLORS.textSecondary,
  },
  time: {
    fontSize: 10,
    color: COLORS.textOnDarkSecondary,
    marginTop: 2,
    marginHorizontal: 4,
  },
  actionModal: {
    margin: SPACING.lg,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.sm,
  },
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.sm,
  },
  actionText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
  },
  actionTextDanger: {
    color: COLORS.danger,
  },
});
