import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { TextInput, IconButton, Text } from 'react-native-paper';
import * as Location from 'expo-location';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useToast } from '../../contexts/ToastContext';
import { COLORS } from '../../constants/colors';
import { SPACING, RADIUS, SHADOW } from '../../styles/theme';

const SEND_ERROR_MESSAGE = "Le message n'a pas pu être envoyé. Réessayez.";

function replyPreviewText(replyingTo) {
  if (!replyingTo) return '';
  if (replyingTo.type === 'localisation') return 'Position partagée';
  return replyingTo.contenu || '';
}

export function ChatInput({ onSendText, onSendLocation, sending, replyingTo, onCancelReply }) {
  const [text, setText] = useState('');
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const canSend = Boolean(text.trim()) && !sending;

  const handleSend = async () => {
    const trimmed = text.trim();
    if (!trimmed || sending) return;
    setText('');
    try {
      await onSendText(trimmed);
    } catch {
      setText(trimmed);
      toast.showError(SEND_ERROR_MESSAGE);
    }
  };

  const handleShareLocation = async () => {
    if (sending) return;
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        toast.showInfo('Activez la localisation pour partager votre position.');
        return;
      }
      const pos = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      await onSendLocation(pos.coords.latitude, pos.coords.longitude);
    } catch {
      toast.showError('Impossible de partager votre position.');
    }
  };

  return (
    <View style={[styles.container, { paddingBottom: Math.max(insets.bottom, SPACING.sm) }]}>
      {replyingTo ? (
        <View style={styles.replyPreview}>
          <View style={styles.replyPreviewBar} />
          <View style={styles.replyPreviewBody}>
            <Text style={styles.replyPreviewAuthor} numberOfLines={1}>
              {replyingTo.auteur?.pseudo || 'Utilisateur'}
            </Text>
            <Text style={styles.replyPreviewExcerpt} numberOfLines={1}>
              {replyPreviewText(replyingTo)}
            </Text>
          </View>
          <IconButton
            icon="close"
            size={18}
            iconColor={COLORS.textSecondary}
            onPress={onCancelReply}
            accessibilityLabel="Annuler la réponse"
          />
        </View>
      ) : null}

      <View style={styles.capsule}>
        <IconButton
          icon="map-marker"
          mode="contained"
          containerColor={COLORS.primaryLight}
          iconColor={COLORS.primary}
          size={20}
          style={styles.roundButton}
          onPress={handleShareLocation}
          disabled={sending}
          accessibilityLabel="Partager ma position"
        />
        <TextInput
          style={styles.input}
          mode="flat"
          underlineColor="transparent"
          activeUnderlineColor="transparent"
          placeholder="Écrire un message…"
          value={text}
          onChangeText={setText}
          multiline
          maxLength={2000}
          dense
          accessibilityLabel="Champ de message"
        />
        <IconButton
          icon="send"
          mode="contained"
          containerColor={canSend ? COLORS.primary : COLORS.disabled}
          iconColor="#FFFFFF"
          size={20}
          style={styles.roundButton}
          onPress={handleSend}
          disabled={!canSend}
          accessibilityLabel="Envoyer le message"
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: SPACING.sm,
    paddingTop: SPACING.xs,
  },
  capsule: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.lg,
    paddingHorizontal: SPACING.xs,
    paddingVertical: SPACING.xs,
    ...SHADOW.card,
  },
  roundButton: {
    margin: 0,
    borderRadius: RADIUS.full,
  },
  input: {
    flex: 1,
    maxHeight: 100,
    backgroundColor: 'transparent',
  },
  replyPreview: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.xs,
    marginBottom: SPACING.xs,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.sm,
  },
  replyPreviewBar: {
    width: 3,
    alignSelf: 'stretch',
    backgroundColor: COLORS.secondary,
    marginRight: SPACING.sm,
    borderRadius: 2,
  },
  replyPreviewBody: {
    flex: 1,
  },
  replyPreviewAuthor: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.primary,
  },
  replyPreviewExcerpt: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
});
