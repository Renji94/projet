import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text } from 'react-native-paper';
import { RADIUS, SPACING } from '../../styles/theme';

export function Badge({ label, color, textColor = '#FFFFFF', small = false }) {
  return (
    <View style={[styles.badge, { backgroundColor: color }, small && styles.small]}>
      <Text style={[styles.text, { color: textColor }, small && styles.smallText]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    borderRadius: RADIUS.full,
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.xs,
    alignSelf: 'flex-start',
  },
  small: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.xxs,
  },
  text: {
    fontSize: 12,
    fontWeight: '600',
  },
  smallText: {
    fontSize: 10,
  },
});