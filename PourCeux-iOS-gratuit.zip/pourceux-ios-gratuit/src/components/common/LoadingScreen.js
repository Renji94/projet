import React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import { ActivityIndicator, Text } from 'react-native-paper';
import { COLORS } from '../../constants/colors';

export function LoadingScreen({ message = 'Chargement…', transparent = false }) {
  return (
    <View style={[styles.container, transparent && styles.containerTransparent]}>
      <Image
        source={require('../../../assets/logo.png')}
        style={styles.logo}
        resizeMode="contain"
        accessibilityLabel="Logo PourCeux"
      />
      <ActivityIndicator size="large" color={COLORS.secondary} />
      <Text style={[styles.text, transparent && styles.textTransparent]}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    padding: 24,
  },
  containerTransparent: {
    backgroundColor: 'transparent',
  },
  logo: {
    width: 220,
    height: 175,
    marginBottom: 24,
  },
  text: {
    marginTop: 12,
    color: COLORS.primaryLight,
  },
  textTransparent: {
    color: COLORS.textOnDark,
  },
});
