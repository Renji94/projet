import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Snackbar, Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS } from '../../constants/colors';
import { RADIUS, SPACING, SHADOW } from '../../styles/theme';

const TYPE_CONFIG = {
  success: { icon: 'check-circle', color: COLORS.success },
  error: { icon: 'alert-circle', color: COLORS.danger },
  info: { icon: 'information', color: COLORS.info },
};

export function Toast({ toast, onDismiss }) {
  const insets = useSafeAreaInsets();
  const config = TYPE_CONFIG[toast?.type] || TYPE_CONFIG.info;

  return (
    <Snackbar
      visible={Boolean(toast)}
      onDismiss={onDismiss}
      duration={toast?.duration}
      style={[styles.snackbar, { marginBottom: insets.bottom + SPACING.sm }]}
      action={{ label: 'Fermer', onPress: onDismiss, textColor: COLORS.textOnDark }}
    >
      <View style={styles.content}>
        <MaterialCommunityIcons name={config.icon} size={20} color={config.color} />
        <Text style={styles.text}>{toast?.message}</Text>
      </View>
    </Snackbar>
  );
}

const styles = StyleSheet.create({
  snackbar: {
    borderRadius: RADIUS.md,
    backgroundColor: COLORS.primaryDark,
    ...SHADOW.elevated,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  text: {
    color: COLORS.textOnDark,
    flex: 1,
  },
});
