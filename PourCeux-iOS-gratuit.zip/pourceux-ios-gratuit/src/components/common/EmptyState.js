import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS } from '../../constants/colors';

export function EmptyState({ icon = 'inbox', title, subtitle }) {
  return (
    <View style={styles.container}>
      <MaterialCommunityIcons name={icon} size={64} color={COLORS.textOnDarkSecondary} />
      <Text variant="titleMedium" style={styles.title}>
        {title}
      </Text>
      {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
  },
  title: {
    marginTop: 16,
    color: COLORS.textOnDark,
    textAlign: 'center',
  },
  subtitle: {
    marginTop: 8,
    color: COLORS.textOnDarkSecondary,
    textAlign: 'center',
  },
});