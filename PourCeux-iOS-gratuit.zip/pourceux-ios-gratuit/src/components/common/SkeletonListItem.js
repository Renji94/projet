import React, { useEffect, useState } from 'react';
import { View, StyleSheet, Animated, AccessibilityInfo } from 'react-native';
import { COLORS } from '../../constants/colors';
import { RADIUS, SPACING, SHADOW } from '../../styles/theme';

export function SkeletonListItem() {
  const [opacity] = useState(() => new Animated.Value(0.4));

  useEffect(() => {
    let loop;
    let cancelled = false;
    AccessibilityInfo.isReduceMotionEnabled().then((reduceMotion) => {
      if (cancelled || reduceMotion) return;
      loop = Animated.loop(
        Animated.sequence([
          Animated.timing(opacity, { toValue: 1, duration: 700, useNativeDriver: true }),
          Animated.timing(opacity, { toValue: 0.4, duration: 700, useNativeDriver: true }),
        ])
      );
      loop.start();
    });
    return () => {
      cancelled = true;
      loop?.stop();
    };
  }, [opacity]);

  return (
    <View style={styles.card}>
      <Animated.View style={[styles.line, styles.title, { opacity }]} />
      <Animated.View style={[styles.line, styles.subtitle, { opacity }]} />
      <Animated.View style={[styles.line, styles.subtitleShort, { opacity }]} />
    </View>
  );
}

export function SkeletonList({ count = 4 }) {
  return (
    <View>
      {Array.from({ length: count }).map((_, index) => (
        <SkeletonListItem key={index} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginHorizontal: SPACING.md,
    marginVertical: SPACING.xs,
    ...SHADOW.card,
  },
  line: {
    backgroundColor: COLORS.border,
    borderRadius: RADIUS.sm,
  },
  title: {
    height: 16,
    width: '60%',
    marginBottom: SPACING.sm,
  },
  subtitle: {
    height: 12,
    width: '90%',
    marginBottom: SPACING.xs,
  },
  subtitleShort: {
    height: 12,
    width: '40%',
  },
});
