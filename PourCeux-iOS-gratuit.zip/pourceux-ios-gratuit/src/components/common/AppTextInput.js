import React from 'react';
import { View, StyleSheet } from 'react-native';
import { TextInput, HelperText } from 'react-native-paper';
import { Controller } from 'react-hook-form';
import { COLORS } from '../../constants/colors';
import { RADIUS } from '../../styles/theme';

/**
 * Champ de texte intégré à React Hook Form.
 */
export function AppTextInput({ control, name, label, rules, error, style, ...props }) {
  return (
    <View style={styles.container}>
      <Controller
        control={control}
        name={name}
        rules={rules}
        render={({ field: { onChange, onBlur, value } }) => (
          <TextInput
            label={label}
            mode="outlined"
            outlineStyle={styles.outline}
            value={value ?? ''}
            onChangeText={onChange}
            onBlur={onBlur}
            error={Boolean(error)}
            style={[styles.input, style]}
            {...props}
          />
        )}
      />
      {error ? <HelperText type="error">{error.message}</HelperText> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 8,
  },
  input: {
    backgroundColor: COLORS.surface,
  },
  outline: {
    borderRadius: RADIUS.sm,
  },
});