import React, { useEffect, useState } from 'react';
import { Animated, AccessibilityInfo, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { COLORS } from '../../constants/colors';

const PHASE_DURATION_MS = 10000;
const LAYERS = [COLORS.gradient.blue, COLORS.gradient.blueGray, COLORS.gradient.softGray];

export function AnimatedGradientBackground() {
  const [opacities] = useState(() =>
    LAYERS.map((_, index) => new Animated.Value(index === 0 ? 1 : 0))
  );

  useEffect(() => {
    let loop;
    let cancelled = false;

    AccessibilityInfo.isReduceMotionEnabled().then((reduceMotion) => {
      if (cancelled || reduceMotion) return;
      const sequence = LAYERS.map((_, index) => {
        const current = (index + 1) % LAYERS.length;
        return Animated.parallel([
          Animated.timing(opacities[index], {
            toValue: 0,
            duration: PHASE_DURATION_MS,
            useNativeDriver: true,
          }),
          Animated.timing(opacities[current], {
            toValue: 1,
            duration: PHASE_DURATION_MS,
            useNativeDriver: true,
          }),
        ]);
      });
      loop = Animated.loop(Animated.sequence(sequence));
      loop.start();
    });

    return () => {
      cancelled = true;
      loop?.stop();
    };
  }, [opacities]);

  return (
    <Animated.View style={StyleSheet.absoluteFill} pointerEvents="none">
      {LAYERS.map((colors, index) => (
        <Animated.View key={colors.join('-')} style={[StyleSheet.absoluteFill, { opacity: opacities[index] }]}>
          <LinearGradient colors={colors} style={StyleSheet.absoluteFill} />
        </Animated.View>
      ))}
    </Animated.View>
  );
}
