import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Chip } from 'react-native-paper';
import { COLORS } from '../../constants/colors';
import { SPACING } from '../../styles/theme';

export function SortBar({ options, value, onChange }) {
  return (
    <View style={styles.row}>
      {options.map((option) => {
        const selected = value === option.value;
        return (
          <Chip
            key={option.value}
            selected={selected}
            disabled={option.disabled}
            icon={option.icon}
            onPress={() => onChange(option.value)}
            style={[styles.chip, selected && styles.chipSelected]}
            textStyle={selected ? styles.textSelected : undefined}
          >
            {option.label}
          </Chip>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm,
    paddingHorizontal: SPACING.md,
  },
  chip: {
    backgroundColor: COLORS.surface,
  },
  chipSelected: {
    backgroundColor: COLORS.primary,
  },
  textSelected: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
});
