import React from 'react';
import { StyleSheet } from 'react-native';
import { Portal, Dialog, Text } from 'react-native-paper';
import { AppButton } from './AppButton';
import { COLORS } from '../../constants/colors';
import { RADIUS, SHADOW } from '../../styles/theme';

export function ConfirmDialog({ request, onCancel, onConfirm }) {
  return (
    <Portal>
      <Dialog visible={Boolean(request)} onDismiss={onCancel} style={styles.dialog}>
        <Dialog.Title>{request?.title}</Dialog.Title>
        <Dialog.Content>
          <Text>{request?.message}</Text>
        </Dialog.Content>
        <Dialog.Actions>
          <AppButton mode="text" onPress={onCancel}>
            {request?.cancelLabel || 'Annuler'}
          </AppButton>
          <AppButton
            mode="text"
            onPress={onConfirm}
            textColor={request?.destructive ? COLORS.danger : undefined}
          >
            {request?.confirmLabel || 'Confirmer'}
          </AppButton>
        </Dialog.Actions>
      </Dialog>
    </Portal>
  );
}

const styles = StyleSheet.create({
  dialog: {
    borderRadius: RADIUS.md,
    ...SHADOW.elevated,
  },
});
