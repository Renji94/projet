import React, { useEffect, useRef, useState, useCallback } from 'react';
import { StyleSheet, Animated, AccessibilityInfo } from 'react-native';
import { Button } from 'react-native-paper';
import { RADIUS } from '../../styles/theme';

export function AppButton({ children, mode = 'contained', style, onPressIn, onPressOut, ...props }) {
  const [scale] = useState(() => new Animated.Value(1));
  const reduceMotionRef = useRef(false);

  useEffect(() => {
    let cancelled = false;
    AccessibilityInfo.isReduceMotionEnabled().then((value) => {
      if (!cancelled) reduceMotionRef.current = value;
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const handlePressIn = useCallback(
    (e) => {
      if (!reduceMotionRef.current) {
        Animated.spring(scale, { toValue: 0.96, useNativeDriver: true, speed: 50, bounciness: 0 }).start();
      }
      onPressIn?.(e);
    },
    [scale, onPressIn]
  );

  const handlePressOut = useCallback(
    (e) => {
      if (!reduceMotionRef.current) {
        Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 50, bounciness: 0 }).start();
      }
      onPressOut?.(e);
    },
    [scale, onPressOut]
  );

  return (
    <Animated.View style={[{ transform: [{ scale }] }, style]}>
      <Button
        mode={mode}
        style={styles.button}
        contentStyle={styles.content}
        labelStyle={styles.label}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        {...props}
      >
        {children}
      </Button>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: RADIUS.md,
    alignSelf: 'stretch',
  },
  content: {
    paddingVertical: 6,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
  },
});
