import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS } from '../../constants/colors';
import { RADIUS, SPACING } from '../../styles/theme';

export function ErrorMessage({ message }) {
  if (!message) return null;
  return (
    <View style={styles.container}>
      <MaterialCommunityIcons name="alert-circle" size={20} color={COLORS.danger} />
      <Text style={styles.text}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FEE2E2',
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginVertical: SPACING.sm,
    gap: 8,
  },
  text: {
    color: COLORS.danger,
    flex: 1,
  },
});