import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, Avatar } from 'react-native-paper';
import { COLORS } from '../../constants/colors';
import { SPACING, RADIUS } from '../../styles/theme';

export function ParticipantsList({ participants = [] }) {
  if (participants.length === 0) {
    return <Text style={styles.empty}>Aucun participant pour le moment.</Text>;
  }

  return (
    <View style={styles.container}>
      {participants.map((p) => (
        <View key={p.user.id} style={styles.item}>
          {p.user.avatar_url ? (
            <Avatar.Image size={40} source={{ uri: p.user.avatar_url }} />
          ) : (
            <Avatar.Text
              size={40}
              label={(p.user.pseudo || '?').slice(0, 2).toUpperCase()}
              style={{ backgroundColor: COLORS.primaryLight }}
              labelStyle={{ color: COLORS.primary }}
            />
          )}
          <View style={styles.details}>
            <Text style={styles.pseudo}>{p.user.pseudo}</Text>
            <Text style={styles.ville}>{p.user.ville}</Text>
          </View>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: SPACING.sm,
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
    backgroundColor: COLORS.surface,
    padding: SPACING.sm,
    borderRadius: RADIUS.md,
  },
  details: {
    flex: 1,
  },
  pseudo: {
    fontWeight: '600',
    color: COLORS.text,
  },
  ville: {
    color: COLORS.textSecondary,
    fontSize: 12,
  },
  empty: {
    color: COLORS.textSecondary,
    fontStyle: 'italic',
    padding: SPACING.sm,
  },
});