import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, TouchableRipple } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Badge } from '../common/Badge';
import { COLORS } from '../../constants/colors';
import { MARAUDE_STATUTS, DIFFICULTES } from '../../constants/enums';
import { formatDate, formatHeure } from '../../utils/date';
import { formatDistance } from '../../utils/geo';
import { RADIUS, SPACING, SHADOW } from '../../styles/theme';

export function MaraudeCard({ maraude, onPress, distanceKm }) {
  const statut = MARAUDE_STATUTS[maraude.statut] || MARAUDE_STATUTS.programmee;
  const difficulte = DIFFICULTES[maraude.difficulte] || DIFFICULTES.facile;
  const complet = maraude.current_participants >= maraude.max_participants;

  return (
    <TouchableRipple
      style={styles.card}
      borderless={false}
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`Maraude ${maraude.titre}, ${statut.label}`}
    >
      <View>
        <View style={styles.header}>
          <Text variant="titleMedium" style={styles.titre} numberOfLines={1}>
            {maraude.titre}
          </Text>
          <Badge label={statut.label} color={statut.color} small />
        </View>

        <View style={styles.row}>
          <MaterialCommunityIcons name="calendar" size={16} color={COLORS.textSecondary} />
          <Text style={styles.info}>
            {formatDate(maraude.date_maraude)} · {formatHeure(maraude.heure_debut)} –{' '}
            {formatHeure(maraude.heure_fin)}
          </Text>
        </View>

        <View style={styles.row}>
          <MaterialCommunityIcons name="map-marker" size={16} color={COLORS.textSecondary} />
          <Text style={styles.info} numberOfLines={1}>
            {maraude.adresse}, {maraude.ville}
          </Text>
          {distanceKm != null ? (
            <Text style={styles.distance}>{formatDistance(distanceKm)}</Text>
          ) : null}
        </View>

        <View style={styles.footer}>
          <View style={styles.row}>
            <MaterialCommunityIcons
              name="account-group"
              size={16}
              color={complet ? COLORS.danger : COLORS.success}
            />
            <Text style={[styles.info, complet && { color: COLORS.danger }]}>
              {maraude.current_participants}/{maraude.max_participants}
              {complet ? ' (complet)' : ''}
            </Text>
          </View>
          <Badge label={difficulte.label} color={difficulte.color} small />
        </View>
      </View>
    </TouchableRipple>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginHorizontal: SPACING.md,
    marginVertical: SPACING.xs,
    ...SHADOW.card,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
    gap: 8,
  },
  titre: {
    flex: 1,
    fontWeight: '700',
    color: COLORS.text,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  info: {
    color: COLORS.textSecondary,
    fontSize: 13,
    flex: 1,
  },
  distance: {
    color: COLORS.primary,
    fontSize: 12,
    fontWeight: '700',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: SPACING.sm,
  },
});