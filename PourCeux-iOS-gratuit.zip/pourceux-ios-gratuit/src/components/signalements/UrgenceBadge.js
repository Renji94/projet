import React from 'react';
import { Badge } from '../common/Badge';
import { URGENCES } from '../../constants/enums';

export function UrgenceBadge({ urgence, small = false }) {
  const config = URGENCES[urgence] || URGENCES.moyenne;
  return <Badge label={config.label} color={config.color} small={small} />;
}