import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, TouchableRipple } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Badge } from '../common/Badge';
import { UrgenceBadge } from './UrgenceBadge';
import { COLORS } from '../../constants/colors';
import { SIGNALEMENT_STATUTS, BESOINS } from '../../constants/enums';
import { formatRelative } from '../../utils/date';
import { RADIUS, SPACING, SHADOW } from '../../styles/theme';

export function SignalementCard({ signalement, onPress }) {
  const statut = SIGNALEMENT_STATUTS[signalement.statut] || SIGNALEMENT_STATUTS.ouvert;
  const besoinsLabels = (signalement.besoins || [])
    .map((b) => BESOINS.find((x) => x.value === b)?.label || b)
    .join(', ');

  return (
    <TouchableRipple
      style={styles.card}
      borderless={false}
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`Signalement ${signalement.titre}, urgence ${signalement.urgence}`}
    >
      <View>
        <View style={styles.header}>
          <Text variant="titleMedium" style={styles.titre} numberOfLines={1}>
            {signalement.titre}
          </Text>
          <UrgenceBadge urgence={signalement.urgence} small />
        </View>

        <Text style={styles.description} numberOfLines={2}>
          {signalement.description}
        </Text>

        {signalement.adresse ? (
          <View style={styles.row}>
            <MaterialCommunityIcons name="map-marker" size={16} color={COLORS.textSecondary} />
            <Text style={styles.info} numberOfLines={1}>
              {signalement.adresse}
            </Text>
          </View>
        ) : null}

        <View style={styles.row}>
          <MaterialCommunityIcons name="account-multiple" size={16} color={COLORS.textSecondary} />
          <Text style={styles.info}>
            {signalement.nb_personnes} personne{signalement.nb_personnes > 1 ? 's' : ''}
            {signalement.animaux ? ' · avec animaux' : ''}
          </Text>
        </View>

        {besoinsLabels ? (
          <View style={styles.row}>
            <MaterialCommunityIcons name="hand-heart" size={16} color={COLORS.textSecondary} />
            <Text style={styles.info} numberOfLines={1}>
              {besoinsLabels}
            </Text>
          </View>
        ) : null}

        <View style={styles.footer}>
          <Badge label={statut.label} color={statut.color} small />
          <Text style={styles.date}>{formatRelative(signalement.created_at)}</Text>
        </View>
      </View>
    </TouchableRipple>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginHorizontal: SPACING.md,
    marginVertical: SPACING.xs,
    ...SHADOW.card,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
    gap: 8,
  },
  titre: {
    flex: 1,
    fontWeight: '700',
    color: COLORS.text,
  },
  description: {
    color: COLORS.textSecondary,
    marginBottom: SPACING.sm,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  info: {
    color: COLORS.textSecondary,
    fontSize: 13,
    flex: 1,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: SPACING.sm,
  },
  date: {
    color: COLORS.textLight,
    fontSize: 12,
  },
});