import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Chip, HelperText } from 'react-native-paper';
import { BESOINS } from '../../constants/enums';
import { COLORS } from '../../constants/colors';
import { SPACING } from '../../styles/theme';

export function BesoinsSelector({ value = [], onChange, error }) {
  const toggle = (besoin) => {
    if (value.includes(besoin)) {
      onChange(value.filter((b) => b !== besoin));
    } else {
      onChange([...value, besoin]);
    }
  };

  return (
    <View>
      <View style={styles.container}>
        {BESOINS.map((besoin) => {
          const selected = value.includes(besoin.value);
          return (
            <Chip
              key={besoin.value}
              icon={besoin.icon}
              selected={selected}
              onPress={() => toggle(besoin.value)}
              style={[styles.chip, selected && styles.chipSelected]}
              textStyle={selected ? styles.textSelected : undefined}
              accessibilityLabel={`Besoin ${besoin.label}${selected ? ', sélectionné' : ''}`}
            >
              {besoin.label}
            </Chip>
          );
        })}
      </View>
      {error ? <HelperText type="error">{error.message}</HelperText> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm,
    marginVertical: SPACING.sm,
  },
  chip: {
    backgroundColor: COLORS.surface,
  },
  chipSelected: {
    backgroundColor: COLORS.primaryLight,
  },
  textSelected: {
    color: COLORS.primary,
    fontWeight: '600',
  },
});