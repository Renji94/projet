import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, TouchableRipple } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Badge } from '../common/Badge';
import { COLORS } from '../../constants/colors';
import { formatRelative } from '../../utils/date';
import { RADIUS, SPACING, SHADOW } from '../../styles/theme';

export function ConversationCard({ conversation, onPress }) {
  const isMaraude = conversation.type === 'maraude';
  const isLocation = conversation.lastMessage?.type === 'localisation';
  const preview = conversation.lastMessage
    ? isLocation
      ? 'Position partagée'
      : conversation.lastMessage.contenu
    : 'Aucun message';

  return (
    <TouchableRipple
      style={styles.card}
      borderless={false}
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`Conversation ${conversation.titre}`}
    >
      <View>
        <View style={styles.header}>
          <Text variant="titleMedium" style={styles.titre} numberOfLines={1}>
            {conversation.titre}
          </Text>
          <Badge
            label={isMaraude ? 'Maraude' : 'Signalement'}
            color={isMaraude ? COLORS.markerMaraude : COLORS.markerSignalement}
            small
          />
        </View>

        <View style={styles.row}>
          {isLocation && (
            <MaterialCommunityIcons name="map-marker" size={16} color={COLORS.textSecondary} />
          )}
          <Text style={styles.preview} numberOfLines={1}>
            {preview}
          </Text>
          <Text style={styles.time}>{formatRelative(conversation.lastActivity)}</Text>
        </View>
      </View>
    </TouchableRipple>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginHorizontal: SPACING.md,
    marginVertical: SPACING.xs,
    ...SHADOW.card,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
    gap: 8,
  },
  titre: {
    flex: 1,
    fontWeight: '700',
    color: COLORS.text,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  preview: {
    flex: 1,
    color: COLORS.textSecondary,
    fontSize: 13,
  },
  time: {
    color: COLORS.textLight,
    fontSize: 11,
  },
});
