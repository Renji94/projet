import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import * as Linking from 'expo-linking';

import { authService } from '../services/auth.service';
import { profilesService } from '../services/profiles.service';
import { startSupabaseAutoRefresh } from '../services/supabase';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadProfile = useCallback(async (userId) => {
    setError(null);

    try {
      const data = await profilesService.getMyProfile();

      if (data?.id !== userId) {
        throw new Error('Profil incohérent avec la session active.');
      }

      setProfile(data);
      return data;
    } catch (e) {
      setProfile(null);
      setError(e.message || 'Impossible de charger votre profil.');
      throw e;
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    let profileLoadTimer;

    const stopAutoRefresh = startSupabaseAutoRefresh();

    const handleIncomingUrl = async ({ url }) => {
      if (!url || !mounted) return;

      setLoading(true);
      setError(null);

      try {
        const nextSession = await authService.createSessionFromUrl(url);

        if (!mounted || !nextSession?.user) return;

        setSession(nextSession);
        await loadProfile(nextSession.user.id);
      } catch (e) {
        if (mounted) {
          setError(
            e.message || 'Impossible de confirmer votre adresse email.'
          );
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    const linkingSubscription = Linking.addEventListener(
      'url',
      handleIncomingUrl
    );

    const initialize = async () => {
      try {
        /*
         * Si l'application a été ouverte depuis le lien de confirmation
         * Supabase, on crée d'abord la session à partir de cette URL.
         */
        const initialUrl = await Linking.getInitialURL();

        if (initialUrl) {
          await authService.createSessionFromUrl(initialUrl);
        }

        const currentSession = await authService.getSession();

        if (!mounted) return;

        setSession(currentSession);

        if (currentSession?.user) {
          await loadProfile(currentSession.user.id);
        } else {
          setProfile(null);
        }
      } catch (e) {
        if (mounted) {
          setSession(null);
          setProfile(null);
          setError(
            e.message ||
              'Impossible d’initialiser la session utilisateur.'
          );
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    const subscription = authService.onAuthStateChange((nextSession) => {
      if (!mounted) return;

      setSession(nextSession);
      setLoading(true);

      clearTimeout(profileLoadTimer);

      /*
       * L'appel Supabase est décalé hors du callback Auth afin d'éviter
       * de réutiliser le verrou interne de session pendant l'événement.
       */
      profileLoadTimer = setTimeout(async () => {
        try {
          if (nextSession?.user) {
            await loadProfile(nextSession.user.id);
          } else {
            setProfile(null);
            setError(null);
          }
        } catch {
          // L'erreur est déjà enregistrée par loadProfile.
        } finally {
          if (mounted) {
            setLoading(false);
          }
        }
      }, 0);
    });

    initialize();

    return () => {
      mounted = false;
      clearTimeout(profileLoadTimer);
      linkingSubscription.remove();
      subscription?.unsubscribe();
      stopAutoRefresh();
    };
  }, [loadProfile]);

  const signIn = useCallback(
    (credentials) => authService.signIn(credentials),
    []
  );

  const signUp = useCallback(
    (payload) => authService.signUp(payload),
    []
  );

  const signOut = useCallback(async () => {
    await authService.signOut();

    setSession(null);
    setProfile(null);
    setError(null);
  }, []);

  const refreshProfile = useCallback(async () => {
    if (!session?.user) return null;

    return loadProfile(session.user.id);
  }, [session, loadProfile]);

  const value = useMemo(
    () => ({
      session,
      user: session?.user ?? null,
      profile,
      isAdmin: profile?.role === 'admin',
      isSuspended: profile?.is_suspended === true,
      loading,
      error,
      signIn,
      signUp,
      signOut,
      refreshProfile,
    }),
    [
      session,
      profile,
      loading,
      error,
      signIn,
      signUp,
      signOut,
      refreshProfile,
    ]
  );

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error(
      'useAuth doit être utilisé dans un AuthProvider'
    );
  }

  return context;
}
