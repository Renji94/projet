import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import * as Localization from 'expo-localization';
import { translations } from '../i18n/translations';
import { getPreference, setPreference } from '../services/localPreferences';

const LocaleContext = createContext(null);
const STORAGE_KEY = 'locale';
const SUPPORTED_LOCALES = ['fr', 'en'];
const FALLBACK_LOCALE = 'fr';

// Détection du téléphone via expo-localization : I18nManager (cœur React
// Native) a été écarté après vérification — son localeIdentifier est
// documenté comme non fiable sur iOS (facebook/react-native#10709).
function detectDeviceLocale() {
  try {
    const code = Localization.getLocales()?.[0]?.languageCode;
    return SUPPORTED_LOCALES.includes(code) ? code : FALLBACK_LOCALE;
  } catch {
    return FALLBACK_LOCALE;
  }
}

export function LocaleProvider({ children }) {
  const [locale, setLocaleState] = useState(() => detectDeviceLocale());

  useEffect(() => {
    let mounted = true;
    getPreference(STORAGE_KEY, null).then((stored) => {
      if (mounted && SUPPORTED_LOCALES.includes(stored)) setLocaleState(stored);
    });
    return () => {
      mounted = false;
    };
  }, []);

  const setLocale = useCallback((next) => {
    const value = SUPPORTED_LOCALES.includes(next) ? next : FALLBACK_LOCALE;
    setLocaleState(value);
    setPreference(STORAGE_KEY, value);
  }, []);

  const t = useCallback(
    (key) => translations[locale]?.[key] ?? translations[FALLBACK_LOCALE]?.[key] ?? key,
    [locale]
  );

  return (
    <LocaleContext.Provider value={{ locale, setLocale, t }}>{children}</LocaleContext.Provider>
  );
}

export function useLocale() {
  const ctx = useContext(LocaleContext);
  if (!ctx) throw new Error('useLocale doit être utilisé dans un LocaleProvider.');
  return ctx;
}
