import React, { createContext, useCallback, useContext, useState } from 'react';
import { Toast } from '../components/common/Toast';

const ToastContext = createContext(null);

const DEFAULT_DURATION = 3500;

export function ToastProvider({ children }) {
  const [toast, setToast] = useState(null);

  const hide = useCallback(() => setToast(null), []);

  const show = useCallback((type, message, duration = DEFAULT_DURATION) => {
    setToast({ type, message, duration, key: Date.now() });
  }, []);

  const value = {
    showSuccess: (message, duration) => show('success', message, duration),
    showError: (message, duration) => show('error', message, duration),
    showInfo: (message, duration) => show('info', message, duration),
  };

  return (
    <ToastContext.Provider value={value}>
      {children}
      <Toast toast={toast} onDismiss={hide} />
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast doit être utilisé dans un ToastProvider.');
  return ctx;
}
