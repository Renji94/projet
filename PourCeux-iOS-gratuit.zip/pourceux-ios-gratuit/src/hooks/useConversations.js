import { useQuery } from '@tanstack/react-query';
import { conversationsService } from '../services/conversations.service';

export function useConversationsList() {
  return useQuery({
    queryKey: ['conversations'],
    queryFn: () => conversationsService.list(),
  });
}
