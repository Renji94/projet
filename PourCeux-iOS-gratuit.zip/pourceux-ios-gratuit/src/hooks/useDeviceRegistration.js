import { useEffect } from 'react';
import { Platform } from 'react-native';
import { useAuth } from '../contexts/AuthContext';
import { useLocation } from './useLocation';
import { profilesService } from '../services/profiles.service';
import { notificationsService } from '../services/notifications.service';

/**
 * Enregistre séquentiellement les capacités de l'appareil afin de ne pas
 * afficher simultanément les demandes de permission localisation/notifications.
 */
export function useDeviceRegistration() {
  const { user } = useAuth();
  const { requestLocation } = useLocation({ autoRequest: false });

  useEffect(() => {
    if (!user?.id || Platform.OS === 'web') return undefined;
    let cancelled = false;

    const register = async () => {
      const location = await requestLocation();
      if (!cancelled && location) {
        try {
          await profilesService.updatePosition(user.id, location.latitude, location.longitude);
        } catch (error) {
          console.warn('[Localisation] Synchronisation impossible :', error.message);
        }
      }

      if (!cancelled) {
        try {
          await notificationsService.registerForPushNotifications();
        } catch (error) {
          console.warn('[Notifications] Enregistrement impossible :', error.message);
        }
      }
    };

    register();
    return () => {
      cancelled = true;
    };
  }, [user?.id, requestLocation]);
}
