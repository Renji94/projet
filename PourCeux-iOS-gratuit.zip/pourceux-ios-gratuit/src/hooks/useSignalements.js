import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { signalementsService } from '../services/signalements.service';

export function useSignalementsList(filters = {}) {
  return useQuery({
    queryKey: ['signalements', filters],
    queryFn: () => signalementsService.list(filters),
  });
}

export function useSignalement(id) {
  return useQuery({
    queryKey: ['signalement', id],
    queryFn: () => signalementsService.getById(id),
    enabled: Boolean(id),
  });
}

export function useEvenementsProches(location, rayonKm) {
  return useQuery({
    queryKey: ['evenements-proches', location?.latitude, location?.longitude, rayonKm],
    queryFn: () =>
      signalementsService.getEvenementsProches(location.latitude, location.longitude, rayonKm),
    enabled: Boolean(location),
  });
}

export function useSignalementMutations(signalementId) {
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ['signalements'] });
    queryClient.invalidateQueries({ queryKey: ['signalement', signalementId] });
    queryClient.invalidateQueries({ queryKey: ['evenements-proches'] });
  };

  const creer = useMutation({
    mutationFn: (payload) => signalementsService.create(payload),
    onSuccess: invalidate,
  });

  const prendreEnCharge = useMutation({
    mutationFn: () => signalementsService.prendreEnCharge(signalementId),
    onSuccess: invalidate,
  });

  const cloturer = useMutation({
    mutationFn: (statut) => signalementsService.cloturer(signalementId, statut),
    onSuccess: invalidate,
  });

  const supprimer = useMutation({
    mutationFn: (id) => signalementsService.remove(id),
    onSuccess: invalidate,
  });

  return { creer, prendreEnCharge, cloturer, supprimer };
}