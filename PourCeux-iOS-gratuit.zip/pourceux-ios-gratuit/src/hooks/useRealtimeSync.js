import { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '../services/supabase';
import { useAuth } from '../contexts/AuthContext';

/**
 * Centralise les abonnements Realtime globaux afin d'éviter qu'un écran
 * ouvert plusieurs fois crée des canaux dupliqués.
 */
export function useRealtimeSync() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!user?.id) return undefined;

    const invalidateEvents = () => {
      queryClient.invalidateQueries({ queryKey: ['maraudes'] });
      queryClient.invalidateQueries({ queryKey: ['signalements'] });
      queryClient.invalidateQueries({ queryKey: ['evenements-proches'] });
    };

    const channel = supabase
      .channel(`global-events-${user.id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'maraudes' },
        invalidateEvents
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'signalements' },
        invalidateEvents
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'maraude_participants' },
        (payload) => {
          invalidateEvents();
          const maraudeId = payload.new?.maraude_id || payload.old?.maraude_id;
          if (maraudeId) {
            queryClient.invalidateQueries({ queryKey: ['maraude', maraudeId] });
            queryClient.invalidateQueries({ queryKey: ['participants', maraudeId] });
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'messages' },
        () => queryClient.invalidateQueries({ queryKey: ['conversations'] })
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, queryClient]);
}
