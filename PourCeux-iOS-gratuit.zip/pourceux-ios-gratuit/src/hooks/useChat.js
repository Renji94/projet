import { useState, useEffect, useCallback, useRef } from 'react';
import { chatService } from '../services/chat.service';
import { getFriendlyErrorMessage } from '../utils/friendlyError';
import { useAuth } from '../contexts/AuthContext';

const SEND_ERROR_MESSAGE = "Le message n'a pas pu être envoyé. Réessayez.";

export function useChat(chatId) {
  const { user, profile } = useAuth();
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);
  const messagesRef = useRef([]);

  useEffect(() => {
    if (!chatId) return undefined;
    let mounted = true;

    (async () => {
      try {
        const data = await chatService.getMessages(chatId);
        if (mounted) {
          messagesRef.current = data;
          setMessages(data);
          await chatService.markAsRead(chatId);
        }
      } catch (e) {
        if (mounted) setError(getFriendlyErrorMessage(e));
      } finally {
        if (mounted) setLoading(false);
      }
    })();

    const unsubscribe = chatService.subscribeToMessages(chatId, (updatedMessage, eventType) => {
      if (!mounted) return;
      if (eventType === 'UPDATE') {
        messagesRef.current = messagesRef.current.map((m) =>
          m.id === updatedMessage.id ? updatedMessage : m
        );
        setMessages(messagesRef.current);
        return;
      }
      // INSERT — éviter les doublons (le message envoyé localement est déjà présent)
      if (messagesRef.current.some((m) => m.id === updatedMessage.id)) return;
      messagesRef.current = [...messagesRef.current, updatedMessage];
      setMessages(messagesRef.current);
      chatService.markAsRead(chatId).catch(() => {});
    });

    return () => {
      mounted = false;
      unsubscribe();
    };
  }, [chatId]);

  // Reconstruit localement auteur/reply (mêmes champs que l'embed serveur)
  // à partir du contexte déjà connu, sans requête supplémentaire — l'envoi
  // ne dépend ainsi jamais de la résolution de la relation reply_to côté
  // PostgREST.
  const buildAuteur = useCallback(
    () => ({ id: user?.id, pseudo: profile?.pseudo, avatar_url: profile?.avatar_url }),
    [user?.id, profile?.pseudo, profile?.avatar_url]
  );

  const sendText = useCallback(
    async (contenu, replyToMessage = null) => {
      if (!contenu.trim()) return;
      setSending(true);
      setError(null);
      try {
        const data = await chatService.sendText(chatId, contenu, replyToMessage?.id ?? null);
        const message = {
          ...data,
          auteur: buildAuteur(),
          reply: replyToMessage
            ? {
                id: replyToMessage.id,
                contenu: replyToMessage.contenu,
                type: replyToMessage.type,
                is_deleted: replyToMessage.is_deleted,
                auteur: { pseudo: replyToMessage.auteur?.pseudo },
              }
            : null,
        };
        if (!messagesRef.current.some((m) => m.id === message.id)) {
          messagesRef.current = [...messagesRef.current, message];
          setMessages(messagesRef.current);
        }
      } catch (e) {
        setError(SEND_ERROR_MESSAGE);
        throw e;
      } finally {
        setSending(false);
      }
    },
    [chatId, buildAuteur]
  );

  const sendLocation = useCallback(
    async (latitude, longitude) => {
      setSending(true);
      setError(null);
      try {
        const data = await chatService.sendLocation(chatId, latitude, longitude);
        const message = { ...data, auteur: buildAuteur(), reply: null };
        if (!messagesRef.current.some((m) => m.id === message.id)) {
          messagesRef.current = [...messagesRef.current, message];
          setMessages(messagesRef.current);
        }
      } catch (e) {
        setError(SEND_ERROR_MESSAGE);
        throw e;
      } finally {
        setSending(false);
      }
    },
    [chatId, buildAuteur]
  );

  const deleteMessage = useCallback(async (messageId) => {
    await chatService.deleteMessage(messageId);
    messagesRef.current = messagesRef.current.map((m) =>
      m.id === messageId ? { ...m, is_deleted: true } : m
    );
    setMessages(messagesRef.current);
  }, []);

  return { messages, loading, sending, error, sendText, sendLocation, deleteMessage };
}