import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { maraudesService } from '../services/maraudes.service';
import { useAuth } from '../contexts/AuthContext';

export function useMaraudesList(filters = {}) {
  return useQuery({
    queryKey: ['maraudes', filters],
    queryFn: () => maraudesService.list(filters),
  });
}

export function useMaraude(id) {
  return useQuery({
    queryKey: ['maraude', id],
    queryFn: () => maraudesService.getById(id),
    enabled: Boolean(id),
  });
}

export function useParticipants(maraudeId) {
  return useQuery({
    queryKey: ['participants', maraudeId],
    queryFn: () => maraudesService.getParticipants(maraudeId),
    enabled: Boolean(maraudeId),
  });
}

export function useIsParticipant(maraudeId) {
  const { user } = useAuth();
  return useQuery({
    queryKey: ['isParticipant', maraudeId, user?.id],
    queryFn: () => maraudesService.isParticipant(maraudeId, user.id),
    enabled: Boolean(maraudeId && user?.id),
  });
}

export function useMaraudeMutations(maraudeId) {
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ['maraudes'] });
    queryClient.invalidateQueries({ queryKey: ['maraude', maraudeId] });
    queryClient.invalidateQueries({ queryKey: ['participants', maraudeId] });
    queryClient.invalidateQueries({ queryKey: ['isParticipant', maraudeId] });
    queryClient.invalidateQueries({ queryKey: ['evenements-proches'] });
  };

  const rejoindre = useMutation({
    mutationFn: () => maraudesService.rejoindre(maraudeId),
    onSuccess: invalidate,
  });

  const quitter = useMutation({
    mutationFn: () => maraudesService.quitter(maraudeId),
    onSuccess: invalidate,
  });

  const creer = useMutation({
    mutationFn: (payload) => maraudesService.create(payload),
    onSuccess: invalidate,
  });

  const modifier = useMutation({
    mutationFn: ({ id, payload }) => maraudesService.update(id, payload),
    onSuccess: invalidate,
  });

  const supprimer = useMutation({
    mutationFn: (id) => maraudesService.remove(id),
    onSuccess: invalidate,
  });

  const changerStatut = useMutation({
    mutationFn: ({ id, statut }) => maraudesService.setStatut(id, statut),
    onSuccess: invalidate,
  });

  return { rejoindre, quitter, creer, modifier, supprimer, changerStatut };
}