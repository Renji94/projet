import { useEffect } from 'react';
import { Platform } from 'react-native';
import { useQueryClient } from '@tanstack/react-query';
import { notificationsService } from '../services/notifications.service';
import { useAuth } from '../contexts/AuthContext';
import { openNotificationTarget } from '../navigation/navigationRef';

export function useNotifications() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!user?.id) return undefined;

    let responseSubscription;
    if (Platform.OS !== 'web') {
      notificationsService
        .consumeLastResponse()
        .then((data) => {
          if (data) setTimeout(() => openNotificationTarget(data), 0);
        })
        .catch((error) => console.warn('[Notifications] Réponse initiale illisible :', error.message));
      responseSubscription = notificationsService.addResponseListener(openNotificationTarget);
    }

    const unsubscribeRealtime = notificationsService.subscribeToUserNotifications(user.id, () => {
      queryClient.invalidateQueries({ queryKey: ['notifications', user.id] });
      queryClient.invalidateQueries({ queryKey: ['maraudes'] });
      queryClient.invalidateQueries({ queryKey: ['signalements'] });
    });

    return () => {
      responseSubscription?.remove();
      unsubscribeRealtime();
    };
  }, [user?.id, queryClient]);
}
