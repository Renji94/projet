import { useState, useEffect, useCallback, useRef } from 'react';
import * as Location from 'expo-location';

export function useLocation({ watch = false, autoRequest = true } = {}) {
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [loading, setLoading] = useState(autoRequest);
  const [permissionGranted, setPermissionGranted] = useState(false);
  const mountedRef = useRef(true);

  const requestLocation = useCallback(async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        if (mountedRef.current) {
          setPermissionGranted(false);
          setErrorMsg('Permission de localisation refusée.');
          setLoading(false);
        }
        return null;
      }

      const pos = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      const coords = {
        latitude: pos.coords.latitude,
        longitude: pos.coords.longitude,
      };
      if (mountedRef.current) {
        setPermissionGranted(true);
        setLocation(coords);
        setLoading(false);
      }
      return coords;
    } catch {
      if (mountedRef.current) {
        setErrorMsg('Impossible de récupérer votre position.');
        setLoading(false);
      }
      return null;
    }
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    let subscription;

    const initialize = async () => {
      if (!autoRequest) return;
      const coords = await requestLocation();
      if (watch && coords && mountedRef.current) {
        subscription = await Location.watchPositionAsync(
          {
            accuracy: Location.Accuracy.Balanced,
            timeInterval: 15000,
            distanceInterval: 50,
          },
          (pos) => {
            if (mountedRef.current) {
              setLocation({
                latitude: pos.coords.latitude,
                longitude: pos.coords.longitude,
              });
            }
          }
        );
      }
    };

    initialize();
    return () => {
      mountedRef.current = false;
      subscription?.remove();
    };
  }, [autoRequest, watch, requestLocation]);

  return { location, errorMsg, loading, permissionGranted, requestLocation };
}
