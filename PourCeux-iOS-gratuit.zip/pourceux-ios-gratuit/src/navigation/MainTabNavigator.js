import React, { useState } from 'react';
import { View, TouchableOpacity, Pressable, Animated, StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Portal, Modal, Text } from 'react-native-paper';
import { COLORS } from '../constants/colors';
import { SPACING, RADIUS, SHADOW } from '../styles/theme';
import { navigationRef } from './navigationRef';
import { useLocale } from '../contexts/LocaleContext';

import { MapScreen } from '../screens/map/MapScreen';
import { HomeScreen } from '../screens/home/HomeScreen';
import { MaraudesListScreen } from '../screens/maraudes/MaraudesListScreen';
import { MaraudeDetailScreen } from '../screens/maraudes/MaraudeDetailScreen';
import { MaraudeFormScreen } from '../screens/maraudes/MaraudeFormScreen';
import { SignalementsListScreen } from '../screens/signalements/SignalementsListScreen';
import { SignalementDetailScreen } from '../screens/signalements/SignalementDetailScreen';
import { SignalementFormScreen } from '../screens/signalements/SignalementFormScreen';
import { ChatScreen } from '../screens/chat/ChatScreen';
import { MessagesListScreen } from '../screens/messages/MessagesListScreen';
import { ProfileScreen } from '../screens/profile/ProfileScreen';
import { EditProfileScreen } from '../screens/profile/EditProfileScreen';
import { SettingsScreen } from '../screens/profile/SettingsScreen';
import { AdminDashboardScreen } from '../screens/admin/AdminDashboardScreen';
import { UsersManagementScreen } from '../screens/admin/UsersManagementScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const stackOptions = {
  headerStyle: { backgroundColor: 'transparent' },
  headerShadowVisible: false,
  headerTintColor: '#FFFFFF',
  headerTitleStyle: { fontWeight: '600' },
  contentStyle: { backgroundColor: 'transparent' },
};

function HomeStack() {
  return (
    <Stack.Navigator screenOptions={stackOptions}>
      <Stack.Screen name="HomeMain" component={HomeScreen} options={{ title: 'Accueil' }} />
      <Stack.Screen
        name="MaraudesList"
        component={MaraudesListScreen}
        options={{ title: 'Maraudes' }}
      />
      <Stack.Screen
        name="MaraudeDetail"
        component={MaraudeDetailScreen}
        options={{ title: 'Détail de la maraude' }}
      />
      <Stack.Screen
        name="MaraudeForm"
        component={MaraudeFormScreen}
        options={({ route }) => ({
          title: route.params?.maraude ? 'Modifier la maraude' : 'Nouvelle maraude',
        })}
      />
      <Stack.Screen
        name="SignalementsList"
        component={SignalementsListScreen}
        options={{ title: 'Signalements' }}
      />
      <Stack.Screen
        name="SignalementDetail"
        component={SignalementDetailScreen}
        options={{ title: 'Détail du signalement' }}
      />
      <Stack.Screen
        name="SignalementForm"
        component={SignalementFormScreen}
        options={{ title: 'Nouveau signalement' }}
      />
      <Stack.Screen
        name="Chat"
        component={ChatScreen}
        options={({ route }) => ({ title: route.params?.titre || 'Discussion' })}
      />
    </Stack.Navigator>
  );
}

function MapStack() {
  return (
    <Stack.Navigator screenOptions={stackOptions}>
      <Stack.Screen name="MapMain" component={MapScreen} options={{ title: 'Carte' }} />
      <Stack.Screen
        name="MaraudeDetail"
        component={MaraudeDetailScreen}
        options={{ title: 'Détail de la maraude' }}
      />
      <Stack.Screen
        name="SignalementDetail"
        component={SignalementDetailScreen}
        options={{ title: 'Détail du signalement' }}
      />
      <Stack.Screen
        name="MaraudeForm"
        component={MaraudeFormScreen}
        options={({ route }) => ({
          title: route.params?.maraude ? 'Modifier la maraude' : 'Nouvelle maraude',
        })}
      />
      <Stack.Screen
        name="Chat"
        component={ChatScreen}
        options={({ route }) => ({ title: route.params?.titre || 'Discussion' })}
      />
    </Stack.Navigator>
  );
}

// Onglet central "Créer" : jamais réellement affiché, le tabBarButton
// custom ci-dessous intercepte le tap pour ouvrir le menu au lieu de naviguer.
function CreerPlaceholder() {
  return null;
}

function CreateTabButton({ style, onPress }) {
  const [scale] = useState(() => new Animated.Value(1));

  const animateTo = (toValue) => {
    Animated.spring(scale, { toValue, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  };

  return (
    <View style={[style, createButtonStyles.wrapper]}>
      <Pressable
        onPress={onPress}
        onPressIn={() => animateTo(0.92)}
        onPressOut={() => animateTo(1)}
        accessibilityRole="button"
        accessibilityLabel="Créer une maraude ou un signalement"
      >
        <Animated.View style={[createButtonStyles.button, { transform: [{ scale }] }]}>
          <MaterialCommunityIcons name="plus" size={28} color={COLORS.primary} />
        </Animated.View>
      </Pressable>
    </View>
  );
}

const createButtonStyles = StyleSheet.create({
  wrapper: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: COLORS.secondary,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: -18,
    ...SHADOW.card,
  },
  modal: {
    margin: SPACING.lg,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.sm,
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.sm,
  },
  optionText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
  },
});

function MessagesStack() {
  return (
    <Stack.Navigator screenOptions={stackOptions}>
      <Stack.Screen
        name="MessagesList"
        component={MessagesListScreen}
        options={{ title: 'Messages' }}
      />
      <Stack.Screen
        name="Chat"
        component={ChatScreen}
        options={({ route }) => ({ title: route.params?.titre || 'Discussion' })}
      />
    </Stack.Navigator>
  );
}

function ProfileStack() {
  const { t } = useLocale();

  return (
    <Stack.Navigator screenOptions={stackOptions}>
      <Stack.Screen
        name="ProfileMain"
        component={ProfileScreen}
        options={{ title: 'Mon profil' }}
      />
      <Stack.Screen
        name="Settings"
        component={SettingsScreen}
        options={{ title: t('settings.title') }}
      />
      <Stack.Screen
        name="EditProfile"
        component={EditProfileScreen}
        options={{ title: 'Modifier mon profil' }}
      />
      <Stack.Screen
        name="AdminDashboard"
        component={AdminDashboardScreen}
        options={{ title: 'Administration' }}
      />
      <Stack.Screen
        name="UsersManagement"
        component={UsersManagementScreen}
        options={{ title: 'Utilisateurs' }}
      />
      <Stack.Screen
        name="MaraudeForm"
        component={MaraudeFormScreen}
        options={({ route }) => ({
          title: route.params?.maraude ? 'Modifier la maraude' : 'Nouvelle maraude',
        })}
      />
    </Stack.Navigator>
  );
}

const TAB_ICONS = {
  Accueil: 'home',
  Carte: 'map',
  Messages: 'message-text',
  Profil: 'account',
};

export function MainTabNavigator() {
  const [createMenuOpen, setCreateMenuOpen] = useState(false);
  const { t } = useLocale();

  const openForm = (screen, params) => {
    setCreateMenuOpen(false);
    navigationRef.navigate('Accueil', { screen, params });
  };

  return (
    <>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarStyle: { backgroundColor: 'transparent', elevation: 0, shadowOpacity: 0 },
          tabBarActiveTintColor: COLORS.secondary,
          tabBarInactiveTintColor: 'rgba(179, 227, 199, 0.5)',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name={TAB_ICONS[route.name]} size={size} color={color} />
          ),
        })}
      >
        <Tab.Screen
          name="Accueil"
          component={HomeStack}
          options={{ tabBarLabel: t('tabs.accueil') }}
        />
        <Tab.Screen name="Carte" component={MapStack} options={{ tabBarLabel: t('tabs.carte') }} />
        <Tab.Screen
          name="Creer"
          component={CreerPlaceholder}
          options={{
            tabBarButton: (props) => (
              <CreateTabButton style={props.style} onPress={() => setCreateMenuOpen(true)} />
            ),
          }}
        />
        <Tab.Screen
          name="Messages"
          component={MessagesStack}
          options={{ tabBarLabel: t('tabs.messages') }}
        />
        <Tab.Screen
          name="Profil"
          component={ProfileStack}
          options={{ tabBarLabel: t('tabs.profil') }}
        />
      </Tab.Navigator>

      <Portal>
        <Modal
          visible={createMenuOpen}
          onDismiss={() => setCreateMenuOpen(false)}
          contentContainerStyle={createButtonStyles.modal}
        >
          <TouchableOpacity
            style={createButtonStyles.option}
            onPress={() => openForm('MaraudeForm', {})}
          >
            <MaterialCommunityIcons name="walk" size={24} color={COLORS.primary} />
            <Text style={createButtonStyles.optionText}>Créer une maraude</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={createButtonStyles.option}
            onPress={() => openForm('SignalementForm')}
          >
            <MaterialCommunityIcons name="alert" size={24} color={COLORS.danger} />
            <Text style={createButtonStyles.optionText}>Créer un signalement</Text>
          </TouchableOpacity>
        </Modal>
      </Portal>
    </>
  );
}