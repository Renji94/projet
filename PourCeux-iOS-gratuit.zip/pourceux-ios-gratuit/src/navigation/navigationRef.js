import { createNavigationContainerRef } from '@react-navigation/native';

export const navigationRef = createNavigationContainerRef();
let pendingTarget = null;

function navigateToTarget(data = {}) {
  if (data.signalement_id) {
    navigationRef.navigate('Accueil', {
      screen: 'SignalementDetail',
      params: { id: data.signalement_id },
    });
    return;
  }

  if (data.maraude_id) {
    navigationRef.navigate('Accueil', {
      screen: 'MaraudeDetail',
      params: { id: data.maraude_id },
    });
  }
}

export function openNotificationTarget(data = {}) {
  if (!navigationRef.isReady()) {
    pendingTarget = data;
    return;
  }
  navigateToTarget(data);
}

export function flushPendingNotificationTarget() {
  if (!pendingTarget || !navigationRef.isReady()) return;
  const target = pendingTarget;
  pendingTarget = null;
  navigateToTarget(target);
}
