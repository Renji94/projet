import React from 'react';
import { View } from 'react-native';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { useAuth } from '../contexts/AuthContext';
import { AuthNavigator } from './AuthNavigator';
import { MainTabNavigator } from './MainTabNavigator';
import { LoadingScreen } from '../components/common/LoadingScreen';
import { AnimatedGradientBackground } from '../components/common/AnimatedGradientBackground';
import { useNotifications } from '../hooks/useNotifications';
import { useRealtimeSync } from '../hooks/useRealtimeSync';
import { useDeviceRegistration } from '../hooks/useDeviceRegistration';
import { ConfigurationScreen } from '../screens/system/ConfigurationScreen';
import { SuspendedScreen } from '../screens/system/SuspendedScreen';
import { ProfileErrorScreen } from '../screens/system/ProfileErrorScreen';
import { getMissingConfig } from '../constants/config';
import { flushPendingNotificationTarget, navigationRef } from './navigationRef';

const navigationTheme = {
  ...DefaultTheme,
  colors: { ...DefaultTheme.colors, background: 'transparent' },
};

function AuthenticatedApp() {
  useNotifications();
  useRealtimeSync();
  useDeviceRegistration();
  return <MainTabNavigator />;
}

export function RootNavigator() {
  const { session, profile, loading, isSuspended, error } = useAuth();

  let content;
  if (getMissingConfig().length > 0) {
    content = <ConfigurationScreen />;
  } else if (loading) {
    content = <LoadingScreen />;
  } else {
    content = (
      <NavigationContainer ref={navigationRef} theme={navigationTheme} onReady={flushPendingNotificationTarget}>
        {!session ? (
          <AuthNavigator />
        ) : error && !profile ? (
          <ProfileErrorScreen />
        ) : isSuspended ? (
          <SuspendedScreen />
        ) : (
          <AuthenticatedApp />
        )}
      </NavigationContainer>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <AnimatedGradientBackground />
      {content}
    </View>
  );
}
