import React from 'react';
import { View, StyleSheet, ScrollView, Linking } from 'react-native';
import { Text, Divider, IconButton, Menu } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Badge } from '../../components/common/Badge';
import { AppButton } from '../../components/common/AppButton';
import { LoadingScreen } from '../../components/common/LoadingScreen';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { ParticipantsList } from '../../components/maraudes/ParticipantsList';
import {
  useMaraude,
  useParticipants,
  useIsParticipant,
  useMaraudeMutations,
} from '../../hooks/useMaraudes';
import { useLocation } from '../../hooks/useLocation';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { useConfirm } from '../../contexts/ConfirmContext';
import { getFriendlyErrorMessage } from '../../utils/friendlyError';
import { COLORS } from '../../constants/colors';
import { MARAUDE_STATUTS, DIFFICULTES } from '../../constants/enums';
import { formatDate, formatHeure } from '../../utils/date';
import { getItineraireUrl } from '../../utils/geo';
import { SPACING, RADIUS, SHADOW } from '../../styles/theme';

export function MaraudeDetailScreen({ route, navigation }) {
  const { id } = route.params;
  const { isAdmin } = useAuth();
  const { location } = useLocation({ autoRequest: false });
  const toast = useToast();
  const confirm = useConfirm();

  const { data: maraude, isLoading, error } = useMaraude(id);
  const { data: participants } = useParticipants(id);
  const { data: isParticipant } = useIsParticipant(id);
  const { rejoindre, quitter, supprimer, changerStatut } = useMaraudeMutations(id);

  const [menuVisible, setMenuVisible] = React.useState(false);

  if (isLoading) return <LoadingScreen />;
  if (error || !maraude) {
    return (
      <View style={styles.errorContainer}>
        <ErrorMessage message={error?.message || 'Maraude introuvable.'} />
      </View>
    );
  }

  const statut = MARAUDE_STATUTS[maraude.statut];
  const difficulte = DIFFICULTES[maraude.difficulte];
  const complet = maraude.current_participants >= maraude.max_participants;
  const chatId = Array.isArray(maraude.chat) ? maraude.chat[0]?.id : maraude.chat?.id;
  const inscriptionOuverte = ['programmee', 'en_cours'].includes(maraude.statut);

  const handleRejoindre = () => {
    rejoindre.mutate(undefined, {
      onError: (e) => toast.showError(getFriendlyErrorMessage(e)),
    });
  };

  const handleQuitter = async () => {
    const ok = await confirm({
      title: 'Quitter la maraude',
      message: 'Êtes-vous sûr de vouloir quitter cette maraude ?',
      confirmLabel: 'Quitter',
      destructive: true,
    });
    if (!ok) return;
    quitter.mutate(undefined, {
      onError: (e) => toast.showError(getFriendlyErrorMessage(e)),
    });
  };

  const handleSupprimer = async () => {
    setMenuVisible(false);
    const ok = await confirm({
      title: 'Supprimer la maraude',
      message: 'Cette action est irréversible. Confirmer ?',
      confirmLabel: 'Supprimer',
      destructive: true,
    });
    if (!ok) return;
    supprimer.mutate(id, {
      onSuccess: () => navigation.goBack(),
      onError: (e) => toast.showError(getFriendlyErrorMessage(e)),
    });
  };

  const handleChangerStatut = (nouveauStatut) => {
    setMenuVisible(false);
    changerStatut.mutate(
      { id, statut: nouveauStatut },
      { onError: (e) => toast.showError(getFriendlyErrorMessage(e)) }
    );
  };

  const openItineraire = () => {
    const url = getItineraireUrl(
      maraude.latitude,
      maraude.longitude,
      location?.latitude,
      location?.longitude
    );
    Linking.openURL(url).catch(() => {});
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.card}>
        <View style={styles.headerRow}>
          <Text variant="headlineSmall" style={styles.titre}>
            {maraude.titre}
          </Text>
          {isAdmin && (
            <Menu
              visible={menuVisible}
              onDismiss={() => setMenuVisible(false)}
              anchor={
                <IconButton
                  icon="dots-vertical"
                  onPress={() => setMenuVisible(true)}
                  accessibilityLabel="Actions administrateur"
                />
              }
            >
              <Menu.Item
                leadingIcon="pencil"
                title="Modifier"
                onPress={() => {
                  setMenuVisible(false);
                  navigation.navigate('MaraudeForm', { maraude });
                }}
              />
              <Menu.Item
                leadingIcon="play"
                title="Marquer en cours"
                onPress={() => handleChangerStatut('en_cours')}
              />
              <Menu.Item
                leadingIcon="check"
                title="Marquer terminée"
                onPress={() => handleChangerStatut('terminee')}
              />
              <Menu.Item
                leadingIcon="cancel"
                title="Annuler"
                onPress={() => handleChangerStatut('annulee')}
              />
              <Divider />
              <Menu.Item leadingIcon="delete" title="Supprimer" onPress={handleSupprimer} />
            </Menu>
          )}
        </View>

        <View style={styles.badges}>
          <Badge label={statut.label} color={statut.color} />
          <Badge label={difficulte.label} color={difficulte.color} />
        </View>

        <Text style={styles.description}>{maraude.description}</Text>

        <Divider style={styles.divider} />

        <InfoRow icon="calendar" text={formatDate(maraude.date_maraude)} />
        <InfoRow
          icon="clock-outline"
          text={`${formatHeure(maraude.heure_debut)} – ${formatHeure(maraude.heure_fin)}`}
        />
        <InfoRow icon="map-marker" text={`${maraude.adresse}, ${maraude.ville}`} />
        <InfoRow
          icon="account-group"
          text={`${maraude.current_participants}/${maraude.max_participants} participants${
            complet ? ' (complet)' : ''
          }`}
        />
        <InfoRow icon="account" text={`Organisée par ${maraude.createur?.pseudo || 'Admin'}`} />

        {maraude.materiel_recommande?.length > 0 && (
          <>
            <Divider style={styles.divider} />
            <Text style={styles.sectionTitle}>Matériel recommandé</Text>
            {maraude.materiel_recommande.map((item, index) => (
              <InfoRow key={index} icon="check-circle-outline" text={item} />
            ))}
          </>
        )}
      </View>

      <View style={styles.actions}>
        {inscriptionOuverte && !isParticipant && !complet && (
          <AppButton onPress={handleRejoindre} loading={rejoindre.isPending} icon="account-plus">
            Rejoindre la maraude
          </AppButton>
        )}
        {isParticipant && (
          <AppButton
            mode="outlined"
            onPress={handleQuitter}
            loading={quitter.isPending}
            icon="account-minus"
            textColor={COLORS.danger}
          >
            Quitter la maraude
          </AppButton>
        )}
        {(isParticipant || isAdmin) && chatId && (
          <AppButton
            mode="contained-tonal"
            icon="chat"
            onPress={() => navigation.navigate('Chat', { chatId, titre: maraude.titre })}
          >
            Discuter
          </AppButton>
        )}
        <AppButton mode="outlined" icon="directions" onPress={openItineraire}>
          Itinéraire
        </AppButton>
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>
          Participants ({maraude.current_participants})
        </Text>
        <ParticipantsList participants={participants || []} />
      </View>
    </ScrollView>
  );
}

function InfoRow({ icon, text }) {
  return (
    <View style={styles.infoRow}>
      <MaterialCommunityIcons name={icon} size={18} color={COLORS.textSecondary} />
      <Text style={styles.infoText}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  errorContainer: {
    flex: 1,
    backgroundColor: 'transparent',
    padding: SPACING.md,
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    padding: SPACING.md,
    paddingBottom: SPACING.xl,
    gap: SPACING.md,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    ...SHADOW.card,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  titre: {
    flex: 1,
    fontWeight: '700',
    color: COLORS.text,
  },
  badges: {
    flexDirection: 'row',
    gap: SPACING.sm,
    marginVertical: SPACING.sm,
  },
  description: {
    color: COLORS.textSecondary,
    lineHeight: 20,
  },
  divider: {
    marginVertical: SPACING.md,
  },
  sectionTitle: {
    fontWeight: '700',
    color: COLORS.text,
    fontSize: 16,
    marginBottom: SPACING.sm,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: 6,
  },
  infoText: {
    color: COLORS.text,
    flex: 1,
  },
  actions: {
    gap: SPACING.sm,
  },
});