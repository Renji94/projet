import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Text, SegmentedButtons, Chip, TextInput } from 'react-native-paper';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { AppTextInput } from '../../components/common/AppTextInput';
import { AppButton } from '../../components/common/AppButton';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { useMaraudeMutations } from '../../hooks/useMaraudes';
import { geocodingService } from '../../services/geocoding.service';
import { maraudeSchema } from '../../utils/validation';
import { useToast } from '../../contexts/ToastContext';
import { getFriendlyErrorMessage } from '../../utils/friendlyError';
import { COLORS } from '../../constants/colors';
import { SPACING, RADIUS } from '../../styles/theme';

export function MaraudeFormScreen({ route, navigation }) {
  const existing = route.params?.maraude || null;
  const { creer, modifier } = useMaraudeMutations(existing?.id);
  const toast = useToast();

  const [error, setError] = useState(null);
  const [addressQuery, setAddressQuery] = useState('');
  const [addressResults, setAddressResults] = useState([]);
  const [searchingAddress, setSearchingAddress] = useState(false);
  const [materielInput, setMaterielInput] = useState('');

  const {
    control,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(maraudeSchema),
    defaultValues: existing
      ? {
          titre: existing.titre,
          description: existing.description,
          date_maraude: existing.date_maraude,
          heure_debut: existing.heure_debut?.slice(0, 5),
          heure_fin: existing.heure_fin?.slice(0, 5),
          ville: existing.ville,
          adresse: existing.adresse,
          latitude: existing.latitude,
          longitude: existing.longitude,
          max_participants: existing.max_participants,
          materiel_recommande: existing.materiel_recommande || [],
          difficulte: existing.difficulte,
        }
      : {
          titre: '',
          description: '',
          date_maraude: '',
          heure_debut: '',
          heure_fin: '',
          ville: '',
          adresse: '',
          latitude: undefined,
          longitude: undefined,
          max_participants: 10,
          materiel_recommande: [],
          difficulte: 'facile',
        },
  });

  const materiel = watch('materiel_recommande');
  const latitude = watch('latitude');
  const longitude = watch('longitude');

  const searchAddress = async () => {
    if (addressQuery.trim().length < 3) return;
    setSearchingAddress(true);
    try {
      const results = await geocodingService.search(addressQuery);
      setAddressResults(results);
      if (results.length === 0) {
        toast.showInfo('Aucune adresse trouvée pour cette recherche.');
      }
    } catch {
      toast.showError('Recherche d’adresse impossible. Vérifiez votre connexion.');
    } finally {
      setSearchingAddress(false);
    }
  };

  const selectAddress = (result) => {
    setValue('adresse', result.label);
    setValue('ville', result.ville || '');
    setValue('latitude', result.latitude);
    setValue('longitude', result.longitude);
    setAddressResults([]);
    setAddressQuery('');
  };

  const addMateriel = () => {
    const item = materielInput.trim();
    if (!item) return;
    setValue('materiel_recommande', [...materiel, item]);
    setMaterielInput('');
  };

  const removeMateriel = (index) => {
    setValue(
      'materiel_recommande',
      materiel.filter((_, i) => i !== index)
    );
  };

  const onSubmit = (values) => {
    setError(null);
    const payload = {
      ...values,
      max_participants: Number(values.max_participants),
    };

    const mutation = existing ? modifier : creer;
    const args = existing ? { id: existing.id, payload } : payload;

    mutation.mutate(args, {
      onSuccess: () => {
        toast.showSuccess(existing ? 'Maraude modifiée.' : 'Maraude créée.');
        navigation.goBack();
      },
      onError: (e) => setError(getFriendlyErrorMessage(e)),
    });
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <ErrorMessage message={error} />

      <AppTextInput control={control} name="titre" label="Titre *" error={errors.titre} />
      <AppTextInput
        control={control}
        name="description"
        label="Description *"
        multiline
        numberOfLines={4}
        error={errors.description}
      />
      <AppTextInput
        control={control}
        name="date_maraude"
        label="Date (AAAA-MM-JJ) *"
        placeholder="2026-08-15"
        error={errors.date_maraude}
      />
      <View style={styles.row}>
        <View style={styles.half}>
          <AppTextInput
            control={control}
            name="heure_debut"
            label="Début (HH:MM) *"
            placeholder="19:00"
            error={errors.heure_debut}
          />
        </View>
        <View style={styles.half}>
          <AppTextInput
            control={control}
            name="heure_fin"
            label="Fin (HH:MM) *"
            placeholder="22:00"
            error={errors.heure_fin}
          />
        </View>
      </View>

      <Text style={styles.sectionTitle}>Lieu</Text>
      <View style={styles.searchRow}>
        <TextInput
          style={styles.searchInput}
          mode="outlined"
          label="Rechercher une adresse"
          value={addressQuery}
          onChangeText={setAddressQuery}
          dense
        />
        <AppButton
          mode="contained-tonal"
          onPress={searchAddress}
          loading={searchingAddress}
          compact
        >
          Chercher
        </AppButton>
      </View>

      {addressResults.map((result, index) => (
        <TouchableOpacity
          key={index}
          style={styles.addressResult}
          onPress={() => selectAddress(result)}
        >
          <Text numberOfLines={2}>{result.label}</Text>
        </TouchableOpacity>
      ))}

      <AppTextInput control={control} name="adresse" label="Adresse *" error={errors.adresse} />
      <AppTextInput control={control} name="ville" label="Ville *" error={errors.ville} />

      {latitude != null && longitude != null ? (
        <Text style={styles.coords}>
          GPS : {Number(latitude).toFixed(5)}, {Number(longitude).toFixed(5)}
        </Text>
      ) : (
        <Text style={styles.coordsMissing}>
          Coordonnées GPS requises — utilisez la recherche d’adresse.
        </Text>
      )}
      {errors.latitude && <ErrorMessage message="Position GPS requise." />}

      <Text style={styles.sectionTitle}>Participants maximum *</Text>
      <Controller
        control={control}
        name="max_participants"
        render={({ field: { onChange, value } }) => (
          <TextInput
            style={styles.searchInput}
            mode="outlined"
            keyboardType="number-pad"
            value={String(value ?? '')}
            onChangeText={(text) => onChange(text ? parseInt(text, 10) : undefined)}
            error={Boolean(errors.max_participants)}
          />
        )}
      />
      {errors.max_participants && (
        <Text style={styles.errorText}>{errors.max_participants.message}</Text>
      )}

      <Text style={styles.sectionTitle}>Difficulté</Text>
      <Controller
        control={control}
        name="difficulte"
        render={({ field: { onChange, value } }) => (
          <SegmentedButtons
            value={value}
            onValueChange={onChange}
            buttons={[
              { value: 'facile', label: 'Facile' },
              { value: 'moyen', label: 'Moyen' },
              { value: 'difficile', label: 'Difficile' },
            ]}
          />
        )}
      />

      <Text style={styles.sectionTitle}>Matériel recommandé</Text>
      <View style={styles.searchRow}>
        <TextInput
          style={styles.searchInput}
          mode="outlined"
          label="Ajouter du matériel"
          value={materielInput}
          onChangeText={setMaterielInput}
          dense
          onSubmitEditing={addMateriel}
        />
        <AppButton mode="contained-tonal" onPress={addMateriel} compact>
          Ajouter
        </AppButton>
      </View>
      <View style={styles.chips}>
        {materiel.map((item, index) => (
          <Chip key={index} onClose={() => removeMateriel(index)} style={styles.chip}>
            {item}
          </Chip>
        ))}
      </View>

      <AppButton
        onPress={handleSubmit(onSubmit)}
        loading={creer.isPending || modifier.isPending}
        style={styles.submit}
      >
        {existing ? 'Enregistrer les modifications' : 'Créer la maraude'}
      </AppButton>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    padding: SPACING.md,
    paddingBottom: SPACING.xl,
  },
  row: {
    flexDirection: 'row',
    gap: SPACING.sm,
  },
  half: {
    flex: 1,
  },
  sectionTitle: {
    fontWeight: '700',
    color: COLORS.textOnDark,
    marginTop: SPACING.md,
    marginBottom: SPACING.sm,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.sm,
  },
  searchInput: {
    flex: 1,
    backgroundColor: COLORS.surface,
  },
  addressResult: {
    backgroundColor: COLORS.surface,
    padding: SPACING.md,
    borderRadius: RADIUS.sm,
    marginBottom: SPACING.xs,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  coords: {
    color: COLORS.success,
    fontSize: 13,
    marginBottom: SPACING.sm,
  },
  coordsMissing: {
    color: COLORS.warning,
    fontSize: 13,
    marginBottom: SPACING.sm,
  },
  errorText: {
    color: COLORS.danger,
    fontSize: 12,
    marginTop: 4,
  },
  chips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm,
    marginTop: SPACING.sm,
  },
  chip: {
    backgroundColor: COLORS.primaryLight,
  },
  submit: {
    marginTop: SPACING.lg,
  },
});