import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { View, StyleSheet, FlatList, RefreshControl, LayoutAnimation } from 'react-native';
import { Searchbar, Chip } from 'react-native-paper';
import * as Location from 'expo-location';
import { MaraudeCard } from '../../components/maraudes/MaraudeCard';
import { EmptyState } from '../../components/common/EmptyState';
import { SkeletonList } from '../../components/common/SkeletonListItem';
import { SortBar } from '../../components/common/SortBar';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { useMaraudesList } from '../../hooks/useMaraudes';
import { useLocation } from '../../hooks/useLocation';
import { getPreference, setPreference } from '../../services/localPreferences';
import { sortMaraudesByProximity } from '../../utils/geo';
import { COLORS } from '../../constants/colors';
import { MARAUDE_STATUTS } from '../../constants/enums';
import { SPACING } from '../../styles/theme';

const SORT_STORAGE_KEY = 'maraudes-sort-mode';

const SORT_OPTIONS = [
  { value: 'proximite', label: 'Plus proches', icon: 'crosshairs-gps' },
  { value: 'bientot', label: 'Bientôt', icon: 'calendar-clock' },
  { value: 'recentes', label: 'Plus récentes', icon: 'clock-outline' },
];

export function MaraudesListScreen({ navigation }) {
  const [ville, setVille] = useState('');
  const [statut, setStatut] = useState(null);
  const [sortMode, setSortMode] = useState(null); // null = pas encore déterminé
  const [lastKnownLocation, setLastKnownLocation] = useState(null);
  const [sortPreferenceLoaded, setSortPreferenceLoaded] = useState(false);
  const [initialSortDone, setInitialSortDone] = useState(false);

  const { location, loading: locationLoading, requestLocation } = useLocation();

  const { data: maraudes, isLoading, error, refetch, isRefetching } = useMaraudesList({
    statut,
    ville,
  });

  // Dernière position connue (rapide, en cache) — permet de déterminer le tri
  // initial avant même la fin de la récupération ponctuelle standard.
  useEffect(() => {
    let mounted = true;
    Location.getLastKnownPositionAsync()
      .then((pos) => {
        if (mounted && pos) {
          setLastKnownLocation({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
          });
        }
      })
      .catch(() => {});
    return () => {
      mounted = false;
    };
  }, []);

  // Charge un éventuel tri choisi manuellement au préalable (persisté) —
  // si présent, aucune logique automatique ne s'applique ensuite.
  useEffect(() => {
    let mounted = true;
    getPreference(SORT_STORAGE_KEY, null).then((stored) => {
      if (!mounted) return;
      if (stored) {
        setInitialSortDone(true);
        setSortMode(stored);
      }
      setSortPreferenceLoaded(true);
    });
    return () => {
      mounted = false;
    };
  }, []);

  const effectiveLocation = location || lastKnownLocation;

  // Détermine le tri par défaut une seule fois : "Plus proches" dès qu'une
  // position (cache ou fraîche) est connue, sinon "Bientôt" une fois la
  // tentative de localisation terminée. Dérivé pendant le rendu (pattern
  // recommandé par React pour ce cas plutôt qu'un effect qui déclencherait
  // un setState synchrone) — ne s'exécute jamais après un choix manuel ou
  // une préférence persistée déjà chargée.
  if (sortPreferenceLoaded && !initialSortDone) {
    if (effectiveLocation) {
      setInitialSortDone(true);
      setSortMode('proximite');
    } else if (!locationLoading) {
      setInitialSortDone(true);
      setSortMode('bientot');
    }
  }

  const handleSortChange = useCallback(
    (mode) => {
      LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
      setInitialSortDone(true);
      setSortMode(mode);
      setPreference(SORT_STORAGE_KEY, mode);
      if (mode === 'proximite' && !effectiveLocation) {
        requestLocation();
      }
    },
    [effectiveLocation, requestLocation]
  );

  const sortedMaraudes = useMemo(() => {
    if (!maraudes) return [];
    return sortMaraudesByProximity(maraudes, sortMode || 'bientot', effectiveLocation);
  }, [maraudes, sortMode, effectiveLocation]);

  if (isLoading) {
    return (
      <View style={styles.container}>
        <SkeletonList count={5} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {error ? <View style={styles.error}><ErrorMessage message={error.message} /></View> : null}
      <Searchbar
        placeholder="Rechercher par ville…"
        value={ville}
        onChangeText={setVille}
        style={styles.search}
      />

      <View style={styles.filters}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={Object.entries(MARAUDE_STATUTS)}
          keyExtractor={([key]) => key}
          contentContainerStyle={styles.chipRow}
          renderItem={({ item: [key, config] }) => (
            <Chip
              selected={statut === key}
              onPress={() => setStatut(statut === key ? null : key)}
              style={[styles.chip, statut === key && { backgroundColor: config.color }]}
              textStyle={statut === key ? styles.chipTextSelected : undefined}
            >
              {config.label}
            </Chip>
          )}
        />
      </View>

      <View style={styles.sortRow}>
        <SortBar value={sortMode || 'bientot'} onChange={handleSortChange} options={SORT_OPTIONS} />
      </View>

      <FlatList
        data={sortedMaraudes}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <MaraudeCard
            maraude={item}
            distanceKm={item.distanceKm}
            onPress={() => navigation.navigate('MaraudeDetail', { id: item.id })}
          />
        )}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={refetch} />}
        ListEmptyComponent={
          <EmptyState
            icon="walk"
            title="Aucune maraude"
            subtitle="Aucune maraude ne correspond à vos critères."
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  error: {
    paddingHorizontal: SPACING.md,
  },
  search: {
    margin: SPACING.md,
    marginBottom: SPACING.xs,
    backgroundColor: COLORS.surface,
  },
  filters: {
    marginBottom: SPACING.xs,
  },
  chipRow: {
    paddingHorizontal: SPACING.md,
    gap: SPACING.sm,
  },
  chip: {
    backgroundColor: COLORS.surface,
  },
  chipTextSelected: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  sortRow: {
    marginBottom: SPACING.sm,
  },
  list: {
    paddingBottom: SPACING.lg,
    flexGrow: 1,
  },
});
