import React from 'react';
import { Linking, ScrollView, StyleSheet, View } from 'react-native';
import { Text } from 'react-native-paper';
import { AppButton } from '../../components/common/AppButton';
import { COLORS } from '../../constants/colors';
import { SPACING } from '../../styles/theme';

export function MapScreen() {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text variant="headlineSmall" style={styles.title}>Carte disponible sur mobile</Text>
      <Text style={styles.body}>
        La V0 utilise MapLibre et les tuiles OpenStreetMap sur Android et iOS. La version web conserve l'accès aux autres écrans, mais n'embarque pas de carte interactive.
      </Text>
      <AppButton
        icon="open-in-new"
        onPress={() => Linking.openURL('https://www.openstreetmap.org')}
      >
        Ouvrir OpenStreetMap
      </AppButton>
      <View style={styles.attribution}><Text>© contributeurs OpenStreetMap</Text></View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  content: { flexGrow: 1, justifyContent: 'center', gap: SPACING.lg, padding: SPACING.xl },
  title: { color: COLORS.textOnDark, fontWeight: '700' },
  body: { color: COLORS.textOnDarkSecondary, lineHeight: 22 },
  attribution: { marginTop: SPACING.md },
});
