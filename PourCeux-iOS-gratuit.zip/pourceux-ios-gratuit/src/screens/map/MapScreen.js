import React, { useState, useRef, useCallback, useEffect } from 'react';
import { View, StyleSheet, TouchableOpacity, Keyboard, ActivityIndicator } from 'react-native';
import { Searchbar, IconButton, Text, Portal, Modal } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { MapWebView } from '../../components/map/MapWebView';
import { MapFilters } from '../../components/map/MapFilters';
import { Badge } from '../../components/common/Badge';
import { AppButton } from '../../components/common/AppButton';
import { useLocation } from '../../hooks/useLocation';
import { useEvenementsProches } from '../../hooks/useSignalements';
import { geocodingService } from '../../services/geocoding.service';
import { CONFIG } from '../../constants/config';
import { COLORS } from '../../constants/colors';
import { URGENCES } from '../../constants/enums';
import { toLngLat } from '../../utils/geo';
import { SPACING, RADIUS, SHADOW } from '../../styles/theme';

const ZOOM_USER = 14;
const ZOOM_SEARCH = 13;
const MAP_LOAD_TIMEOUT_MS = 15000;

export function MapScreen({ navigation }) {
  const mapRef = useRef(null);
  const hasCenteredOnUser = useRef(false);
  const { location, errorMsg: locationError, requestLocation } = useLocation({ watch: true });

  const [filters, setFilters] = useState({
    showMaraudes: true,
    showSignalements: true,
    urgence: null,
    rayonKm: CONFIG.DEFAULT_RADIUS_KM,
  });
  const [filtersVisible, setFiltersVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searchCenter, setSearchCenter] = useState(null);
  const [selectedEvent, setSelectedEvent] = useState(null);

  const [mapKey, setMapKey] = useState(0);
  const [mapReady, setMapReady] = useState(false);
  const [mapError, setMapError] = useState(null);
  const mapReadyRef = useRef(false);

  const center = searchCenter || location;
  const { data: evenements } = useEvenementsProches(center, filters.rayonKm);

  const maraudes = filters.showMaraudes ? evenements?.maraudes || [] : [];
  const signalements = (filters.showSignalements ? evenements?.signalements || [] : []).filter(
    (s) => !filters.urgence || s.urgence === filters.urgence
  );

  const eventsById = {};
  maraudes.forEach((m) => { eventsById[`maraude-${m.id}`] = { ...m, type: 'maraude' }; });
  signalements.forEach((s) => { eventsById[`signalement-${s.id}`] = { ...s, type: 'signalement' }; });

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!mapReadyRef.current) {
        setMapError('Le chargement de la carte prend plus de temps que prévu.');
      }
    }, MAP_LOAD_TIMEOUT_MS);
    return () => clearTimeout(timer);
  }, [mapKey]);

  useEffect(() => {
    if (!location || hasCenteredOnUser.current) return;
    hasCenteredOnUser.current = true;
    mapRef.current?.flyTo({ center: toLngLat(location.latitude, location.longitude), zoom: ZOOM_USER });
  }, [location]);

  const handleSearch = useCallback(async () => {
    if (searchQuery.trim().length < 3) return;
    Keyboard.dismiss();
    try {
      const results = await geocodingService.search(searchQuery);
      setSearchResults(results);
    } catch {
      setSearchResults([]);
    }
  }, [searchQuery]);

  const selectSearchResult = (result) => {
    setSearchResults([]);
    setSearchQuery(result.label);
    setSearchCenter({ latitude: result.latitude, longitude: result.longitude });
    mapRef.current?.flyTo({ center: toLngLat(result.latitude, result.longitude), zoom: ZOOM_SEARCH });
  };

  const centerOnUser = () => {
    if (!location) return;
    setSearchCenter(null);
    mapRef.current?.flyTo({ center: toLngLat(location.latitude, location.longitude), zoom: ZOOM_USER });
  };

  const handleRetryMap = () => {
    mapReadyRef.current = false;
    setMapReady(false);
    setMapError(null);
    setMapKey((k) => k + 1);
  };

  const handleMarkerPress = (kind, id) => {
    const event = eventsById[`${kind}-${id}`];
    if (event) setSelectedEvent(event);
  };

  return (
    <View style={styles.container}>
      <MapWebView
        key={mapKey}
        ref={mapRef}
        userLocation={location}
        maraudes={maraudes}
        signalements={signalements}
        onReady={() => {
          mapReadyRef.current = true;
          setMapReady(true);
          setMapError(null);
        }}
        onError={(message) => setMapError(message)}
        onMarkerPress={handleMarkerPress}
      />

      {!mapReady && (
        <View style={styles.mapOverlay} pointerEvents="box-none">
          {mapError ? (
            <View style={styles.mapOverlayCard}>
              <MaterialCommunityIcons name="map-marker-alert" size={40} color={COLORS.textOnDark} />
              <Text style={styles.mapOverlayText}>{mapError}</Text>
              <AppButton onPress={handleRetryMap}>Réessayer</AppButton>
            </View>
          ) : (
            <View style={styles.mapOverlayCard}>
              <ActivityIndicator size="large" color={COLORS.textOnDark} />
              <Text style={styles.mapOverlayText}>Chargement de la carte…</Text>
            </View>
          )}
        </View>
      )}

      {/* Barre de recherche */}
      <View style={styles.searchContainer}>
        <Searchbar
          placeholder="Rechercher une ville ou une adresse…"
          value={searchQuery}
          onChangeText={setSearchQuery}
          onSubmitEditing={handleSearch}
          onIconPress={handleSearch}
          style={styles.search}
        />
        {searchResults.map((result, index) => (
          <TouchableOpacity
            key={index}
            style={styles.searchResult}
            onPress={() => selectSearchResult(result)}
          >
            <MaterialCommunityIcons name="map-marker" size={16} color={COLORS.primary} />
            <Text numberOfLines={1} style={styles.searchResultText}>
              {result.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {locationError ? (
        <TouchableOpacity style={styles.locationError} onPress={requestLocation}>
          <MaterialCommunityIcons name="crosshairs-question" size={18} color={COLORS.danger} />
          <Text style={styles.locationErrorText}>{locationError} Appuyez pour réessayer.</Text>
        </TouchableOpacity>
      ) : null}

      {/* Boutons flottants */}
      <View style={styles.buttons}>
        <IconButton
          icon="filter-variant"
          mode="contained"
          containerColor={COLORS.surface}
          iconColor={COLORS.primary}
          size={26}
          onPress={() => setFiltersVisible(true)}
          style={SHADOW.card}
          accessibilityLabel="Filtres"
        />
        <IconButton
          icon="crosshairs-gps"
          mode="contained"
          containerColor={COLORS.surface}
          iconColor={COLORS.primary}
          size={26}
          onPress={centerOnUser}
          style={SHADOW.card}
          accessibilityLabel="Centrer sur ma position"
        />
      </View>

      {/* Légende */}
      <View style={styles.legend}>
        <View style={styles.legendItem}>
          <View style={[styles.legendDot, { backgroundColor: COLORS.markerMaraude }]} />
          <Text style={styles.legendText}>Maraudes ({maraudes.length})</Text>
        </View>
        <View style={styles.legendItem}>
          <View style={[styles.legendDot, { backgroundColor: COLORS.markerSignalement }]} />
          <Text style={styles.legendText}>Signalements ({signalements.length})</Text>
        </View>
      </View>

      {/* Modal filtres */}
      <Portal>
        <Modal
          visible={filtersVisible}
          onDismiss={() => setFiltersVisible(false)}
          contentContainerStyle={styles.modal}
        >
          <MapFilters filters={filters} onChange={setFilters} />
        </Modal>
      </Portal>

      {/* Info-bulle événement */}
      <Portal>
        <Modal
          visible={!!selectedEvent}
          onDismiss={() => setSelectedEvent(null)}
          contentContainerStyle={styles.previewModal}
        >
          {selectedEvent && (
            <View>
              <View style={styles.previewHeader}>
                <Text variant="titleMedium" style={styles.previewTitle} numberOfLines={2}>
                  {selectedEvent.titre}
                </Text>
                <Badge
                  label={selectedEvent.type === 'maraude' ? 'Maraude' : 'Signalement'}
                  color={
                    selectedEvent.type === 'maraude'
                      ? COLORS.markerMaraude
                      : COLORS.markerSignalement
                  }
                  small
                />
              </View>

              {selectedEvent.adresse ? (
                <View style={styles.previewRow}>
                  <MaterialCommunityIcons
                    name="map-marker"
                    size={16}
                    color={COLORS.textSecondary}
                  />
                  <Text style={styles.previewText}>{selectedEvent.adresse}</Text>
                </View>
              ) : null}

              {selectedEvent.type === 'signalement' && selectedEvent.urgence ? (
                <Badge
                  label={`Urgence : ${URGENCES[selectedEvent.urgence]?.label || selectedEvent.urgence}`}
                  color={URGENCES[selectedEvent.urgence]?.color || COLORS.markerSignalement}
                  small
                />
              ) : null}

              <AppButton
                style={styles.previewButton}
                onPress={() => {
                  const target =
                    selectedEvent.type === 'maraude' ? 'MaraudeDetail' : 'SignalementDetail';
                  const id = selectedEvent.id;
                  setSelectedEvent(null);
                  navigation.navigate(target, { id });
                }}
              >
                Voir le détail
              </AppButton>
            </View>
          )}
        </Modal>
      </Portal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  mapOverlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapOverlayCard: {
    alignItems: 'center',
    gap: SPACING.sm,
    padding: SPACING.lg,
  },
  mapOverlayText: {
    color: COLORS.textOnDark,
    textAlign: 'center',
  },
  searchContainer: {
    position: 'absolute',
    top: SPACING.md,
    left: SPACING.md,
    right: SPACING.md,
  },
  search: {
    backgroundColor: COLORS.surface,
    ...SHADOW.card,
  },
  searchResult: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: COLORS.surface,
    padding: SPACING.md,
    borderRadius: RADIUS.sm,
    marginTop: SPACING.xs,
    ...SHADOW.card,
  },
  searchResultText: {
    flex: 1,
    fontSize: 13,
  },
  locationError: {
    position: 'absolute',
    top: 82,
    left: SPACING.md,
    right: SPACING.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.sm,
    padding: SPACING.sm,
    ...SHADOW.card,
  },
  locationErrorText: {
    flex: 1,
    color: COLORS.danger,
    fontSize: 12,
  },
  buttons: {
    position: 'absolute',
    right: SPACING.md,
    bottom: 100,
    gap: SPACING.sm,
  },
  legend: {
    position: 'absolute',
    left: SPACING.md,
    bottom: SPACING.md,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.sm,
    gap: 4,
    ...SHADOW.card,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  legendDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  legendText: {
    fontSize: 12,
    color: COLORS.text,
  },
  modal: {
    margin: SPACING.lg,
  },
  previewModal: {
    margin: SPACING.lg,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
  },
  previewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
    gap: 8,
  },
  previewTitle: {
    flex: 1,
    fontWeight: '700',
    color: COLORS.text,
  },
  previewRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: SPACING.sm,
  },
  previewText: {
    flex: 1,
    color: COLORS.textSecondary,
    fontSize: 13,
  },
  previewButton: {
    marginTop: SPACING.md,
  },
});
