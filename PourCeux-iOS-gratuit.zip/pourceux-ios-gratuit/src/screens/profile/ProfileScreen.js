import React from 'react';
import { View, StyleSheet, ScrollView, RefreshControl } from 'react-native';
import { Text, Avatar, Divider } from 'react-native-paper';
import { useQuery } from '@tanstack/react-query';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { AppButton } from '../../components/common/AppButton';
import { Badge } from '../../components/common/Badge';
import { LoadingScreen } from '../../components/common/LoadingScreen';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { useAuth } from '../../contexts/AuthContext';
import { useConfirm } from '../../contexts/ConfirmContext';
import { useLocale } from '../../contexts/LocaleContext';
import { profilesService } from '../../services/profiles.service';
import { COLORS } from '../../constants/colors';
import { MARAUDE_STATUTS } from '../../constants/enums';
import { formatDate } from '../../utils/date';
import { SPACING, RADIUS, SHADOW } from '../../styles/theme';

export function ProfileScreen({ navigation }) {
  const { user, profile, isAdmin, signOut, refreshProfile } = useAuth();
  const confirm = useConfirm();
  const { t } = useLocale();

  const { data: stats, error: statsError, refetch: refetchStats } = useQuery({
    queryKey: ['profile-stats', user?.id],
    queryFn: () => profilesService.getStats(user.id),
    enabled: Boolean(user?.id),
  });

  const {
    data: historique,
    refetch: refetchHistorique,
    isRefetching,
    error: historiqueError,
  } = useQuery({
    queryKey: ['profile-historique', user?.id],
    queryFn: () => profilesService.getHistorique(user.id),
    enabled: Boolean(user?.id),
  });

  const onRefresh = () => {
    refreshProfile();
    refetchStats();
    refetchHistorique();
  };

  const handleSignOut = async () => {
    const ok = await confirm({
      title: t('profile.signOutDialog.title'),
      message: t('profile.signOutDialog.message'),
      confirmLabel: t('profile.signOutDialog.confirm'),
      destructive: true,
    });
    if (ok) signOut();
  };

  if (!profile) return <LoadingScreen />;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={onRefresh} />}
    >
      {statsError || historiqueError ? (
        <ErrorMessage message={(statsError || historiqueError).message} />
      ) : null}
      <View style={styles.card}>
        <View style={styles.header}>
          {profile.avatar_url ? (
            <Avatar.Image size={72} source={{ uri: profile.avatar_url }} />
          ) : (
            <Avatar.Text
              size={72}
              label={(profile.pseudo || '?').slice(0, 2).toUpperCase()}
              style={{ backgroundColor: COLORS.primaryLight }}
              labelStyle={{ color: COLORS.primary }}
            />
          )}
          <View style={styles.headerInfo}>
            <Text variant="titleLarge" style={styles.pseudo}>
              {profile.pseudo}
            </Text>
            <Text style={styles.name}>
              {profile.prenom} {profile.nom}
            </Text>
            {isAdmin && <Badge label="Administrateur" color={COLORS.secondary} small />}
          </View>
        </View>

        <Divider style={styles.divider} />

        <InfoRow icon="map-marker" text={profile.ville} />
        {profile.telephone ? <InfoRow icon="phone" text={profile.telephone} /> : null}
        <InfoRow icon="email" text={user?.email || ''} />
      </View>

      <View style={styles.statsRow}>
        <StatCard
          icon="walk"
          value={stats?.nb_maraudes ?? 0}
          label={t('profile.stats.maraudes')}
          color={COLORS.primary}
        />
        <StatCard
          icon="alert-circle"
          value={stats?.nb_signalements ?? 0}
          label={t('profile.stats.signalements')}
          color={COLORS.danger}
        />
        <StatCard
          icon="hand-heart"
          value={stats?.nb_prises_en_charge ?? 0}
          label={t('profile.stats.prisesEnCharge')}
          color={COLORS.success}
        />
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>{t('profile.history.title')}</Text>
        {!historique || historique.length === 0 ? (
          <Text style={styles.empty}>{t('profile.history.empty')}</Text>
        ) : (
          historique.map((item, index) => {
            const maraude = item.maraudes;
            if (!maraude) return null;
            const statut = MARAUDE_STATUTS[maraude.statut];
            return (
              <View key={index} style={styles.historiqueItem}>
                <View style={styles.historiqueInfo}>
                  <Text style={styles.historiqueTitre} numberOfLines={1}>
                    {maraude.titre}
                  </Text>
                  <Text style={styles.historiqueDetails}>
                    {formatDate(maraude.date_maraude)} · {maraude.ville}
                  </Text>
                </View>
                <Badge label={statut.label} color={statut.color} small />
              </View>
            );
          })
        )}
      </View>

      <View style={styles.actions}>
        <AppButton icon="pencil" onPress={() => navigation.navigate('EditProfile')}>
          {t('profile.editProfile')}
        </AppButton>
        <AppButton
          mode="outlined"
          icon="cog-outline"
          onPress={() => navigation.navigate('Settings')}
        >
          {t('profile.settings')}
        </AppButton>
        {isAdmin ? (
          <AppButton
            mode="outlined"
            icon="shield-account"
            onPress={() => navigation.navigate('AdminDashboard')}
          >
            {t('profile.administration')}
          </AppButton>
        ) : null}
        <AppButton
          mode="outlined"
          icon="logout"
          textColor={COLORS.danger}
          onPress={handleSignOut}
        >
          {t('profile.signOut')}
        </AppButton>
      </View>
    </ScrollView>
  );
}

function InfoRow({ icon, text }) {
  return (
    <View style={styles.infoRow}>
      <MaterialCommunityIcons name={icon} size={18} color={COLORS.textSecondary} />
      <Text style={styles.infoText}>{text}</Text>
    </View>
  );
}

function StatCard({ icon, value, label, color }) {
  return (
    <View style={styles.statCard}>
      <MaterialCommunityIcons name={icon} size={28} color={color} />
      <Text style={[styles.statValue, { color }]}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    padding: SPACING.md,
    paddingBottom: SPACING.xl,
    gap: SPACING.md,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    ...SHADOW.card,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
  },
  headerInfo: {
    flex: 1,
    gap: 4,
  },
  pseudo: {
    fontWeight: '700',
    color: COLORS.text,
  },
  name: {
    color: COLORS.textSecondary,
  },
  divider: {
    marginVertical: SPACING.md,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: 6,
  },
  infoText: {
    color: COLORS.text,
    flex: 1,
  },
  statsRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
  },
  statCard: {
    flex: 1,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    alignItems: 'center',
    gap: 4,
    ...SHADOW.card,
  },
  statValue: {
    fontSize: 22,
    fontWeight: '700',
  },
  statLabel: {
    fontSize: 11,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
  sectionTitle: {
    fontWeight: '700',
    color: COLORS.text,
    fontSize: 16,
    marginBottom: SPACING.sm,
  },
  empty: {
    color: COLORS.textSecondary,
    fontStyle: 'italic',
  },
  historiqueItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    gap: SPACING.sm,
  },
  historiqueInfo: {
    flex: 1,
  },
  historiqueTitre: {
    fontWeight: '600',
    color: COLORS.text,
  },
  historiqueDetails: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  actions: {
    gap: SPACING.sm,
  },
});