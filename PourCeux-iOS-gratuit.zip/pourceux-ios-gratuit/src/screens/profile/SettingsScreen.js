import React, { useCallback, useEffect, useState } from 'react';
import { StyleSheet, ScrollView, Linking } from 'react-native';
import { Text } from 'react-native-paper';
import * as Location from 'expo-location';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import { SettingsSection } from '../../components/settings/SettingsSection';
import { SettingsItem } from '../../components/settings/SettingsItem';
import { useAuth } from '../../contexts/AuthContext';
import { useConfirm } from '../../contexts/ConfirmContext';
import { useLocale } from '../../contexts/LocaleContext';
import { CONFIG } from '../../constants/config';
import { COLORS } from '../../constants/colors';
import { SPACING } from '../../styles/theme';

export function SettingsScreen({ navigation }) {
  const { signOut } = useAuth();
  const confirm = useConfirm();
  const { locale, setLocale, t } = useLocale();

  const [notifStatus, setNotifStatus] = useState(null);
  const [locStatus, setLocStatus] = useState(null);

  const refreshStatuses = useCallback(() => {
    Notifications.getPermissionsAsync().then((r) => setNotifStatus(r.status));
    Location.getForegroundPermissionsAsync().then((r) => setLocStatus(r.status));
  }, []);

  useEffect(() => {
    refreshStatuses();
  }, [refreshStatuses]);

  const handleRequestLocation = async () => {
    await Location.requestForegroundPermissionsAsync();
    refreshStatuses();
  };

  const handleSignOut = async () => {
    const ok = await confirm({
      title: t('profile.signOutDialog.title'),
      message: t('profile.signOutDialog.message'),
      confirmLabel: t('profile.signOutDialog.confirm'),
      destructive: true,
    });
    if (ok) signOut();
  };

  const appVersion = Constants.nativeAppVersion || Constants.expoConfig?.version || '—';
  const buildNumber = Constants.nativeBuildVersion || '—';
  const contactEmail = CONFIG.APP_CONTACT_EMAIL;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <SettingsSection title={t('settings.language.section')}>
        <SettingsItem
          icon="translate"
          label={t('settings.language.french')}
          value={locale === 'fr' ? '✓' : undefined}
          onPress={() => setLocale('fr')}
        />
        <SettingsItem
          icon="translate"
          label={t('settings.language.english')}
          value={locale === 'en' ? '✓' : undefined}
          onPress={() => setLocale('en')}
        />
      </SettingsSection>

      <SettingsSection title={t('settings.notifications.section')}>
        <SettingsItem
          icon="bell-outline"
          label={t('settings.notifications.status')}
          value={
            notifStatus === 'granted'
              ? t('settings.notifications.granted')
              : t('settings.notifications.denied')
          }
        />
        <SettingsItem
          icon="cog-outline"
          label={t('settings.notifications.openSettings')}
          onPress={() => Linking.openSettings()}
        />
      </SettingsSection>

      <SettingsSection title={t('settings.location.section')}>
        <SettingsItem
          icon="map-marker-outline"
          label={t('settings.location.status')}
          value={
            locStatus === 'granted' ? t('settings.location.granted') : t('settings.location.denied')
          }
        />
        {locStatus !== 'granted' ? (
          <SettingsItem
            icon="crosshairs-gps"
            label={t('settings.location.request')}
            onPress={handleRequestLocation}
          />
        ) : null}
        <SettingsItem
          icon="cog-outline"
          label={t('settings.location.openSettings')}
          onPress={() => Linking.openSettings()}
        />
      </SettingsSection>
      <Text style={styles.explanationText}>{t('settings.location.explanation')}</Text>

      <SettingsSection title={t('settings.account.section')}>
        <SettingsItem
          icon="account-cog-outline"
          label={t('settings.account.manage')}
          onPress={() => navigation.navigate('EditProfile')}
        />
        <SettingsItem icon="logout" label={t('settings.account.signOut')} onPress={handleSignOut} />
      </SettingsSection>

      <SettingsSection title={t('settings.help.section')}>
        {contactEmail ? (
          <SettingsItem
            icon="email-outline"
            label={t('settings.help.contact')}
            value={contactEmail}
            onPress={() => Linking.openURL(`mailto:${contactEmail}`)}
          />
        ) : null}
        <SettingsItem icon="information-outline" label={t('settings.help.about')} />
        <SettingsItem
          icon="tag-outline"
          label={t('settings.help.version')}
          value={String(appVersion)}
        />
        <SettingsItem icon="numeric" label={t('settings.help.build')} value={String(buildNumber)} />
      </SettingsSection>
      <Text style={styles.explanationText}>{t('settings.help.aboutText')}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    padding: SPACING.md,
    paddingBottom: SPACING.xl,
  },
  explanationText: {
    fontSize: 12,
    color: COLORS.textOnDarkSecondary,
    marginTop: -SPACING.sm,
    marginBottom: SPACING.md,
    marginHorizontal: SPACING.xs,
  },
});
