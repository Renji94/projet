import React, { useState } from 'react';
import { StyleSheet, ScrollView } from 'react-native';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { AppTextInput } from '../../components/common/AppTextInput';
import { AppButton } from '../../components/common/AppButton';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { getFriendlyErrorMessage } from '../../utils/friendlyError';
import { profilesService } from '../../services/profiles.service';
import { profileSchema } from '../../utils/validation';
import { SPACING } from '../../styles/theme';

export function EditProfileScreen({ navigation }) {
  const { user, profile, refreshProfile } = useAuth();
  const toast = useToast();
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      pseudo: profile?.pseudo || '',
      prenom: profile?.prenom || '',
      nom: profile?.nom || '',
      telephone: profile?.telephone || '',
      ville: profile?.ville || '',
    },
  });

  const onSubmit = async (values) => {
    setError(null);
    setLoading(true);
    try {
      await profilesService.updateProfile(user.id, values);
      await refreshProfile();
      toast.showSuccess('Profil mis à jour.');
      navigation.goBack();
    } catch (e) {
      setError(getFriendlyErrorMessage(e));
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <ErrorMessage message={error} />

      <AppTextInput
        control={control}
        name="pseudo"
        label="Pseudo *"
        autoCapitalize="none"
        error={errors.pseudo}
      />
      <AppTextInput control={control} name="prenom" label="Prénom *" error={errors.prenom} />
      <AppTextInput control={control} name="nom" label="Nom *" error={errors.nom} />
      <AppTextInput
        control={control}
        name="telephone"
        label="Téléphone (facultatif)"
        keyboardType="phone-pad"
        error={errors.telephone}
      />
      <AppTextInput control={control} name="ville" label="Ville *" error={errors.ville} />

      <AppButton onPress={handleSubmit(onSubmit)} loading={loading} style={styles.submit}>
        Enregistrer
      </AppButton>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    padding: SPACING.md,
    paddingBottom: SPACING.xl,
  },
  submit: {
    marginTop: SPACING.md,
  },
});