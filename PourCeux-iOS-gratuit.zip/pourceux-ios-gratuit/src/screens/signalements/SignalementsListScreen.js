import React, { useState } from 'react';
import { View, StyleSheet, FlatList, RefreshControl } from 'react-native';
import { Chip } from 'react-native-paper';
import { SignalementCard } from '../../components/signalements/SignalementCard';
import { EmptyState } from '../../components/common/EmptyState';
import { SkeletonList } from '../../components/common/SkeletonListItem';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { useSignalementsList } from '../../hooks/useSignalements';
import { COLORS } from '../../constants/colors';
import { URGENCES, SIGNALEMENT_STATUTS } from '../../constants/enums';
import { SPACING } from '../../styles/theme';

export function SignalementsListScreen({ navigation }) {
  const [urgence, setUrgence] = useState(null);
  const [statut, setStatut] = useState(null);

  const { data: signalements, isLoading, error, refetch, isRefetching } = useSignalementsList({
    urgence,
    statut,
  });

  if (isLoading) {
    return (
      <View style={styles.container}>
        <SkeletonList count={5} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {error ? <View style={styles.error}><ErrorMessage message={error.message} /></View> : null}
      <View style={styles.filters}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={Object.entries(URGENCES)}
          keyExtractor={([key]) => `urgence-${key}`}
          contentContainerStyle={styles.chipRow}
          renderItem={({ item: [key, config] }) => (
            <Chip
              selected={urgence === key}
              onPress={() => setUrgence(urgence === key ? null : key)}
              style={[styles.chip, urgence === key && { backgroundColor: config.color }]}
              textStyle={urgence === key ? styles.chipTextSelected : undefined}
            >
              {config.label}
            </Chip>
          )}
        />
      </View>

      <View style={styles.filters}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={Object.entries(SIGNALEMENT_STATUTS)}
          keyExtractor={([key]) => `statut-${key}`}
          contentContainerStyle={styles.chipRow}
          renderItem={({ item: [key, config] }) => (
            <Chip
              selected={statut === key}
              onPress={() => setStatut(statut === key ? null : key)}
              style={[styles.chip, statut === key && { backgroundColor: config.color }]}
              textStyle={statut === key ? styles.chipTextSelected : undefined}
            >
              {config.label}
            </Chip>
          )}
        />
      </View>

      <FlatList
        data={signalements || []}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <SignalementCard
            signalement={item}
            onPress={() => navigation.navigate('SignalementDetail', { id: item.id })}
          />
        )}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={refetch} />}
        ListEmptyComponent={
          <EmptyState
            icon="alert-circle-outline"
            title="Aucun signalement"
            subtitle="Aucun signalement ne correspond à vos critères."
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  error: {
    paddingHorizontal: SPACING.md,
  },
  filters: {
    marginTop: SPACING.sm,
  },
  chipRow: {
    paddingHorizontal: SPACING.md,
    gap: SPACING.sm,
  },
  chip: {
    backgroundColor: COLORS.surface,
  },
  chipTextSelected: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  list: {
    paddingTop: SPACING.sm,
    paddingBottom: SPACING.lg,
    flexGrow: 1,
  },
});