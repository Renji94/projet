import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Text, SegmentedButtons, Switch, TextInput } from 'react-native-paper';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { AppTextInput } from '../../components/common/AppTextInput';
import { AppButton } from '../../components/common/AppButton';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { BesoinsSelector } from '../../components/signalements/BesoinsSelector';
import { useSignalementMutations } from '../../hooks/useSignalements';
import { useLocation } from '../../hooks/useLocation';
import { geocodingService } from '../../services/geocoding.service';
import { signalementSchema } from '../../utils/validation';
import { useToast } from '../../contexts/ToastContext';
import { getFriendlyErrorMessage } from '../../utils/friendlyError';
import { COLORS } from '../../constants/colors';
import { SPACING, RADIUS } from '../../styles/theme';

export function SignalementFormScreen({ navigation }) {
  const { creer } = useSignalementMutations();
  const { location, requestLocation, loading: locationLoading } = useLocation();
  const toast = useToast();

  const [error, setError] = useState(null);
  const [gpsMode, setGpsMode] = useState('auto');
  const [addressQuery, setAddressQuery] = useState('');
  const [addressResults, setAddressResults] = useState([]);
  const [searchingAddress, setSearchingAddress] = useState(false);

  const {
    control,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(signalementSchema),
    defaultValues: {
      titre: '',
      description: '',
      urgence: 'moyenne',
      latitude: undefined,
      longitude: undefined,
      adresse: '',
      nb_personnes: 1,
      age_approximatif: '',
      animaux: false,
      besoins: [],
      commentaires: '',
    },
  });

  const latitude = watch('latitude');
  const longitude = watch('longitude');

  // Coordonnées GPS automatiques
  useEffect(() => {
    if (gpsMode === 'auto' && location) {
      setValue('latitude', location.latitude);
      setValue('longitude', location.longitude);
      geocodingService
        .reverse(location.latitude, location.longitude)
        .then((res) => {
          if (res.label) setValue('adresse', res.label);
        })
        .catch(() => {});
    }
  }, [gpsMode, location, setValue]);

  const changeGpsMode = (mode) => {
    setGpsMode(mode);
    setAddressResults([]);
    setAddressQuery('');
    setValue('latitude', undefined);
    setValue('longitude', undefined);
    setValue('adresse', '');
    if (mode === 'auto') requestLocation();
  };

  const searchAddress = async () => {
    if (addressQuery.trim().length < 3) return;
    setSearchingAddress(true);
    try {
      const results = await geocodingService.search(addressQuery);
      setAddressResults(results);
      if (results.length === 0) {
        toast.showInfo('Aucune adresse trouvée pour cette recherche.');
      }
    } catch {
      toast.showError('Recherche d’adresse impossible. Vérifiez votre connexion.');
    } finally {
      setSearchingAddress(false);
    }
  };

  const selectAddress = (result) => {
    setValue('adresse', result.label);
    setValue('latitude', result.latitude);
    setValue('longitude', result.longitude);
    setAddressResults([]);
    setAddressQuery('');
  };

  const onSubmit = (values) => {
    setError(null);
    const payload = {
      ...values,
      nb_personnes: Number(values.nb_personnes),
      adresse: values.adresse || null,
      age_approximatif: values.age_approximatif || null,
      commentaires: values.commentaires || null,
    };
    creer.mutate(payload, {
      onSuccess: () => {
        toast.showSuccess('Le signalement a été publié. Merci pour votre aide.');
        navigation.goBack();
      },
      onError: (e) => setError(getFriendlyErrorMessage(e)),
    });
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <ErrorMessage message={error} />

      <AppTextInput control={control} name="titre" label="Titre *" error={errors.titre} />
      <AppTextInput
        control={control}
        name="description"
        label="Description *"
        multiline
        numberOfLines={4}
        error={errors.description}
      />

      <Text style={styles.sectionTitle}>Niveau d'urgence *</Text>
      <Controller
        control={control}
        name="urgence"
        render={({ field: { onChange, value } }) => (
          <SegmentedButtons
            value={value}
            onValueChange={onChange}
            buttons={[
              { value: 'faible', label: 'Faible' },
              { value: 'moyenne', label: 'Moyenne' },
              { value: 'haute', label: 'Haute' },
              { value: 'critique', label: 'Critique' },
            ]}
          />
        )}
      />

      <Text style={styles.sectionTitle}>Localisation *</Text>
      <SegmentedButtons
        value={gpsMode}
        onValueChange={changeGpsMode}
        buttons={[
          { value: 'auto', label: 'Ma position', icon: 'crosshairs-gps' },
          { value: 'manuel', label: 'Adresse manuelle', icon: 'map-search' },
        ]}
      />

      {gpsMode === 'auto' && (
        <View style={styles.gpsBox}>
          {locationLoading ? (
            <Text style={styles.gpsText}>Récupération de votre position…</Text>
          ) : latitude != null ? (
            <Text style={styles.gpsOk}>
              Position détectée : {Number(latitude).toFixed(5)}, {Number(longitude).toFixed(5)}
            </Text>
          ) : (
            <View>
              <Text style={styles.gpsError}>Position indisponible.</Text>
              <AppButton mode="contained-tonal" onPress={requestLocation} compact>
                Réessayer
              </AppButton>
            </View>
          )}
        </View>
      )}

      {gpsMode === 'manuel' && (
        <View style={styles.gpsBox}>
          <View style={styles.searchRow}>
            <TextInput
              style={styles.searchInput}
              mode="outlined"
              label="Rechercher une adresse"
              value={addressQuery}
              onChangeText={setAddressQuery}
              dense
            />
            <AppButton
              mode="contained-tonal"
              onPress={searchAddress}
              loading={searchingAddress}
              compact
            >
              Chercher
            </AppButton>
          </View>
          {addressResults.map((result, index) => (
            <TouchableOpacity
              key={index}
              style={styles.addressResult}
              onPress={() => selectAddress(result)}
            >
              <Text numberOfLines={2}>{result.label}</Text>
            </TouchableOpacity>
          ))}
          {latitude != null && (
            <Text style={styles.gpsOk}>
              Position sélectionnée : {Number(latitude).toFixed(5)},{' '}
              {Number(longitude).toFixed(5)}
            </Text>
          )}
        </View>
      )}
      {errors.latitude && <ErrorMessage message="Position GPS requise." />}

      <AppTextInput
        control={control}
        name="adresse"
        label="Adresse (facultatif)"
        error={errors.adresse}
      />

      <Text style={styles.sectionTitle}>Personnes concernées</Text>
      <Controller
        control={control}
        name="nb_personnes"
        render={({ field: { onChange, value } }) => (
          <TextInput
            style={styles.searchInput}
            mode="outlined"
            label="Nombre approximatif de personnes *"
            keyboardType="number-pad"
            value={String(value ?? '')}
            onChangeText={(text) => onChange(text ? parseInt(text, 10) : undefined)}
            error={Boolean(errors.nb_personnes)}
          />
        )}
      />
      {errors.nb_personnes && (
        <Text style={styles.errorText}>{errors.nb_personnes.message}</Text>
      )}

      <AppTextInput
        control={control}
        name="age_approximatif"
        label="Âge approximatif (facultatif)"
        placeholder="Ex : 40-50 ans"
        error={errors.age_approximatif}
      />

      <View style={styles.switchRow}>
        <Text style={styles.switchLabel}>Présence d'animaux</Text>
        <Controller
          control={control}
          name="animaux"
          render={({ field: { onChange, value } }) => (
            <Switch value={value} onValueChange={onChange} color={COLORS.primary} />
          )}
        />
      </View>

      <Text style={styles.sectionTitle}>Besoins *</Text>
      <Controller
        control={control}
        name="besoins"
        render={({ field: { onChange, value } }) => (
          <BesoinsSelector value={value} onChange={onChange} error={errors.besoins} />
        )}
      />

      <AppTextInput
        control={control}
        name="commentaires"
        label="Commentaires (facultatif)"
        multiline
        numberOfLines={3}
        error={errors.commentaires}
      />

      <AppButton onPress={handleSubmit(onSubmit)} loading={creer.isPending} style={styles.submit}>
        Envoyer le signalement
      </AppButton>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    padding: SPACING.md,
    paddingBottom: SPACING.xl,
  },
  sectionTitle: {
    fontWeight: '700',
    color: COLORS.textOnDark,
    marginTop: SPACING.md,
    marginBottom: SPACING.sm,
  },
  gpsBox: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginTop: SPACING.sm,
    marginBottom: SPACING.sm,
  },
  gpsText: {
    color: COLORS.textSecondary,
  },
  gpsOk: {
    color: COLORS.success,
    fontSize: 13,
    marginTop: SPACING.xs,
  },
  gpsError: {
    color: COLORS.danger,
    marginBottom: SPACING.sm,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.sm,
  },
  searchInput: {
    flex: 1,
    backgroundColor: COLORS.surface,
  },
  addressResult: {
    backgroundColor: COLORS.surface,
    padding: SPACING.md,
    borderRadius: RADIUS.sm,
    marginBottom: SPACING.xs,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: SPACING.md,
    backgroundColor: COLORS.surface,
    padding: SPACING.md,
    borderRadius: RADIUS.md,
  },
  switchLabel: {
    color: COLORS.text,
    fontWeight: '600',
  },
  errorText: {
    color: COLORS.danger,
    fontSize: 12,
    marginTop: 4,
  },
  submit: {
    marginTop: SPACING.lg,
  },
});