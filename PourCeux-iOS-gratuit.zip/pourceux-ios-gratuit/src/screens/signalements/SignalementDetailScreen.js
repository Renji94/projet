import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, Linking } from 'react-native';
import { Text, Divider, Portal, Dialog, RadioButton } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Badge } from '../../components/common/Badge';
import { AppButton } from '../../components/common/AppButton';
import { LoadingScreen } from '../../components/common/LoadingScreen';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { UrgenceBadge } from '../../components/signalements/UrgenceBadge';
import { useSignalement, useSignalementMutations } from '../../hooks/useSignalements';
import { useLocation } from '../../hooks/useLocation';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { useConfirm } from '../../contexts/ConfirmContext';
import { getFriendlyErrorMessage } from '../../utils/friendlyError';
import { COLORS } from '../../constants/colors';
import { SIGNALEMENT_STATUTS, BESOINS, CLOTURE_OPTIONS } from '../../constants/enums';
import { formatRelative } from '../../utils/date';
import { getItineraireUrl } from '../../utils/geo';
import { SPACING, RADIUS, SHADOW } from '../../styles/theme';

export function SignalementDetailScreen({ route, navigation }) {
  const { id } = route.params;
  const { user, isAdmin } = useAuth();
  const { location } = useLocation({ autoRequest: false });
  const toast = useToast();
  const confirm = useConfirm();

  const { data: signalement, isLoading, error } = useSignalement(id);
  const { prendreEnCharge, cloturer, supprimer } = useSignalementMutations(id);

  const [clotureVisible, setClotureVisible] = useState(false);
  const [clotureStatut, setClotureStatut] = useState('resolu');

  if (isLoading) return <LoadingScreen />;
  if (error || !signalement) {
    return (
      <View style={styles.errorContainer}>
        <ErrorMessage message={error?.message || 'Signalement introuvable.'} />
      </View>
    );
  }

  const statut = SIGNALEMENT_STATUTS[signalement.statut];
  const chatId = Array.isArray(signalement.chat)
    ? signalement.chat[0]?.id
    : signalement.chat?.id;
  const estResponsable = signalement.pris_en_charge_par === user?.id;
  const estCreateur = signalement.createur_id === user?.id;
  const peutCloturer =
    (estResponsable || estCreateur || isAdmin) &&
    ['ouvert', 'pris_en_charge'].includes(signalement.statut);

  const besoinsLabels = (signalement.besoins || []).map(
    (b) => BESOINS.find((x) => x.value === b)?.label || b
  );

  const handlePrendreEnCharge = () => {
    prendreEnCharge.mutate(undefined, {
      onError: (e) => toast.showError(getFriendlyErrorMessage(e)),
    });
  };

  const handleCloturer = () => {
    setClotureVisible(false);
    cloturer.mutate(clotureStatut, {
      onError: (e) => toast.showError(getFriendlyErrorMessage(e)),
    });
  };

  const handleSupprimer = async () => {
    const ok = await confirm({
      title: 'Supprimer le signalement',
      message: 'Cette action est irréversible. Confirmer ?',
      confirmLabel: 'Supprimer',
      destructive: true,
    });
    if (!ok) return;
    supprimer.mutate(id, {
      onSuccess: () => navigation.goBack(),
      onError: (e) => toast.showError(getFriendlyErrorMessage(e)),
    });
  };

  const openItineraire = () => {
    const url = getItineraireUrl(
      signalement.latitude,
      signalement.longitude,
      location?.latitude,
      location?.longitude
    );
    Linking.openURL(url).catch(() => {});
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.card}>
        <Text variant="headlineSmall" style={styles.titre}>
          {signalement.titre}
        </Text>

        <View style={styles.badges}>
          <UrgenceBadge urgence={signalement.urgence} />
          <Badge label={statut.label} color={statut.color} />
        </View>

        <Text style={styles.description}>{signalement.description}</Text>

        <Divider style={styles.divider} />

        {signalement.adresse ? (
          <InfoRow icon="map-marker" text={signalement.adresse} />
        ) : (
          <InfoRow
            icon="map-marker"
            text={`GPS : ${signalement.latitude.toFixed(5)}, ${signalement.longitude.toFixed(5)}`}
          />
        )}
        <InfoRow
          icon="account-multiple"
          text={`${signalement.nb_personnes} personne${signalement.nb_personnes > 1 ? 's' : ''}`}
        />
        {signalement.age_approximatif ? (
          <InfoRow icon="cake-variant" text={`Âge approximatif : ${signalement.age_approximatif}`} />
        ) : null}
        <InfoRow
          icon="paw"
          text={signalement.animaux ? 'Présence d’animaux' : 'Pas d’animaux'}
        />
        <InfoRow
          icon="account"
          text={`Signalé par ${signalement.createur?.pseudo || 'Utilisateur'} · ${formatRelative(
            signalement.created_at
          )}`}
        />
        {signalement.responsable ? (
          <InfoRow
            icon="hand-heart"
            text={`Pris en charge par ${signalement.responsable.pseudo}`}
          />
        ) : null}

        {besoinsLabels.length > 0 && (
          <>
            <Divider style={styles.divider} />
            <Text style={styles.sectionTitle}>Besoins</Text>
            {besoinsLabels.map((label, index) => (
              <InfoRow key={index} icon="check-circle-outline" text={label} />
            ))}
          </>
        )}

        {signalement.commentaires ? (
          <>
            <Divider style={styles.divider} />
            <Text style={styles.sectionTitle}>Commentaires</Text>
            <Text style={styles.description}>{signalement.commentaires}</Text>
          </>
        ) : null}
      </View>

      <View style={styles.actions}>
        {signalement.statut === 'ouvert' && !estCreateur && (
          <AppButton
            onPress={handlePrendreEnCharge}
            loading={prendreEnCharge.isPending}
            icon="hand-heart"
          >
            Je prends en charge
          </AppButton>
        )}

        {peutCloturer && (
          <AppButton
            mode="contained-tonal"
            icon="flag-checkered"
            onPress={() => setClotureVisible(true)}
          >
            Mettre à jour le statut
          </AppButton>
        )}

        {chatId && (
          <AppButton
            mode="contained-tonal"
            icon="chat"
            onPress={() => navigation.navigate('Chat', { chatId, titre: signalement.titre })}
          >
            Discuter
          </AppButton>
        )}

        <AppButton mode="outlined" icon="directions" onPress={openItineraire}>
          Itinéraire
        </AppButton>

        {(estCreateur || isAdmin) && (
          <AppButton
            mode="outlined"
            icon="delete"
            textColor={COLORS.danger}
            onPress={handleSupprimer}
            loading={supprimer.isPending}
          >
            Supprimer
          </AppButton>
        )}
      </View>

      <Portal>
        <Dialog visible={clotureVisible} onDismiss={() => setClotureVisible(false)}>
          <Dialog.Title>Statut du signalement</Dialog.Title>
          <Dialog.Content>
            <RadioButton.Group onValueChange={setClotureStatut} value={clotureStatut}>
              {CLOTURE_OPTIONS.map((option) => (
                <RadioButton.Item
                  key={option.value}
                  label={option.label}
                  value={option.value}
                  color={COLORS.primary}
                />
              ))}
            </RadioButton.Group>
          </Dialog.Content>
          <Dialog.Actions>
            <AppButton mode="text" onPress={() => setClotureVisible(false)}>
              Annuler
            </AppButton>
            <AppButton mode="text" onPress={handleCloturer} loading={cloturer.isPending}>
              Confirmer
            </AppButton>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </ScrollView>
  );
}

function InfoRow({ icon, text }) {
  return (
    <View style={styles.infoRow}>
      <MaterialCommunityIcons name={icon} size={18} color={COLORS.textSecondary} />
      <Text style={styles.infoText}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  errorContainer: {
    flex: 1,
    backgroundColor: 'transparent',
    padding: SPACING.md,
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    padding: SPACING.md,
    paddingBottom: SPACING.xl,
    gap: SPACING.md,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    ...SHADOW.card,
  },
  titre: {
    fontWeight: '700',
    color: COLORS.text,
  },
  badges: {
    flexDirection: 'row',
    gap: SPACING.sm,
    marginVertical: SPACING.sm,
  },
  description: {
    color: COLORS.textSecondary,
    lineHeight: 20,
  },
  divider: {
    marginVertical: SPACING.md,
  },
  sectionTitle: {
    fontWeight: '700',
    color: COLORS.text,
    fontSize: 16,
    marginBottom: SPACING.sm,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: 6,
  },
  infoText: {
    color: COLORS.text,
    flex: 1,
  },
  actions: {
    gap: SPACING.sm,
  },
});