import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Text } from 'react-native-paper';
import { AppButton } from '../../components/common/AppButton';
import { useAuth } from '../../contexts/AuthContext';
import { COLORS } from '../../constants/colors';
import { SPACING } from '../../styles/theme';

export function SuspendedScreen() {
  const { signOut } = useAuth();
  return (
    <View style={styles.container}>
      <Text variant="headlineSmall" style={styles.title}>Compte suspendu</Text>
      <Text style={styles.body}>
        L'accès à PourCeux a été suspendu par un administrateur. Contactez l'association pour obtenir des informations.
      </Text>
      <AppButton mode="outlined" onPress={signOut}>Se déconnecter</AppButton>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', gap: SPACING.lg, padding: SPACING.xl, backgroundColor: 'transparent' },
  title: { color: COLORS.danger, fontWeight: '700' },
  body: { color: COLORS.textOnDark, lineHeight: 22 },
});
