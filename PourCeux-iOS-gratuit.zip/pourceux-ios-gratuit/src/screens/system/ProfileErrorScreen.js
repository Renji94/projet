import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { Button, Text } from 'react-native-paper';
import { useAuth } from '../../contexts/AuthContext';
import { COLORS } from '../../constants/colors';
import { SPACING } from '../../styles/theme';

export function ProfileErrorScreen() {
  const { error, refreshProfile, signOut } = useAuth();
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState('');

  const run = async (action) => {
    setBusy(true);
    setActionError('');
    try {
      await action();
    } catch (e) {
      setActionError(e.message || 'Opération impossible.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text variant="headlineSmall" style={styles.title}>Profil indisponible</Text>
      <Text style={styles.body}>
        La session est ouverte, mais le profil associé n’a pas pu être chargé. Vérifiez les
        migrations Supabase et les politiques RLS avant de poursuivre.
      </Text>
      <Text style={styles.error}>{actionError || error}</Text>
      <Button
        mode="contained"
        loading={busy}
        disabled={busy}
        onPress={() => run(refreshProfile)}
        style={styles.button}
      >
        Réessayer
      </Button>
      <Button
        mode="outlined"
        disabled={busy}
        onPress={() => run(signOut)}
        style={styles.button}
      >
        Se déconnecter
      </Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: SPACING.xl,
    backgroundColor: 'transparent',
  },
  title: { color: COLORS.danger, fontWeight: '700', marginBottom: SPACING.md },
  body: { color: COLORS.textOnDark, lineHeight: 22 },
  error: { color: COLORS.danger, marginTop: SPACING.md },
  button: { marginTop: SPACING.md },
});
