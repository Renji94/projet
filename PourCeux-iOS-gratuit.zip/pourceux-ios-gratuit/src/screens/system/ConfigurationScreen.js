import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Text } from 'react-native-paper';
import { getMissingConfig } from '../../constants/config';
import { COLORS } from '../../constants/colors';
import { SPACING } from '../../styles/theme';

export function ConfigurationScreen() {
  const missing = getMissingConfig();
  return (
    <View style={styles.container}>
      <Text variant="headlineSmall" style={styles.title}>Configuration incomplète</Text>
      <Text style={styles.body}>
        Copiez .env.example vers .env puis renseignez : {missing.join(', ')}.
      </Text>
      <Text style={styles.help}>Redémarrez Expo avec npm run start:clear après modification.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: SPACING.xl, backgroundColor: 'transparent' },
  title: { color: COLORS.danger, fontWeight: '700', marginBottom: SPACING.md },
  body: { color: COLORS.textOnDark, lineHeight: 22 },
  help: { color: COLORS.textOnDarkSecondary, marginTop: SPACING.md },
});
