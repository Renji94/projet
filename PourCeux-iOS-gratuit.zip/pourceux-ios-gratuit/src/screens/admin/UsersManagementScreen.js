import React, { useState } from 'react';
import { View, StyleSheet, FlatList } from 'react-native';
import { Searchbar, Text, Avatar, IconButton, Menu } from 'react-native-paper';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { LoadingScreen } from '../../components/common/LoadingScreen';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { profilesService } from '../../services/profiles.service';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { useConfirm } from '../../contexts/ConfirmContext';
import { getFriendlyErrorMessage } from '../../utils/friendlyError';
import { COLORS } from '../../constants/colors';
import { SPACING, RADIUS, SHADOW } from '../../styles/theme';

export function UsersManagementScreen() {
  const { user: currentUser } = useAuth();
  const queryClient = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [search, setSearch] = useState('');
  const [menuUserId, setMenuUserId] = useState(null);

  const { data: users, isLoading, error } = useQuery({
    queryKey: ['admin-users', search],
    queryFn: () => profilesService.listUsers(search),
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['admin-users'] });

  const suspendMutation = useMutation({
    mutationFn: ({ userId, suspended }) => profilesService.setSuspended(userId, suspended),
    onSuccess: invalidate,
    onError: (e) => toast.showError(getFriendlyErrorMessage(e)),
  });

  const roleMutation = useMutation({
    mutationFn: ({ userId, role }) => profilesService.setRole(userId, role),
    onSuccess: invalidate,
    onError: (e) => toast.showError(getFriendlyErrorMessage(e)),
  });

  const handleSuspend = async (user) => {
    setMenuUserId(null);
    const action = user.is_suspended ? 'réactiver' : 'suspendre';
    const ok = await confirm({
      title: 'Confirmation',
      message: `Voulez-vous ${action} le compte de ${user.pseudo} ?`,
      confirmLabel: 'Confirmer',
      destructive: !user.is_suspended,
    });
    if (!ok) return;
    suspendMutation.mutate({ userId: user.id, suspended: !user.is_suspended });
  };

  const handleRole = async (user) => {
    setMenuUserId(null);
    const newRole = user.role === 'admin' ? 'user' : 'admin';
    const ok = await confirm({
      title: 'Changement de rôle',
      message: `Attribuer le rôle « ${newRole === 'admin' ? 'Administrateur' : 'Utilisateur'} » à ${user.pseudo} ?`,
      confirmLabel: 'Confirmer',
    });
    if (!ok) return;
    roleMutation.mutate({ userId: user.id, role: newRole });
  };

  if (isLoading) return <LoadingScreen message="Chargement des utilisateurs…" />;

  return (
    <View style={styles.container}>
      {error ? <View style={styles.error}><ErrorMessage message={error.message} /></View> : null}
      <Searchbar
        placeholder="Rechercher un utilisateur…"
        value={search}
        onChangeText={setSearch}
        style={styles.search}
      />

      <FlatList
        data={users || []}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <View style={styles.userCard}>
            {item.avatar_url ? (
              <Avatar.Image size={44} source={{ uri: item.avatar_url }} />
            ) : (
              <Avatar.Text
                size={44}
                label={(item.pseudo || '?').slice(0, 2).toUpperCase()}
                style={{ backgroundColor: COLORS.primaryLight }}
                labelStyle={{ color: COLORS.primary }}
              />
            )}

            <View style={styles.userInfo}>
              <Text style={styles.pseudo}>{item.pseudo}</Text>
              <Text style={styles.details}>
                {item.prenom} {item.nom} · {item.ville}
              </Text>
              <View style={styles.badges}>
                {item.role === 'admin' && (
                  <Badge label="Admin" color={COLORS.secondary} small />
                )}
                {item.is_suspended && (
                  <Badge label="Suspendu" color={COLORS.danger} small />
                )}
              </View>
            </View>

            {item.id !== currentUser?.id && (
              <Menu
                visible={menuUserId === item.id}
                onDismiss={() => setMenuUserId(null)}
                anchor={
                  <IconButton
                    icon="dots-vertical"
                    onPress={() => setMenuUserId(item.id)}
                    accessibilityLabel={`Actions pour ${item.pseudo}`}
                  />
                }
              >
                <Menu.Item
                  leadingIcon={item.is_suspended ? 'account-check' : 'account-cancel'}
                  title={item.is_suspended ? 'Réactiver' : 'Suspendre'}
                  onPress={() => handleSuspend(item)}
                />
                <Menu.Item
                  leadingIcon="shield-account"
                  title={item.role === 'admin' ? 'Retirer admin' : 'Promouvoir admin'}
                  onPress={() => handleRole(item)}
                />
              </Menu>
            )}
          </View>
        )}
        ListEmptyComponent={
          <EmptyState icon="account-search" title="Aucun utilisateur trouvé" />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  error: {
    paddingHorizontal: SPACING.md,
  },
  search: {
    margin: SPACING.md,
    backgroundColor: COLORS.surface,
  },
  list: {
    paddingBottom: SPACING.xl,
    flexGrow: 1,
  },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginHorizontal: SPACING.md,
    marginBottom: SPACING.sm,
    ...SHADOW.card,
  },
  userInfo: {
    flex: 1,
    gap: 2,
  },
  pseudo: {
    fontWeight: '700',
    color: COLORS.text,
  },
  details: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  badges: {
    flexDirection: 'row',
    gap: SPACING.xs,
    marginTop: 2,
  },
});