import React from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '../../services/supabase';
import { COLORS } from '../../constants/colors';
import { SPACING, RADIUS, SHADOW } from '../../styles/theme';
import { ErrorMessage } from '../../components/common/ErrorMessage';

async function fetchAdminStats() {
  const [maraudes, signalements, users, signalementsOuverts] = await Promise.all([
    supabase.from('maraudes').select('id', { count: 'exact', head: true }),
    supabase.from('signalements').select('id', { count: 'exact', head: true }),
    supabase.from('profiles').select('id', { count: 'exact', head: true }),
    supabase
      .from('signalements')
      .select('id', { count: 'exact', head: true })
      .eq('statut', 'ouvert'),
  ]);
  const failed = [maraudes, signalements, users, signalementsOuverts].find(
    (result) => result.error
  );
  if (failed?.error) throw new Error(failed.error.message);

  return {
    maraudes: maraudes.count ?? 0,
    signalements: signalements.count ?? 0,
    users: users.count ?? 0,
    signalementsOuverts: signalementsOuverts.count ?? 0,
  };
}

export function AdminDashboardScreen({ navigation }) {
  const { data: stats, error } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: fetchAdminStats,
  });

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {error ? <ErrorMessage message={error.message} /> : null}
      <View style={styles.statsGrid}>
        <StatBox icon="walk" value={stats?.maraudes ?? '–'} label="Maraudes" color={COLORS.primary} />
        <StatBox
          icon="alert-circle"
          value={stats?.signalements ?? '–'}
          label="Signalements"
          color={COLORS.danger}
        />
        <StatBox
          icon="account-group"
          value={stats?.users ?? '–'}
          label="Utilisateurs"
          color={COLORS.success}
        />
        <StatBox
          icon="alert"
          value={stats?.signalementsOuverts ?? '–'}
          label="Signalements ouverts"
          color={COLORS.warning}
        />
      </View>

      <Text style={styles.sectionTitle}>Actions</Text>

      <ActionCard
        icon="plus-circle"
        title="Créer une maraude"
        subtitle="Organiser un nouvel événement"
        onPress={() => navigation.navigate('MaraudeForm', {})}
      />
      <ActionCard
        icon="account-cog"
        title="Gérer les utilisateurs"
        subtitle="Rôles, suspensions"
        onPress={() => navigation.navigate('UsersManagement')}
      />
    </ScrollView>
  );
}

function StatBox({ icon, value, label, color }) {
  return (
    <View style={styles.statBox}>
      <MaterialCommunityIcons name={icon} size={28} color={color} />
      <Text style={[styles.statValue, { color }]}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

function ActionCard({ icon, title, subtitle, onPress }) {
  return (
    <TouchableOpacity
      style={styles.actionCard}
      onPress={onPress}
      activeOpacity={0.7}
      accessibilityRole="button"
      accessibilityLabel={title}
    >
      <MaterialCommunityIcons name={icon} size={32} color={COLORS.primary} />
      <View style={styles.actionInfo}>
        <Text style={styles.actionTitle}>{title}</Text>
        <Text style={styles.actionSubtitle}>{subtitle}</Text>
      </View>
      <MaterialCommunityIcons name="chevron-right" size={24} color={COLORS.textLight} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    padding: SPACING.md,
    paddingBottom: SPACING.xl,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm,
  },
  statBox: {
    flexBasis: '48%',
    flexGrow: 1,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    alignItems: 'center',
    gap: 4,
    ...SHADOW.card,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
  },
  statLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
  sectionTitle: {
    fontWeight: '700',
    color: COLORS.textOnDark,
    fontSize: 16,
    marginTop: SPACING.lg,
    marginBottom: SPACING.sm,
  },
  actionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginBottom: SPACING.sm,
    ...SHADOW.card,
  },
  actionInfo: {
    flex: 1,
  },
  actionTitle: {
    fontWeight: '700',
    color: COLORS.text,
  },
  actionSubtitle: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
});