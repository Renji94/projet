import React from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useAuth } from '../../contexts/AuthContext';
import { useLocale } from '../../contexts/LocaleContext';
import { COLORS } from '../../constants/colors';
import { SPACING, RADIUS, SHADOW } from '../../styles/theme';

export function HomeScreen({ navigation }) {
  const { profile } = useAuth();
  const { t } = useLocale();

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text variant="headlineSmall" style={styles.greeting}>
        {t('home.greeting')}
        {profile?.prenom ? ` ${profile.prenom}` : ''}
      </Text>
      <Text style={styles.subtitle}>{t('home.subtitle')}</Text>

      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('MaraudesList')}>
        <MaterialCommunityIcons name="walk" size={32} color={COLORS.success} />
        <View style={styles.cardText}>
          <Text style={styles.cardTitle}>{t('home.maraudes.title')}</Text>
          <Text style={styles.cardSubtitle}>{t('home.maraudes.subtitle')}</Text>
        </View>
        <MaterialCommunityIcons name="chevron-right" size={24} color={COLORS.textLight} />
      </TouchableOpacity>

      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('SignalementsList')}>
        <MaterialCommunityIcons name="alert" size={32} color={COLORS.danger} />
        <View style={styles.cardText}>
          <Text style={styles.cardTitle}>{t('home.signalements.title')}</Text>
          <Text style={styles.cardSubtitle}>{t('home.signalements.subtitle')}</Text>
        </View>
        <MaterialCommunityIcons name="chevron-right" size={24} color={COLORS.textLight} />
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: SPACING.md,
    gap: SPACING.md,
  },
  greeting: {
    color: COLORS.textOnDark,
    fontWeight: '700',
  },
  subtitle: {
    color: COLORS.textOnDarkSecondary,
    marginBottom: SPACING.sm,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    ...SHADOW.card,
  },
  cardText: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.text,
  },
  cardSubtitle: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
});
