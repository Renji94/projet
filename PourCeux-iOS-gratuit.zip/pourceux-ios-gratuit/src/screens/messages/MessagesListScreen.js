import React from 'react';
import { View, StyleSheet, FlatList, RefreshControl } from 'react-native';
import { ConversationCard } from '../../components/messages/ConversationCard';
import { EmptyState } from '../../components/common/EmptyState';
import { SkeletonList } from '../../components/common/SkeletonListItem';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { useConversationsList } from '../../hooks/useConversations';
import { SPACING } from '../../styles/theme';

export function MessagesListScreen({ navigation }) {
  const { data: conversations, isLoading, error, refetch, isRefetching } = useConversationsList();

  if (isLoading) {
    return (
      <View style={styles.container}>
        <SkeletonList count={5} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {error ? (
        <View style={styles.error}>
          <ErrorMessage message="Impossible de charger vos conversations. Tirez pour réessayer." />
        </View>
      ) : null}

      <FlatList
        data={conversations || []}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ConversationCard
            conversation={item}
            onPress={() => navigation.navigate('Chat', { chatId: item.id, titre: item.titre })}
          />
        )}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={refetch} />}
        ListEmptyComponent={
          <EmptyState
            icon="message-text-outline"
            title="Aucune conversation"
            subtitle="Rejoignez une maraude ou participez à un signalement pour démarrer une discussion."
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  error: {
    paddingHorizontal: SPACING.md,
  },
  list: {
    paddingBottom: 24,
    flexGrow: 1,
  },
});
