import React, { useState } from 'react';
import { View, StyleSheet, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { Text, IconButton } from 'react-native-paper';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { AppTextInput } from '../../components/common/AppTextInput';
import { AppButton } from '../../components/common/AppButton';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { useAuth } from '../../contexts/AuthContext';
import { registerSchema } from '../../utils/validation';
import { getFriendlyErrorMessage } from '../../utils/friendlyError';
import { COLORS } from '../../constants/colors';
import { SPACING } from '../../styles/theme';

export function RegisterScreen({ navigation }) {
  const { signUp } = useAuth();
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      email: '',
      password: '',
      confirmPassword: '',
      pseudo: '',
      prenom: '',
      nom: '',
      telephone: '',
      ville: '',
    },
  });

  const onSubmit = async (values) => {
    setError(null);
    setLoading(true);
    try {
      // La connexion est automatique : RootNavigator bascule vers l'app
      // dès que la session créée par signUp() est détectée.
      await signUp(values);
    } catch (e) {
      setError(getFriendlyErrorMessage(e));
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <IconButton
            icon="arrow-left"
            iconColor={COLORS.textOnDark}
            onPress={() => navigation.goBack()}
            accessibilityLabel="Retour"
          />
          <Text variant="headlineSmall" style={styles.title}>
            Créer un compte
          </Text>
        </View>

        <ErrorMessage message={error} />

        <AppTextInput
          control={control}
          name="pseudo"
          label="Pseudo *"
          autoCapitalize="none"
          error={errors.pseudo}
        />
        <AppTextInput control={control} name="prenom" label="Prénom *" error={errors.prenom} />
        <AppTextInput control={control} name="nom" label="Nom *" error={errors.nom} />
        <AppTextInput
          control={control}
          name="telephone"
          label="Téléphone (facultatif)"
          keyboardType="phone-pad"
          error={errors.telephone}
        />
        <AppTextInput control={control} name="ville" label="Ville *" error={errors.ville} />
        <AppTextInput
          control={control}
          name="email"
          label="Email *"
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
          error={errors.email}
        />
        <AppTextInput
          control={control}
          name="password"
          label="Mot de passe *"
          secureTextEntry
          autoCapitalize="none"
          error={errors.password}
        />
        <AppTextInput
          control={control}
          name="confirmPassword"
          label="Confirmer le mot de passe *"
          secureTextEntry
          autoCapitalize="none"
          error={errors.confirmPassword}
        />

        <AppButton onPress={handleSubmit(onSubmit)} loading={loading} disabled={loading}>
          S'inscrire
        </AppButton>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  container: {
    flexGrow: 1,
    padding: SPACING.lg,
    paddingTop: SPACING.xl,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  title: {
    fontWeight: '700',
    color: COLORS.textOnDark,
  },
});