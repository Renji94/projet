import React, { useState } from 'react';
import { View, StyleSheet, KeyboardAvoidingView, Platform, ScrollView, Image } from 'react-native';
import { Text } from 'react-native-paper';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { AppTextInput } from '../../components/common/AppTextInput';
import { AppButton } from '../../components/common/AppButton';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { useAuth } from '../../contexts/AuthContext';
import { loginSchema } from '../../utils/validation';
import { getFriendlyErrorMessage } from '../../utils/friendlyError';
import { COLORS } from '../../constants/colors';
import { SPACING } from '../../styles/theme';

export function LoginScreen({ navigation }) {
  const { signIn } = useAuth();
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' },
  });

  const onSubmit = async (values) => {
    setError(null);
    setLoading(true);
    try {
      await signIn(values);
    } catch (e) {
      setError(getFriendlyErrorMessage(e));
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <View style={styles.logo}>
          <Image
            source={require('../../../assets/logo.png')}
            style={styles.logoImage}
            resizeMode="contain"
            accessibilityLabel="Logo PourCeux"
          />
          <Text style={styles.subtitle}>Ensemble, aidons les plus démunis</Text>
        </View>

        <ErrorMessage message={error} />

        <AppTextInput
          control={control}
          name="email"
          label="Email"
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
          error={errors.email}
        />

        <AppTextInput
          control={control}
          name="password"
          label="Mot de passe"
          secureTextEntry
          autoCapitalize="none"
          error={errors.password}
        />

        <AppButton onPress={handleSubmit(onSubmit)} loading={loading} disabled={loading}>
          Se connecter
        </AppButton>

        <AppButton
          mode="text"
          onPress={() => navigation.navigate('Register')}
          style={styles.linkButton}
        >
          Pas encore de compte ? S'inscrire
        </AppButton>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: SPACING.lg,
  },
  logo: {
    alignItems: 'center',
    marginBottom: SPACING.xl,
  },
  logoImage: {
    width: 230,
    height: 180,
  },
  subtitle: {
    color: COLORS.textOnDarkSecondary,
    marginTop: SPACING.xs,
  },
  linkButton: {
    marginTop: SPACING.sm,
  },
});