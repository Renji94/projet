import React, { useMemo, useRef, useState, useCallback } from 'react';
import { StyleSheet, FlatList, KeyboardAvoidingView, Platform } from 'react-native';
import { useHeaderHeight } from '@react-navigation/elements';
import { MessageBubble } from '../../components/chat/MessageBubble';
import { ChatInput } from '../../components/chat/ChatInput';
import { LoadingScreen } from '../../components/common/LoadingScreen';
import { EmptyState } from '../../components/common/EmptyState';
import { ErrorMessage } from '../../components/common/ErrorMessage';
import { useChat } from '../../hooks/useChat';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { useConfirm } from '../../contexts/ConfirmContext';
import { SPACING } from '../../styles/theme';

const DELETE_ERROR_MESSAGE = 'La suppression a échoué. Réessayez.';
const HIGHLIGHT_DURATION_MS = 1200;

export function ChatScreen({ route }) {
  const { chatId } = route.params;
  const { user, isAdmin } = useAuth();
  const toast = useToast();
  const confirm = useConfirm();
  const { messages, loading, sending, error, sendText, sendLocation, deleteMessage } =
    useChat(chatId);
  const headerHeight = useHeaderHeight();
  const reversedMessages = useMemo(() => [...messages].reverse(), [messages]);

  const [replyingTo, setReplyingTo] = useState(null);
  const [highlightedId, setHighlightedId] = useState(null);
  const flatListRef = useRef(null);
  const deletingRef = useRef(new Set());
  const highlightTimeoutRef = useRef(null);

  const handleSendText = async (contenu) => {
    await sendText(contenu, replyingTo ?? null);
    setReplyingTo(null);
  };

  const handleReply = useCallback((message) => {
    setReplyingTo(message);
  }, []);

  const handleCancelReply = useCallback(() => {
    setReplyingTo(null);
  }, []);

  const handleDelete = useCallback(
    async (messageId) => {
      const ok = await confirm({
        title: 'Supprimer ce message ?',
        message: 'Cette action est définitive.',
        confirmLabel: 'Supprimer',
        destructive: true,
      });
      if (!ok) return;
      if (deletingRef.current.has(messageId)) return;
      deletingRef.current.add(messageId);
      try {
        await deleteMessage(messageId);
      } catch {
        toast.showError(DELETE_ERROR_MESSAGE);
      } finally {
        deletingRef.current.delete(messageId);
      }
    },
    [deleteMessage, confirm, toast]
  );

  const handleQuotePress = useCallback(
    (originalId) => {
      const index = reversedMessages.findIndex((m) => m.id === originalId);
      if (index === -1) return;
      flatListRef.current?.scrollToIndex({ index, animated: true, viewPosition: 0.5 });
      setHighlightedId(originalId);
      if (highlightTimeoutRef.current) clearTimeout(highlightTimeoutRef.current);
      highlightTimeoutRef.current = setTimeout(() => setHighlightedId(null), HIGHLIGHT_DURATION_MS);
    },
    [reversedMessages]
  );

  const handleScrollToIndexFailed = useCallback((info) => {
    setTimeout(() => {
      flatListRef.current?.scrollToIndex({ index: info.index, animated: true, viewPosition: 0.5 });
    }, 100);
  }, []);

  if (loading) return <LoadingScreen message="Chargement de la discussion…" />;

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={headerHeight}
    >
      {error ? <ErrorMessage message={error} /> : null}

      {messages.length === 0 ? (
        <EmptyState
          icon="chat-outline"
          title="Aucun message"
          subtitle="Soyez le premier à écrire dans cette discussion."
        />
      ) : (
        <FlatList
          ref={flatListRef}
          data={reversedMessages}
          keyExtractor={(item) => item.id}
          inverted
          onScrollToIndexFailed={handleScrollToIndexFailed}
          renderItem={({ item }) => (
            <MessageBubble
              message={item}
              isOwn={item.user_id === user?.id}
              canDelete={item.user_id === user?.id || isAdmin}
              isHighlighted={item.id === highlightedId}
              onReply={handleReply}
              onDelete={handleDelete}
              onQuotePress={handleQuotePress}
            />
          )}
          contentContainerStyle={styles.list}
        />
      )}

      <ChatInput
        onSendText={handleSendText}
        onSendLocation={sendLocation}
        sending={sending}
        replyingTo={replyingTo}
        onCancelReply={handleCancelReply}
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  list: {
    paddingVertical: SPACING.sm,
    flexGrow: 1,
  },
});
