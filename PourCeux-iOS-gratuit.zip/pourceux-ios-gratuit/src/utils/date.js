import { format, parseISO, isToday, isYesterday } from 'date-fns';
import { fr } from 'date-fns/locale';

/**
 * Formate une date ISO en date lisible française.
 */
export function formatDate(isoDate) {
  if (!isoDate) return '';
  try {
    return format(parseISO(isoDate), 'EEEE d MMMM yyyy', { locale: fr });
  } catch {
    return isoDate;
  }
}

/**
 * Formate une heure "HH:MM:SS" ou "HH:MM" en "HHhMM".
 */
export function formatHeure(time) {
  if (!time) return '';
  const [h, m] = time.split(':');
  return `${h}h${m}`;
}

/**
 * Formate un timestamp pour le chat.
 */
export function formatMessageTime(isoDate) {
  if (!isoDate) return '';
  try {
    const date = parseISO(isoDate);
    if (isToday(date)) return format(date, 'HH:mm');
    if (isYesterday(date)) return `Hier ${format(date, 'HH:mm')}`;
    return format(date, 'd MMM HH:mm', { locale: fr });
  } catch {
    return '';
  }
}

/**
 * Formate un timestamp relatif court pour les listes.
 */
export function formatRelative(isoDate) {
  if (!isoDate) return '';
  try {
    const date = parseISO(isoDate);
    const diffMs = Date.now() - date.getTime();
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 1) return "À l'instant";
    if (diffMin < 60) return `Il y a ${diffMin} min`;
    const diffH = Math.floor(diffMin / 60);
    if (diffH < 24) return `Il y a ${diffH} h`;
    const diffJ = Math.floor(diffH / 24);
    if (diffJ < 7) return `Il y a ${diffJ} j`;
    return format(date, 'd MMM yyyy', { locale: fr });
  } catch {
    return '';
  }
}