/**
 * Distance haversine en kilomètres entre deux points GPS.
 */
export function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const toRad = (deg) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/**
 * Formate une distance en texte lisible.
 */
export function formatDistance(km) {
  if (km == null || Number.isNaN(km)) return '';
  if (km < 1) return `${Math.round(km * 1000)} m`;
  return `${km.toFixed(1)} km`;
}

/**
 * Génère l'URL d'itinéraire OpenStreetMap (gratuit, ouvre le navigateur
 * ou l'application de cartes du téléphone).
 */
export function getItineraireUrl(destLat, destLon, originLat, originLon) {
  if (originLat != null && originLon != null) {
    return `https://www.openstreetmap.org/directions?engine=fossgis_osrm_foot&route=${originLat}%2C${originLon}%3B${destLat}%2C${destLon}`;
  }
  return `https://www.openstreetmap.org/?mlat=${destLat}&mlon=${destLon}#map=16/${destLat}/${destLon}`;
}

/**
 * Centre et zoom par défaut de la carte (France entière).
 */
export const DEFAULT_CENTER = [1.888334, 46.603354];
export const DEFAULT_ZOOM = 5;

/**
 * Convertit des coordonnées {latitude, longitude} au format [longitude,
 * latitude] attendu par MapLibre.
 */
export function toLngLat(latitude, longitude) {
  return [longitude, latitude];
}

// Tri centralisé des maraudes (déjà filtrées par statut/ville en amont).
// mode : 'proximite' | 'bientot' | 'recentes'. Tri secondaire toujours :
// date_maraude croissante puis created_at décroissante.
export function sortMaraudesByProximity(maraudes, mode, location) {
  const withDistance = maraudes.map((m) => ({
    ...m,
    distanceKm:
      location && m.latitude != null && m.longitude != null
        ? haversineKm(location.latitude, location.longitude, m.latitude, m.longitude)
        : null,
  }));

  const compareDateAsc = (a, b) => new Date(a.date_maraude) - new Date(b.date_maraude);
  const compareCreatedDesc = (a, b) => new Date(b.created_at) - new Date(a.created_at);

  const withTieBreak = (primary) => (a, b) => {
    const primaryResult = primary(a, b);
    if (primaryResult !== 0) return primaryResult;
    const dateResult = compareDateAsc(a, b);
    if (dateResult !== 0) return dateResult;
    return compareCreatedDesc(a, b);
  };

  if (mode === 'proximite') {
    return [...withDistance].sort(
      withTieBreak((a, b) => {
        if (a.distanceKm == null && b.distanceKm == null) return 0;
        if (a.distanceKm == null) return 1;
        if (b.distanceKm == null) return -1;
        return a.distanceKm - b.distanceKm;
      })
    );
  }

  if (mode === 'recentes') {
    return [...withDistance].sort(withTieBreak(compareCreatedDesc));
  }

  // 'bientot' (par défaut) : identique au tri déjà en place aujourd'hui.
  return [...withDistance].sort(withTieBreak(compareDateAsc));
}