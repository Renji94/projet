const GENERIC_MESSAGE = 'Une erreur est survenue. Réessayez.';

const RAW_ERROR_PATTERNS = [
  /relation .* does not exist/i,
  /permission denied/i,
  /violates row-level security/i,
  /violates .* constraint/i,
  /\bJWT\b/,
  /duplicate key value/i,
  /invalid input syntax/i,
  /column .* does not exist/i,
  /function .* does not exist/i,
  /could not find a relationship/i,
  /schema cache/i,
];

/**
 * Renvoie un message d'erreur affichable à l'utilisateur : le message
 * d'origine s'il est déjà convivial, sinon un message générique — pour ne
 * jamais exposer une erreur Postgres/PostgREST brute. Le détail technique
 * reste visible dans les logs de développement (__DEV__).
 */
export function getFriendlyErrorMessage(error) {
  const message = error?.message || '';
  if (!message) return GENERIC_MESSAGE;
  if (RAW_ERROR_PATTERNS.some((pattern) => pattern.test(message))) {
    if (__DEV__) console.warn('[Erreur technique masquée]', message);
    return GENERIC_MESSAGE;
  }
  return message;
}
