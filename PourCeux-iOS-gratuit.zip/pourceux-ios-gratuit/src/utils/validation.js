import { z } from 'zod';
import { format, isBefore, isValid, parseISO, startOfDay } from 'date-fns';

export const loginSchema = z.object({
  email: z.string().email('Email invalide'),
  password: z.string().min(8, 'Le mot de passe doit contenir au moins 8 caractères'),
});

export const registerSchema = z
  .object({
    email: z.string().email('Email invalide'),
    password: z
      .string()
      .min(8, 'Le mot de passe doit contenir au moins 8 caractères')
      .regex(/[A-Z]/, 'Au moins une majuscule requise')
      .regex(/[0-9]/, 'Au moins un chiffre requis'),
    confirmPassword: z.string(),
    pseudo: z
      .string()
      .min(3, 'Le pseudo doit contenir au moins 3 caractères')
      .max(30, 'Le pseudo ne peut pas dépasser 30 caractères')
      .regex(/^[a-zA-Z0-9_-]+$/, 'Lettres, chiffres, tirets et underscores uniquement'),
    prenom: z.string().min(1, 'Prénom requis').max(50, 'Prénom trop long'),
    nom: z.string().min(1, 'Nom requis').max(50, 'Nom trop long'),
    telephone: z
      .string()
      .regex(/^\+?[0-9 ]{6,20}$/, 'Numéro de téléphone invalide')
      .optional()
      .or(z.literal('')),
    ville: z.string().min(1, 'Ville requise').max(100, 'Ville trop longue'),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'Les mots de passe ne correspondent pas',
    path: ['confirmPassword'],
  });

export const profileSchema = z.object({
  pseudo: z
    .string()
    .min(3, 'Le pseudo doit contenir au moins 3 caractères')
    .max(30, 'Le pseudo ne peut pas dépasser 30 caractères')
    .regex(/^[a-zA-Z0-9_-]+$/, 'Lettres, chiffres, tirets et underscores uniquement'),
  prenom: z.string().min(1, 'Prénom requis').max(50, 'Prénom trop long'),
  nom: z.string().min(1, 'Nom requis').max(50, 'Nom trop long'),
  telephone: z
    .string()
    .regex(/^\+?[0-9 ]{6,20}$/, 'Numéro de téléphone invalide')
    .optional()
    .or(z.literal('')),
  ville: z.string().min(1, 'Ville requise').max(100, 'Ville trop longue'),
});

const dateMaraudeSchema = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, 'Date invalide (AAAA-MM-JJ)')
  .refine((value) => {
    const parsed = parseISO(value);
    return isValid(parsed) && format(parsed, 'yyyy-MM-dd') === value;
  }, 'Cette date n’existe pas')
  .refine((value) => {
    const parsed = parseISO(value);
    return isValid(parsed) && !isBefore(parsed, startOfDay(new Date()));
  }, 'La date de la maraude ne peut pas être passée');

export const maraudeSchema = z
  .object({
    titre: z.string().min(3, 'Titre trop court (3 caractères min)').max(150, 'Titre trop long'),
    description: z
      .string()
      .min(10, 'Description trop courte (10 caractères min)')
      .max(5000, 'Description trop longue'),
    date_maraude: dateMaraudeSchema,
    heure_debut: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Heure invalide (HH:MM)'),
    heure_fin: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Heure invalide (HH:MM)'),
    ville: z.string().min(1, 'Ville requise'),
    adresse: z.string().min(3, 'Adresse requise'),
    latitude: z.number().min(-90).max(90),
    longitude: z.number().min(-180).max(180),
    max_participants: z
      .number({ invalid_type_error: 'Nombre requis' })
      .int('Nombre entier requis')
      .min(1, 'Au moins 1 participant')
      .max(500, 'Maximum 500 participants'),
    materiel_recommande: z.array(z.string()).default([]),
    difficulte: z.enum(['facile', 'moyen', 'difficile']),
  })
  .refine((data) => data.heure_fin > data.heure_debut, {
    message: "L'heure de fin doit être après l'heure de début",
    path: ['heure_fin'],
  });

export const signalementSchema = z.object({
  titre: z.string().min(3, 'Titre trop court (3 caractères min)').max(150, 'Titre trop long'),
  description: z
    .string()
    .min(5, 'Description trop courte (5 caractères min)')
    .max(5000, 'Description trop longue'),
  urgence: z.enum(['faible', 'moyenne', 'haute', 'critique']),
  latitude: z.number({ invalid_type_error: 'Position GPS requise' }).min(-90).max(90),
  longitude: z.number({ invalid_type_error: 'Position GPS requise' }).min(-180).max(180),
  adresse: z.string().optional().or(z.literal('')),
  nb_personnes: z
    .number({ invalid_type_error: 'Nombre requis' })
    .int()
    .min(1, 'Au moins 1 personne')
    .max(100, 'Maximum 100'),
  age_approximatif: z.string().optional().or(z.literal('')),
  animaux: z.boolean().default(false),
  besoins: z.array(z.string()).min(1, 'Sélectionnez au moins un besoin'),
  commentaires: z.string().max(2000, 'Commentaires trop longs').optional().or(z.literal('')),
});

export const messageSchema = z.object({
  contenu: z.string().min(1, 'Message vide').max(2000, 'Message trop long'),
});