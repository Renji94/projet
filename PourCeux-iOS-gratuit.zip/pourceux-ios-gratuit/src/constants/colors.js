export const COLORS = {
  primary: '#0E1F3D',
  primaryDark: '#071326',
  primaryLight: '#DFF4E8',
  secondary: '#B3E3C7',
  success: '#16A34A',
  danger: '#DC2626',
  warning: '#EA580C',
  info: '#0891B2',
  background: '#F8FAFC',
  surface: '#FFFFFF',
  text: '#0F172A',
  textSecondary: '#64748B',
  textLight: '#94A3B8',
  border: '#E2E8F0',
  disabled: '#CBD5E1',
  overlay: 'rgba(15, 23, 42, 0.5)',

  // Texte clair, pour du contenu affiché directement sur le fond dégradé sombre
  textOnDark: '#F1F5F9',
  textOnDarkSecondary: 'rgba(241, 245, 249, 0.7)',

  // Fond dégradé animé de l'application (bleu foncé -> bleu-gris -> gris bleuté)
  gradient: {
    blue: ['#0E1F3D', '#071326'],
    blueGray: ['#22344A', '#38495E'],
    softGray: ['#4A5568', '#5C6B7D'],
  },

  // Marqueurs de carte
  markerMaraude: '#16A34A',
  markerSignalement: '#DC2626',
  markerUser: '#16A34A',

  // Urgences
  urgenceFaible: '#16A34A',
  urgenceMoyenne: '#F59E0B',
  urgenceHaute: '#EA580C',
  urgenceCritique: '#DC2626',

  // Statuts maraude
  statutProgrammee: '#0E1F3D',
  statutEnCours: '#16A34A',
  statutTerminee: '#64748B',
  statutAnnulee: '#DC2626',

  // Statuts signalement
  statutOuvert: '#DC2626',
  statutPrisEnCharge: '#F59E0B',
  statutResolu: '#16A34A',
  statutIntrouvable: '#64748B',
  statutFausseAlerte: '#94A3B8',
};