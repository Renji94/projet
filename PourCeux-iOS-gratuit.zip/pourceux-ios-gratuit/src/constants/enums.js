export const MARAUDE_STATUTS = {
  programmee: { label: 'Programmée', color: '#1D4ED8' },
  en_cours: { label: 'En cours', color: '#16A34A' },
  terminee: { label: 'Terminée', color: '#64748B' },
  annulee: { label: 'Annulée', color: '#DC2626' },
};

export const DIFFICULTES = {
  facile: { label: 'Facile', color: '#16A34A' },
  moyen: { label: 'Moyen', color: '#F59E0B' },
  difficile: { label: 'Difficile', color: '#DC2626' },
};

export const URGENCES = {
  faible: { label: 'Faible', color: '#16A34A' },
  moyenne: { label: 'Moyenne', color: '#F59E0B' },
  haute: { label: 'Haute', color: '#EA580C' },
  critique: { label: 'Critique', color: '#DC2626' },
};

export const SIGNALEMENT_STATUTS = {
  ouvert: { label: 'Ouvert', color: '#DC2626' },
  pris_en_charge: { label: 'Pris en charge', color: '#F59E0B' },
  resolu: { label: 'Résolu', color: '#16A34A' },
  toujours_present: { label: 'Toujours présent', color: '#EA580C' },
  introuvable: { label: 'Introuvable', color: '#64748B' },
  fausse_alerte: { label: 'Fausse alerte', color: '#94A3B8' },
};

export const BESOINS = [
  { value: 'nourriture', label: 'Nourriture', icon: 'food' },
  { value: 'eau', label: 'Eau', icon: 'water' },
  { value: 'vetements', label: 'Vêtements', icon: 'tshirt-crew' },
  { value: 'couverture', label: 'Couverture', icon: 'bed' },
  { value: 'medicaments', label: 'Médicaments', icon: 'pill' },
  { value: 'hebergement', label: 'Hébergement', icon: 'home' },
  { value: 'autres', label: 'Autres', icon: 'dots-horizontal' },
];

export const CLOTURE_OPTIONS = [
  { value: 'resolu', label: 'Résolu' },
  { value: 'toujours_present', label: 'Toujours présent' },
  { value: 'introuvable', label: 'Impossible à trouver' },
  { value: 'fausse_alerte', label: 'Fausse alerte' },
];