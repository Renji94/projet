const required = (name, value) => {
  if (!value || value.includes('your_') || value.includes('your-project')) {
    return '';
  }
  return value;
};

const appContactEmail = (process.env.EXPO_PUBLIC_APP_CONTACT_EMAIL || '').trim();
const nominatimUrl =
  process.env.EXPO_PUBLIC_NOMINATIM_URL || 'https://nominatim.openstreetmap.org';

export const CONFIG = {
  SUPABASE_URL: required('EXPO_PUBLIC_SUPABASE_URL', process.env.EXPO_PUBLIC_SUPABASE_URL || ''),
  SUPABASE_KEY: required(
    'EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY',
    process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
      process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ||
      ''
  ),
  EAS_PROJECT_ID: process.env.EXPO_PUBLIC_EAS_PROJECT_ID || '',
  NOMINATIM_URL: nominatimUrl,
  APP_CONTACT_EMAIL: appContactEmail,
  NOMINATIM_USER_AGENT: appContactEmail
    ? `PourCeux/1.0 (${appContactEmail})`
    : 'PourCeux/1.0',
  OSM_TILE_URL:
    process.env.EXPO_PUBLIC_OSM_TILE_URL ||
    'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
  MAP_STYLE_URL:
    process.env.EXPO_PUBLIC_MAP_STYLE_URL ||
    'https://tiles.openfreemap.org/styles/liberty',
  DEFAULT_RADIUS_KM: 50,
  RADIUS_OPTIONS: [5, 10, 20, 50, 100],
  CHAT_HISTORY_LIMIT: 200,
};

export const getMissingConfig = () => {
  const missing = [];
  if (!CONFIG.SUPABASE_URL) missing.push('EXPO_PUBLIC_SUPABASE_URL');
  if (!CONFIG.SUPABASE_KEY) missing.push('EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY');
  if (
    CONFIG.NOMINATIM_URL.includes('nominatim.openstreetmap.org') &&
    !CONFIG.APP_CONTACT_EMAIL
  ) {
    missing.push('EXPO_PUBLIC_APP_CONTACT_EMAIL');
  }
  return missing;
};
