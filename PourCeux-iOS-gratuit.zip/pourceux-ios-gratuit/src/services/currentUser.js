import { supabase } from './supabase';

export async function getCurrentUserId() {
  const { data, error } = await supabase.auth.getUser();
  if (error) throw new Error(error.message);
  if (!data.user?.id) throw new Error('Session expirée. Reconnectez-vous.');
  return data.user.id;
}
