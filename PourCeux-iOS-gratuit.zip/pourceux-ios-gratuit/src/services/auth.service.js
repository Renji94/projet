import { supabase } from './supabase';

const EMAIL_REDIRECT_TO = 'pourceux://auth/callback';

export const authService = {
  async signIn({ email, password }) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email: email.trim().toLowerCase(),
      password,
    });

    if (error) {
      throw new Error(traduireErreurAuth(error.message));
    }

    return data;
  },

  async signUp({
    email,
    password,
    pseudo,
    prenom,
    nom,
    telephone,
    ville,
  }) {
    const { data, error } = await supabase.auth.signUp({
      email: email.trim().toLowerCase(),
      password,
      options: {
        emailRedirectTo: EMAIL_REDIRECT_TO,
        data: {
          pseudo: pseudo.trim(),
          prenom: prenom.trim(),
          nom: nom.trim(),
          telephone: telephone?.trim() || '',
          ville: ville.trim(),
        },
      },
    });

    if (error) {
      throw new Error(traduireErreurAuth(error.message));
    }

    return data;
  },

  async signOut() {
    const { error } = await supabase.auth.signOut();

    if (error) {
      throw new Error(traduireErreurAuth(error.message));
    }
  },

  async getSession() {
    const { data, error } = await supabase.auth.getSession();

    if (error) {
      throw new Error(traduireErreurAuth(error.message));
    }

    return data.session;
  },

  onAuthStateChange(callback) {
    const { data } = supabase.auth.onAuthStateChange((_event, session) => {
      callback(session);
    });

    return data.subscription;
  },

  async createSessionFromUrl(url) {
    if (!url) return null;

    const params = extraireParametresUrl(url);

    const errorDescription = params.get('error_description');
    const errorCode = params.get('error_code');

    if (errorDescription || errorCode) {
      throw new Error(
        traduireErreurAuth(
          errorDescription ||
            errorCode ||
            'La confirmation de l’adresse email a échoué.'
        )
      );
    }

    /*
     * Nouveau flux utilisé par le modèle d’email :
     * pourceux://auth/callback?token_hash=...&type=email
     */
    const tokenHash = params.get('token_hash');

    if (tokenHash) {
      const { data, error } = await supabase.auth.verifyOtp({
        token_hash: tokenHash,
        type: 'email',
      });

      if (error) {
        throw new Error(traduireErreurAuth(error.message));
      }

      return data.session ?? null;
    }

    /*
     * Ancien flux conservé comme solution de secours :
     * #access_token=...&refresh_token=...
     */
    const accessToken = params.get('access_token');
    const refreshToken = params.get('refresh_token');

    if (accessToken && refreshToken) {
      const { data, error } = await supabase.auth.setSession({
        access_token: accessToken,
        refresh_token: refreshToken,
      });

      if (error) {
        throw new Error(traduireErreurAuth(error.message));
      }

      return data.session ?? null;
    }

    /*
     * Aucun paramètre d’authentification exploitable.
     * Une simple ouverture de pourceux://auth/callback
     * ne doit pas provoquer d’erreur.
     */
    return null;
  },
};

/**
 * Récupère les paramètres placés dans la query string et/ou le fragment.
 *
 * Exemples :
 * ?token_hash=...&type=email
 * #access_token=...&refresh_token=...
 */
function extraireParametresUrl(url) {
  const params = new URLSearchParams();

  const queryIndex = url.indexOf('?');
  const hashIndex = url.indexOf('#');

  if (queryIndex !== -1) {
    const queryEnd =
      hashIndex !== -1 && hashIndex > queryIndex
        ? hashIndex
        : url.length;

    const queryParams = new URLSearchParams(
      url.slice(queryIndex + 1, queryEnd)
    );

    queryParams.forEach((value, key) => {
      params.set(key, value);
    });
  }

  if (hashIndex !== -1) {
    const hashParams = new URLSearchParams(
      url.slice(hashIndex + 1)
    );

    hashParams.forEach((value, key) => {
      params.set(key, value);
    });
  }

  return params;
}

function traduireErreurAuth(message) {
  const map = {
    'Invalid login credentials':
      'Email ou mot de passe incorrect.',

    'User already registered':
      'Un compte existe déjà avec cet email.',

    'Email not confirmed':
      'Veuillez confirmer votre adresse email avant de vous connecter.',

    'Password should be at least 6 characters':
      'Le mot de passe doit contenir au moins 6 caractères.',

    'Email link is invalid or has expired':
      'Le lien de confirmation est invalide ou a expiré.',

    'Token has expired or is invalid':
      'Le lien de confirmation est invalide ou a expiré.',

    'Token has expired':
      'Le lien de confirmation a expiré.',

    'otp_expired':
      'Le lien de confirmation est invalide ou a expiré.',

    'Email rate limit exceeded':
      'Trop d’emails ont été envoyés. Réessayez plus tard.',

    'For security purposes, you can only request this after':
      'Veuillez patienter avant de demander un nouvel email.',
  };

  return map[message] || message;
}