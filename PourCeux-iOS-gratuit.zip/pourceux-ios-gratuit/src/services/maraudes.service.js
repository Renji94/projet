import { supabase } from './supabase';
import { getCurrentUserId } from './currentUser';

const MARAUDE_SELECT = `
  *,
  createur:profiles!maraudes_createur_id_fkey(id, pseudo, avatar_url),
  chat:chats(id)
`;

export const maraudesService = {
  async list({ statut = null, ville = '' } = {}) {
    let query = supabase
      .from('maraudes')
      .select(MARAUDE_SELECT)
      .order('date_maraude', { ascending: true });
    if (statut) query = query.eq('statut', statut);
    if (ville) query = query.ilike('ville', `%${ville}%`);
    const { data, error } = await query;
    if (error) throw new Error(error.message);
    return data;
  },

  async getById(id) {
    const { data, error } = await supabase
      .from('maraudes')
      .select(MARAUDE_SELECT)
      .eq('id', id)
      .single();
    if (error) throw new Error(error.message);
    return data;
  },

  async getParticipants(maraudeId) {
    const { data, error } = await supabase
      .from('maraude_participants')
      .select('joined_at, user:profiles(id, pseudo, prenom, nom, ville, avatar_url)')
      .eq('maraude_id', maraudeId)
      .order('joined_at', { ascending: true });
    if (error) throw new Error(error.message);
    return data;
  },

  async create(payload) {
    const userId = await getCurrentUserId();
    const { data, error } = await supabase
      .from('maraudes')
      .insert({ ...payload, createur_id: userId })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return data;
  },

  async update(id, payload) {
    const { data, error } = await supabase
      .from('maraudes')
      .update(payload)
      .eq('id', id)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return data;
  },

  async remove(id) {
    const { error } = await supabase.from('maraudes').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },

  async setStatut(id, statut) {
    const { error } = await supabase.from('maraudes').update({ statut }).eq('id', id);
    if (error) throw new Error(error.message);
  },

  async rejoindre(maraudeId) {
    const { data, error } = await supabase.rpc('rejoindre_maraude', {
      p_maraude_id: maraudeId,
    });
    if (error) throw new Error(error.message);
    if (!data.success) throw new Error(data.error);
    return data;
  },

  async quitter(maraudeId) {
    const { data, error } = await supabase.rpc('quitter_maraude', {
      p_maraude_id: maraudeId,
    });
    if (error) throw new Error(error.message);
    if (!data.success) throw new Error(data.error);
    return data;
  },

  async isParticipant(maraudeId, userId) {
    const { data, error } = await supabase
      .from('maraude_participants')
      .select('id')
      .eq('maraude_id', maraudeId)
      .eq('user_id', userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return Boolean(data);
  },
};