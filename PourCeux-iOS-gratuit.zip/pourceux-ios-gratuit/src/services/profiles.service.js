import { supabase } from './supabase';

function assertRpc(data, error) {
  if (error) throw new Error(error.message);
  if (data?.success === false) throw new Error(data.error || 'Opération refusée.');
  return data?.profile ?? data;
}

export const profilesService = {
  async getMyProfile() {
    const { data, error } = await supabase.rpc('get_my_profile');
    return assertRpc(data, error);
  },

  async updateProfile(_userId, { pseudo, prenom, nom, telephone, ville }) {
    const { data, error } = await supabase.rpc('update_my_profile', {
      p_pseudo: pseudo,
      p_prenom: prenom,
      p_nom: nom,
      p_telephone: telephone || null,
      p_ville: ville,
    });
    try {
      return assertRpc(data, error);
    } catch (e) {
      if (error?.code === '23505' || e.message.includes('pseudo')) {
        throw new Error('Ce pseudo est déjà utilisé.');
      }
      throw e;
    }
  },

  async updatePosition(_userId, latitude, longitude) {
    const { data, error } = await supabase.rpc('update_my_position', {
      p_latitude: latitude,
      p_longitude: longitude,
    });
    return assertRpc(data, error);
  },

  async getStats(userId) {
    const { data, error } = await supabase.rpc('get_profile_stats', { p_user_id: userId });
    if (error) throw new Error(error.message);
    return data;
  },

  async getHistorique(userId) {
    const { data, error } = await supabase
      .from('maraude_participants')
      .select('joined_at, maraudes(id, titre, date_maraude, ville, statut)')
      .eq('user_id', userId)
      .order('joined_at', { ascending: false });
    if (error) throw new Error(error.message);
    return data;
  },

  async listUsers(search = '') {
    const { data, error } = await supabase.rpc('admin_list_users', {
      p_search: search.trim() || null,
    });
    if (error) throw new Error(error.message);
    return data;
  },

  async setSuspended(userId, suspended) {
    const { data, error } = await supabase.rpc('admin_set_user_suspended', {
      p_user_id: userId,
      p_suspended: suspended,
    });
    return assertRpc(data, error);
  },

  async setRole(userId, role) {
    const { data, error } = await supabase.rpc('admin_set_user_role', {
      p_user_id: userId,
      p_role: role,
    });
    return assertRpc(data, error);
  },
};
