import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import { supabase } from './supabase';
import { CONFIG } from '../constants/config';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export const notificationsService = {
  async registerForPushNotifications() {
    if (!Device.isDevice || Platform.OS === 'web') return null;

    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'Signalements et maraudes',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#1D4ED8',
      });
    }

    const current = await Notifications.getPermissionsAsync();
    const finalStatus =
      current.status === 'granted'
        ? current.status
        : (await Notifications.requestPermissionsAsync()).status;
    if (finalStatus !== 'granted') return null;

    const projectId =
      Constants.easConfig?.projectId ||
      Constants.expoConfig?.extra?.eas?.projectId ||
      CONFIG.EAS_PROJECT_ID;
    if (!projectId) {
      console.warn('[Notifications] EXPO_PUBLIC_EAS_PROJECT_ID manquant.');
      return null;
    }

    const token = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
    const { data, error } = await supabase.rpc('register_push_token', {
      p_token: token,
      p_platform: Platform.OS,
    });
    if (error) throw new Error(error.message);
    if (!data?.success) throw new Error(data?.error || 'Enregistrement du token impossible.');
    return token;
  },

  subscribeToUserNotifications(userId, onNotification) {
    const channel = supabase
      .channel(`notifications-${userId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${userId}`,
        },
        (payload) => onNotification?.(payload.new)
      )
      .subscribe();
    return () => supabase.removeChannel(channel);
  },

  addResponseListener(callback) {
    return Notifications.addNotificationResponseReceivedListener((response) => {
      callback(response.notification.request.content.data || {});
    });
  },

  async consumeLastResponse() {
    const response = await Notifications.getLastNotificationResponseAsync();
    const data = response?.notification?.request?.content?.data || null;
    if (response) await Notifications.clearLastNotificationResponseAsync();
    return data;
  },

  async list(userId) {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(100);
    if (error) throw new Error(error.message);
    return data;
  },

  async markAllRead(userId) {
    const { error } = await supabase
      .from('notifications')
      .update({ lu: true })
      .eq('user_id', userId)
      .eq('lu', false);
    if (error) throw new Error(error.message);
  },
};
