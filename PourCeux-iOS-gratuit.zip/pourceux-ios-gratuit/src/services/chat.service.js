import { supabase } from './supabase';
import { CONFIG } from '../constants/config';
import { getCurrentUserId } from './currentUser';

// Pas d'embed récursif reply:messages!... ici : PostgREST résout mal les
// relations auto-référencées de ce type sur ce projet. La citation est
// résolue à la place par une requête groupée côté JS (voir attachReplies),
// aussi bien pour le chargement initial que pour les événements Realtime.
const MESSAGE_SELECT = `
  *,
  auteur:profiles!messages_user_id_fkey(id, pseudo, avatar_url)
`;

const REPLY_TARGET_SELECT = 'id, contenu, type, is_deleted, auteur:profiles!messages_user_id_fkey(pseudo)';

// Résolution groupée des messages cités : une seule requête .in('id', ...)
// pour tout un lot de messages, jamais une requête par message (pas de N+1).
async function attachReplies(rows) {
  const replyIds = [...new Set(rows.map((m) => m.reply_to).filter(Boolean))];
  if (replyIds.length === 0) {
    return rows.map((m) => ({ ...m, reply: null }));
  }
  const { data: replies, error } = await supabase
    .from('messages')
    .select(REPLY_TARGET_SELECT)
    .in('id', replyIds);
  if (error) throw new Error(error.message);
  const repliesById = new Map((replies || []).map((r) => [r.id, r]));
  return rows.map((m) => ({
    ...m,
    reply: m.reply_to ? repliesById.get(m.reply_to) || null : null,
  }));
}

export const chatService = {
  async getMessages(chatId) {
    const query = supabase
      .from('messages')
      .select(MESSAGE_SELECT)
      .eq('chat_id', chatId)
      .order('created_at', { ascending: false })
      .limit(CONFIG.CHAT_HISTORY_LIMIT);
    const { data, error } = await query;
    if (error) throw new Error(error.message);
    const withReplies = await attachReplies(data || []);
    return withReplies.reverse();
  },

  // Écriture sans embed relationnel : l'envoi ne doit jamais échouer à cause
  // d'un problème de résolution de relation (reply/auteur) côté PostgREST.
  // L'appelant (useChat) reconstruit auteur/reply localement à partir du
  // contexte déjà connu (profil courant, message cité).
  async sendText(chatId, contenu, replyTo = null) {
    const userId = await getCurrentUserId();
    const { data, error } = await supabase
      .from('messages')
      .insert({
        chat_id: chatId,
        user_id: userId,
        type: 'texte',
        contenu: contenu.trim(),
        reply_to: replyTo,
      })
      .select('*')
      .single();
    if (error) throw new Error(error.message);
    return data;
  },

  async sendLocation(chatId, latitude, longitude) {
    const userId = await getCurrentUserId();
    const { data, error } = await supabase
      .from('messages')
      .insert({
        chat_id: chatId,
        user_id: userId,
        type: 'localisation',
        latitude,
        longitude,
      })
      .select('*')
      .single();
    if (error) throw new Error(error.message);
    return data;
  },

  async markAsRead(chatId) {
    const userId = await getCurrentUserId();
    const { error } = await supabase.from('message_reads').upsert(
      {
        chat_id: chatId,
        user_id: userId,
        last_read_at: new Date().toISOString(),
      },
      { onConflict: 'chat_id,user_id' }
    );
    if (error) throw new Error(error.message);
  },

  // Écriture sans embed : voir la note sur sendText. useChat fusionne
  // localement is_deleted: true sur le message déjà connu, sans dépendre
  // de l'embed serveur (jamais affiché une fois is_deleted de toute façon).
  async deleteMessage(messageId) {
    const { data, error } = await supabase
      .from('messages')
      .update({ is_deleted: true })
      .eq('id', messageId)
      .select('id')
      .single();
    if (error) throw new Error(error.message);
    return data;
  },

  subscribeToMessages(chatId, onMessageChange) {
    const channel = supabase
      .channel(`chat-${chatId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'messages',
          filter: `chat_id=eq.${chatId}`,
        },
        async (payload) => {
          if (payload.eventType === 'DELETE') return;
          // Récupérer le message complet avec son auteur (embed simple)
          const { data, error } = await supabase
            .from('messages')
            .select(MESSAGE_SELECT)
            .eq('id', payload.new.id)
            .single();
          if (error) {
            if (__DEV__) console.warn('[Realtime messages] fetch enrichi échoué :', error.message);
            return;
          }
          if (!data) return;
          const [withReply] = await attachReplies([data]);
          onMessageChange(withReply, payload.eventType);
        }
      )
      .subscribe();
    return () => supabase.removeChannel(channel);
  },
};