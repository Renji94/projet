import AsyncStorage from '@react-native-async-storage/async-storage';

const PREFIX = '@pourceux/';

// Wrapper centralisé au-dessus d'AsyncStorage pour les préférences locales
// (langue, tri par défaut, etc.). Ne jamais y stocker de secret.
export async function getPreference(key, fallback = null) {
  try {
    const raw = await AsyncStorage.getItem(PREFIX + key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

export async function setPreference(key, value) {
  try {
    await AsyncStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    // Une préférence non persistée ne doit jamais bloquer l'application.
  }
}
