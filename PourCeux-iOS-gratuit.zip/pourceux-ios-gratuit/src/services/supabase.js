import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { AppState } from 'react-native';
import { CONFIG, getMissingConfig } from '../constants/config';

const missing = getMissingConfig();

if (missing.length > 0) {
  console.warn(`[Configuration] Variables manquantes : ${missing.join(', ')}`);
}

// Des valeurs invalides empêchent Supabase de démarrer avant que l'écran de
// configuration puisse expliquer le problème. Ces URLs ne sont jamais utilisées
// lorsque la configuration est absente, car RootNavigator bloque l'application.
const fallbackUrl = 'https://invalid.localhost';
const fallbackKey = 'invalid-publishable-key';

export const supabase = createClient(
  CONFIG.SUPABASE_URL || fallbackUrl,
  CONFIG.SUPABASE_KEY || fallbackKey,
  {
    auth: {
      storage: AsyncStorage,
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
    realtime: {
      params: { eventsPerSecond: 10 },
    },
  }
);

let appStateSubscription;

export function startSupabaseAutoRefresh() {
  if (appStateSubscription) return () => {};

  if (AppState.currentState === 'active') {
    supabase.auth.startAutoRefresh();
  }

  appStateSubscription = AppState.addEventListener('change', (state) => {
    if (state === 'active') supabase.auth.startAutoRefresh();
    else supabase.auth.stopAutoRefresh();
  });

  return () => {
    appStateSubscription?.remove();
    appStateSubscription = undefined;
    supabase.auth.stopAutoRefresh();
  };
}
