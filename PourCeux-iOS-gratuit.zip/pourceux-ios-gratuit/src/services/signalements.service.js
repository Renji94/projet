import { supabase } from './supabase';
import { getCurrentUserId } from './currentUser';

const SIGNALEMENT_SELECT = `
  *,
  createur:profiles!signalements_createur_id_fkey(id, pseudo, avatar_url),
  responsable:profiles!signalements_pris_en_charge_par_fkey(id, pseudo, avatar_url),
  chat:chats(id)
`;

export const signalementsService = {
  async list({ statut = null, urgence = null } = {}) {
    let query = supabase
      .from('signalements')
      .select(SIGNALEMENT_SELECT)
      .order('created_at', { ascending: false });
    if (statut) query = query.eq('statut', statut);
    if (urgence) query = query.eq('urgence', urgence);
    const { data, error } = await query;
    if (error) throw new Error(error.message);
    return data;
  },

  async getById(id) {
    const { data, error } = await supabase
      .from('signalements')
      .select(SIGNALEMENT_SELECT)
      .eq('id', id)
      .single();
    if (error) throw new Error(error.message);
    return data;
  },

  async create(payload) {
    const userId = await getCurrentUserId();
    const { data, error } = await supabase
      .from('signalements')
      .insert({ ...payload, createur_id: userId })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return data;
  },

  async remove(id) {
    const { error } = await supabase.from('signalements').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },

  async prendreEnCharge(signalementId) {
    const { data, error } = await supabase.rpc('prendre_en_charge_signalement', {
      p_signalement_id: signalementId,
    });
    if (error) throw new Error(error.message);
    if (!data.success) throw new Error(data.error);
    return data;
  },

  async cloturer(signalementId, statut) {
    const { data, error } = await supabase.rpc('cloturer_signalement', {
      p_signalement_id: signalementId,
      p_statut: statut,
    });
    if (error) throw new Error(error.message);
    if (!data.success) throw new Error(data.error);
    return data;
  },

  async getEvenementsProches(latitude, longitude, rayonKm) {
    const { data, error } = await supabase.rpc('get_evenements_proches', {
      p_lat: latitude,
      p_lon: longitude,
      p_rayon_km: rayonKm,
    });
    if (error) throw new Error(error.message);
    return data;
  },

  subscribeToChanges(callback) {
    const channel = supabase
      .channel('signalements-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'signalements' },
        callback
      )
      .subscribe();
    return () => supabase.removeChannel(channel);
  },
};