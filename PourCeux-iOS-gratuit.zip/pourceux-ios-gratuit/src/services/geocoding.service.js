import axios from 'axios';
import { CONFIG } from '../constants/config';

const client = axios.create({
  baseURL: CONFIG.NOMINATIM_URL,
  timeout: 10000,
  headers: {
    'User-Agent': CONFIG.NOMINATIM_USER_AGENT,
    'Accept-Language': 'fr',
  },
});

const cache = new Map();
let lastRequestAt = 0;

async function rateLimitedGet(path, params) {
  const key = `${path}:${JSON.stringify(params)}`;
  if (cache.has(key)) return cache.get(key);

  const waitMs = Math.max(0, 1100 - (Date.now() - lastRequestAt));
  if (waitMs > 0) await new Promise((resolve) => setTimeout(resolve, waitMs));
  lastRequestAt = Date.now();

  const requestParams = CONFIG.APP_CONTACT_EMAIL
    ? { ...params, email: CONFIG.APP_CONTACT_EMAIL }
    : params;
  const { data } = await client.get(path, { params: requestParams });
  cache.set(key, data);
  if (cache.size > 100) cache.delete(cache.keys().next().value);
  return data;
}

export const geocodingService = {
  async search(query) {
    const normalized = query?.trim();
    if (!normalized || normalized.length < 3) return [];
    const data = await rateLimitedGet('/search', {
      q: normalized,
      format: 'jsonv2',
      limit: 5,
      countrycodes: 'fr,be,ch,lu,mc',
      addressdetails: 1,
    });
    return data.map((item) => ({
      label: item.display_name,
      latitude: Number(item.lat),
      longitude: Number(item.lon),
      ville:
        item.address?.city ||
        item.address?.town ||
        item.address?.village ||
        item.address?.municipality ||
        '',
    }));
  },

  async reverse(latitude, longitude) {
    const data = await rateLimitedGet('/reverse', {
      lat: Number(latitude).toFixed(6),
      lon: Number(longitude).toFixed(6),
      format: 'jsonv2',
      addressdetails: 1,
    });
    return {
      label: data.display_name || '',
      ville:
        data.address?.city ||
        data.address?.town ||
        data.address?.village ||
        data.address?.municipality ||
        '',
    };
  },
};
