import { supabase } from './supabase';
import { getCurrentUserId } from './currentUser';

const LAST_MESSAGE_SELECT = 'contenu, type, created_at';

function normaliseChat(row, titre) {
  const lastMessage = row.messages?.[0] || null;
  return {
    id: row.id,
    type: row.type,
    titre: titre || 'Discussion',
    lastMessage,
    lastActivity: lastMessage?.created_at || row.created_at,
  };
}

export const conversationsService = {
  async list() {
    const userId = await getCurrentUserId();

    // Chats de maraude : la RLS (can_access_chat) limite déjà exactement
    // aux maraudes créées ou rejointes par l'utilisateur, aucun filtre
    // applicatif supplémentaire n'est nécessaire ici.
    const maraudeChatsQuery = supabase
      .from('chats')
      .select(
        `
        id,
        type,
        created_at,
        maraude:maraudes(id, titre),
        messages(${LAST_MESSAGE_SELECT})
      `
      )
      .eq('type', 'maraude')
      .order('created_at', { foreignTable: 'messages', ascending: false })
      .limit(1, { foreignTable: 'messages' });

    // Chats de signalement : la RLS autorise tout utilisateur connecté
    // non suspendu (accès large, volontaire), donc on ajoute ici un filtre
    // applicatif plus restrictif pour ne montrer que les signalements créés
    // ou pris en charge par l'utilisateur — sans jamais élargir la RLS.
    const signalementChatsQuery = supabase
      .from('chats')
      .select(
        `
        id,
        type,
        created_at,
        signalement:signalements!inner(id, titre, createur_id, pris_en_charge_par),
        messages(${LAST_MESSAGE_SELECT})
      `
      )
      .eq('type', 'signalement')
      .or(`createur_id.eq.${userId},pris_en_charge_par.eq.${userId}`, {
        foreignTable: 'signalements',
      })
      .order('created_at', { foreignTable: 'messages', ascending: false })
      .limit(1, { foreignTable: 'messages' });

    const [
      { data: maraudeData, error: maraudeError },
      { data: signalementData, error: signalementError },
    ] = await Promise.all([maraudeChatsQuery, signalementChatsQuery]);

    if (maraudeError) throw new Error(maraudeError.message);
    if (signalementError) throw new Error(signalementError.message);

    const conversations = [
      ...(maraudeData || []).map((row) => normaliseChat(row, row.maraude?.titre)),
      ...(signalementData || []).map((row) => normaliseChat(row, row.signalement?.titre)),
    ];

    conversations.sort((a, b) => new Date(b.lastActivity) - new Date(a.lastActivity));
    return conversations;
  },
};
