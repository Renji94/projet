// No native gesture-handler bootstrap is required on web.
