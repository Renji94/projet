# Validation des icônes — PourCeux

Le projet utilise `@expo/vector-icons` dans le code applicatif.

`react-native-paper` référence statiquement le paquet
`@react-native-vector-icons/material-design-icons`. Pour éviter un échec de
résolution Metro sans ajouter de Config Plugin Expo invalide, le projet fournit
un paquet local minimal dans `vendor/material-design-icons-shim`.

Ce paquet est une dépendance npm locale, pas un plugin Expo. La section
`expo.plugins` reste limitée à `expo-location` et `expo-notifications`.
