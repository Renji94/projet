const { defineConfig } = require('eslint/config');
const expoConfig = require('eslint-config-expo/flat');

module.exports = defineConfig([
  {
    ignores: ['dist/**', 'dist-web/**', 'dist-android/**', 'dist-ios/**', '.expo/**', 'supabase/functions/**'],
  },
  expoConfig,
  {
    rules: {
      'no-console': ['warn', { allow: ['warn', 'error'] }],
      'react/prop-types': 'off',
      'react/no-unescaped-entities': 'off',
      'react-hooks/incompatible-library': 'off',
      'import/no-named-as-default-member': 'off',
    },
  },
]);
