# PourCeux

Application mobile de coordination de maraudes et de signalements, construite avec React Native, Expo et Supabase.

## État de cette version

Cette branche a été auditée et remise à niveau pour une V0 mobile exploitable :

- Expo SDK 56, React Native 0.85 et React 19 ;
- navigation React Navigation 7 ;
- authentification email Supabase ;
- rôles `user` / `admin` contrôlés côté base ;
- maraudes, inscriptions, signalements, carte et chats temps réel ;
- notifications distantes via Expo Push + Supabase Edge Function ;
- politiques RLS durcies et fonctions `SECURITY DEFINER` verrouillées ;
- configuration EAS Android/iOS ;
- fallback Web explicite pour la carte native.

La portée V0 reste volontairement limitée : messages texte et positions uniquement, sans médias, réactions, badges, statistiques avancées, OAuth ni récupération de mot de passe.

## Prérequis

- Node.js `>= 20.19.4`
- npm
- un projet Supabase
- un compte Expo/EAS pour les builds et les notifications distantes
- un appareil ou un émulateur Android/iOS

## Installation

```bash
npm install
cp .env.example .env
```

Renseigner ensuite :

```dotenv
EXPO_PUBLIC_SUPABASE_URL=https://<project-ref>.supabase.co
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=<clé-publishable>
EXPO_PUBLIC_EAS_PROJECT_ID=<uuid-du-projet-eas>
EXPO_PUBLIC_NOMINATIM_URL=https://nominatim.openstreetmap.org
EXPO_PUBLIC_OSM_TILE_URL=https://tile.openstreetmap.org/{z}/{x}/{y}.png
EXPO_PUBLIC_APP_CONTACT_EMAIL=contact@votre-domaine.fr
```

Ne jamais utiliser la clé `service_role` dans l’application Expo.

`EXPO_PUBLIC_APP_CONTACT_EMAIL` est obligatoire lorsque l’endpoint public `nominatim.openstreetmap.org` est utilisé. Cette valeur identifie proprement l’application auprès du service de géocodage.

## Démarrage

```bash
npm run start
```

Autres commandes :

```bash
npm run android
npm run ios
npm run web
npm run lint
npm run doctor
```

Le Web permet de vérifier l’interface générale. La carte `MapLibre` est une fonctionnalité mobile ; l’écran Web affiche donc un fallback et un lien OpenStreetMap.


## Configuration des icônes

Cette version utilise exclusivement la bibliothèque fournie par Expo :

```js
import { MaterialCommunityIcons } from '@expo/vector-icons';
```

`@react-native-vector-icons/material-design-icons` ne doit être ajouté ni aux dépendances, ni à `plugins` dans `app.json`, ni à `metro.config.js`. Le `metro.config.js` doit rester basé sur `getDefaultConfig` sans alias spécifique aux icônes.

Les contrôles réalisés sur cette archive confirment :

- aucune référence restante à l’ancien package ;
- résolution des deux seuls Config Plugins réels : `expo-location` et `expo-notifications` ;
- génération native réussie avec `expo prebuild` ;
- exports Android, iOS et Web réussis ;
- `eas build:configure` atteint la demande de connexion Expo sans erreur de plugin.

## Base Supabase

### Nouveau projet Supabase

Exécuter les migrations dans cet ordre :

1. `supabase/migrations/001_schema.sql`
2. `supabase/migrations/002_functions_triggers.sql`
3. `supabase/migrations/003_rls_policies.sql`
4. `supabase/migrations/005_security_hardening.sql`
5. `supabase/migrations/006_push_notifications.sql`

Le stockage d’avatars a été retiré de la V0. Il n’existe donc volontairement aucun fichier actif `004_*.sql`. L’ancienne migration 004 est conservée hors séquence dans `supabase/optional/avatars.sql` pour une version future.

### Base existante

Si les migrations actives `001` à `003` ont déjà été exécutées, ne pas les rejouer. Si l’ancienne migration avatars 004 avait aussi été exécutée auparavant, ce n’est pas bloquant. Exécuter uniquement :

1. `005_security_hardening.sql`
2. `006_push_notifications.sql`

Ces migrations conservent les tables existantes et corrigent les autorisations sans supprimer les données.

### Premier administrateur

Après la création du compte concerné, exécuter dans le SQL Editor Supabase :

```sql
update public.profiles
set role = 'admin'
where id = '<UUID_AUTH_USER>';
```

Le rôle ne doit jamais être modifié directement depuis le client.

## Notifications push distantes

La réception lorsque l’application est fermée nécessite un traitement serveur. Le projet contient `supabase/functions/send-push-notifications/index.js`.

### 1. Initialiser et relier EAS

```bash
npx eas-cli@20.5.1 login
npx eas-cli@20.5.1 init
```

Reporter le `projectId` obtenu dans `EXPO_PUBLIC_EAS_PROJECT_ID`.

### 2. Déployer l’Edge Function

Depuis un projet Supabase initialisé en CLI :

```bash
supabase functions deploy send-push-notifications --no-verify-jwt
supabase secrets set PUSH_WEBHOOK_SECRET="<secret-long-et-aleatoire>"
```

Les variables `SUPABASE_URL` et `SUPABASE_SERVICE_ROLE_KEY` sont fournies automatiquement aux Edge Functions hébergées par Supabase.

### 3. Créer le Database Webhook

Dans Supabase Dashboard :

- table : `public.notifications`
- événement : `INSERT`
- URL : URL de la fonction `send-push-notifications`
- en-tête : `x-webhook-secret: <même-secret>`

La fonction récupère les tokens du destinataire, appelle l’API Expo Push et supprime les tokens déclarés `DeviceNotRegistered`.

### 4. Configurer les identifiants natifs

Configurer les credentials FCM Android et APNs iOS via EAS avant les builds de production. Tester les notifications sur un appareil physique et, de préférence, avec un development build.

## Localisation et carte

- La carte utilise `@maplibre/maplibre-react-native` avec les tuiles OpenStreetMap (pas de clé Google Maps nécessaire).
- Le géocodage utilise Nominatim avec temporisation, cache, attribution et paramètres configurables.
- La dernière position connue du bénévole est enregistrée côté profil via une RPC sécurisée afin de cibler les signalements créés dans un rayon de 20 km.
- Les coordonnées privées ne sont pas lisibles par les autres utilisateurs via l’API publique.

Le service public Nominatim impose une utilisation modérée. Pour une montée en charge, placer le géocodage derrière un proxy contrôlé ou utiliser une instance/un fournisseur dédié, sans modifier directement les écrans grâce à `EXPO_PUBLIC_NOMINATIM_URL`.

## Builds

APK interne Android :

```bash
npm run build:android:preview
```

Build Android de production :

```bash
npm run build:android
```

Build iOS de production :

```bash
npm run build:ios
```

Le profil `preview` produit un APK. Les builds de production utilisent la gestion de version distante EAS.

## Sécurité appliquée

- données privées du profil non exposées par `SELECT *` ;
- édition du profil et administration via RPC dédiées ;
- accès aux chats de maraude limité aux participants, au créateur et aux administrateurs ;
- accès aux comptes suspendus bloqué ;
- mise à jour directe du statut/responsable d’un signalement interdite ;
- fonctions `SECURITY DEFINER` avec `search_path` vide et droits d’exécution explicites ;
- tokens push isolés dans une table dédiée et enregistrés par RPC ;
- clés et identifiants réels absents du dépôt.

## Contrôles de qualité

```bash
npm run lint
npx expo install --check
npx expo-doctor
npx expo export --platform web --output-dir dist-web
npx expo export --platform android --output-dir dist-android
npx expo export --platform ios --output-dir dist-ios
```

## Limites de validation

L’audit valide la cohérence statique du code, les imports, les dépendances, les bundles Expo et la syntaxe SQL. Il ne remplace pas :

- l’exécution des migrations sur votre projet Supabase réel ;
- des tests avec plusieurs comptes et rôles sur une base de recette ;
- un test de notification distante avec credentials FCM/APNs ;
- un build EAS signé ;
- une recette sur appareils Android et iOS réels.

## Références officielles

- Expo SDK 56 : https://expo.dev/changelog/sdk-56
- Expo Push Notifications : https://docs.expo.dev/push-notifications/sending-notifications/
- React Navigation 7 : https://reactnavigation.org/docs/upgrading-from-6.x/
- Supabase — sécurité des fonctions : https://supabase.com/docs/guides/database/functions#function-security
- Politique d’utilisation Nominatim : https://operations.osmfoundation.org/policies/nominatim/

## Important — fichiers d'environnement

Le dépôt contient `.env.example` et `.gitignore`. Le vrai fichier `.env` n'est pas inclus dans l'archive afin de ne pas redistribuer les clés locales. Créer le fichier local avec PowerShell :

```powershell
Copy-Item .env.example .env
```

Puis remplacer les valeurs `YOUR_*` dans `.env`. Le fichier `.env` est volontairement ignoré par Git.
