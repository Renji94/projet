# Audit technique — PourCeux

**Date : 10 juillet 2026**  
**Périmètre :** archive complète fournie, hors validation d’un projet Supabase distant et hors build EAS signé.


## Mise à jour de marque PourCeux

- nom Expo, slug, schéma de deep link, identifiants Android/iOS et textes visibles harmonisés ;
- logo, icône, adaptive icon, favicon, icône de notification et splash recréés à partir des visuels fournis ;
- palette principale alignée sur le bleu nuit et le vert menthe du logo ;
- identifiants réels retirés de `.env.example` et vrai `.env` exclu du livrable ;
- Edge Function convertie en JavaScript pur et `tsconfig.json` supprimé ;
- shim npm local ajouté pour la résolution statique des icônes de React Native Paper, sans faux Config Plugin Expo.

## Revalidation de la livraison PourCeux

La revalidation après changement de marque est détaillée dans `RAPPORT_LIVRAISON.md`. Elle confirme l’installation npm, le lint, la syntaxe JavaScript, les imports relatifs, la résolution de la configuration Expo et le démarrage de Metro. Deux contrôles distants d’`expo-doctor` n’ont pas pu contacter les services Expo, et l’export Web a dépassé la fenêtre d’exécution sans produire d’erreur de résolution avant expiration.

## 1. Conclusion

Le projet initial présentait une bonne couverture fonctionnelle apparente, mais n’était pas dans un état suffisamment fiable ni sécurisé pour être traité comme une application professionnelle. Les fichiers JavaScript étaient globalement structurés et les imports relatifs existaient, mais plusieurs problèmes critiques n’étaient visibles qu’en analysant les interactions entre le client, Expo et Supabase.

La version corrigée constitue désormais une base V0 cohérente et buildable. Les points bloquants de configuration, navigation, permissions, RLS, RPC, carte et notifications ont été corrigés. La mise en production nécessite encore les opérations externes listées en section 8.

## 2. Périmètre réellement contrôlé

- structure complète du dépôt et fichiers de configuration ;
- `package.json`, verrou npm et compatibilité Expo ;
- résolution de tous les imports relatifs et analyse syntaxique des sources ;
- navigation et routes imbriquées ;
- providers, authentification et cycle de session ;
- hooks et services Supabase ;
- maraudes, participations, signalements et profils ;
- chat Realtime et lecture des messages ;
- carte mobile, tuiles OSM, géocodage Nominatim et itinéraires ;
- notifications locales, Realtime et push distantes ;
- schéma SQL, triggers, RPC et politiques RLS ;
- configuration Android, iOS, Web et EAS ;
- exports JavaScript Expo et lint.

## 3. Anomalies critiques identifiées

### 3.1 Confidentialité des profils

La politique initiale autorisait tout utilisateur authentifié à exécuter un `SELECT` complet sur `profiles`. Cela exposait notamment téléphone, position GPS et token push. Le client utilisait également des mises à jour directes de profil trop difficiles à verrouiller proprement.

**Correction :** droits de colonnes limités, lecture complète du profil courant via `get_my_profile`, édition via `update_my_profile`, position via `update_my_position`, administration via RPC séparées.

### 3.2 Chats lisibles par tous les comptes

Les messages et les chats pouvaient être lus par n’importe quel utilisateur authentifié. Cette règle ne correspondait pas au fonctionnement annoncé des chats de maraude.

**Correction :** fonction `can_access_chat` et politiques RLS. Pour une maraude, seuls le créateur, les participants et les administrateurs accèdent au chat. Le chat d’un signalement reste ouvert aux bénévoles actifs afin de permettre la prise en charge rapide prévue par le produit.

### 3.3 Fonctions `SECURITY DEFINER` insuffisamment verrouillées

Plusieurs RPC exécutaient des requêtes avec des privilèges élevés, avec un `search_path` permissif et des droits d’exécution par défaut. Certaines fonctions permettaient aussi de consulter des informations pour un autre utilisateur.

**Correction :** `search_path = ''`, noms de schémas explicites, contrôles de l’appelant, révocation globale des droits d’exécution puis attribution fonction par fonction.

### 3.4 Notifications push non réellement implémentées

Le code initial écoutait Supabase Realtime puis déclenchait une notification locale. Ce mécanisme ne fonctionne pas lorsque l’application est fermée et ne constitue pas une notification push distante.

**Correction :** table multi-appareils `push_tokens`, RPC d’enregistrement, création de notifications serveur, Edge Function Supabase, appel de l’API Expo Push, nettoyage des tokens invalides et navigation au toucher de la notification.

### 3.5 Clôture non autorisée d’un signalement ouvert

La RPC initiale comparait `pris_en_charge_par <> auth.uid()`. Lorsque `pris_en_charge_par` était `NULL`, l’expression SQL devenait `NULL` et le bloc de refus n’était pas exécuté. Un utilisateur authentifié quelconque pouvait donc clôturer un signalement ouvert non attribué en appelant directement la RPC.

**Correction :** réécriture avec `IS DISTINCT FROM`, vérification du compte actif et contrôle explicite créateur/responsable/administrateur.

### 3.6 Position des bénévoles jamais enregistrée

Le trigger de proximité cherchait des bénévoles ayant une latitude/longitude dans `profiles`, mais le service prévu pour sauvegarder la position n’était appelé nulle part. Les alertes « proches » ne pouvaient donc pas fonctionner de manière fiable.

**Correction :** synchronisation de la dernière position connue en premier plan via une RPC privée. La carte recentre également l’utilisateur après acquisition GPS et affiche une erreur exploitable si la permission est refusée.

## 4. Anomalies majeures corrigées

| Domaine | État initial | Correction |
|---|---|---|
| Expo | SDK 51 ancien, configuration incomplète | Migration contrôlée vers Expo SDK 56 / RN 0.85 / React 19 |
| Dépendances | anciennes versions et historique de versions invalides | arbre npm régénéré et validé, modules Expo alignés |
| Assets | icône, splash et adaptive icon référencés mais absents | assets cohérents ajoutés |
| EAS | identifiants placeholders, aucun `eas.json` | configuration EAS et profils de build ajoutés |
| Environnement | exemple contenant des identifiants réels | `.env.example` neutralisé et compatibilité clé publishable ajoutée |
| Git | `gitignore.txt` non fonctionnel | vrai `.gitignore`, exclusions des secrets et artefacts |
| Navigation | route `MaraudeForm` absente depuis la pile Carte | route ajoutée dans toutes les piles concernées |
| Notifications | aucune gestion du toucher | navigation différée vers le détail maraude/signalement |
| Session | erreurs profil masquées, comptes suspendus mal traités | état d’erreur, écran de suspension et cycle auto-refresh nettoyé |
| Supabase client | listener `AppState` global non nettoyé | abonnement démarré/arrêté par le provider d’authentification |
| Carte | tuiles OSM sans attribution, recentrage incomplet | attribution, fallback Web, recentrage et message de permission |
| Nominatim | appels non temporisés, sans cache ni endpoint configurable | file d’attente ≥ 1,1 s, cache, URL et contact configurables |
| Signalement | coordonnées anciennes conservées lors du changement de mode | réinitialisation explicite des coordonnées/adresse |
| Realtime | abonnements dupliqués selon les écrans | synchronisation globale centralisée |
| Chat | fausse pagination via pull-to-refresh | historique V0 unique limité à 200 messages, sans pagination UI |
| Dates | simple expression régulière | existence de la date et interdiction d’une date passée |
| Admin | erreurs des requêtes de statistiques ignorées | propagation et affichage des erreurs |
| Avatars | migration active malgré l’exclusion de la V0 | script déplacé dans `supabase/optional` |


### 4.1 Correction de la migration des icônes

Une première version corrigée avait introduit à tort `@react-native-vector-icons/material-design-icons` comme Config Plugin Expo et comme alias Metro. Cette configuration bloquait immédiatement `eas build:configure`.

**Correction finale :**

- suppression du package dans `package.json` et `package-lock.json` ;
- suppression de toute entrée correspondante dans `app.json` ;
- restauration d’un `metro.config.js` Expo standard, sans alias ;
- remplacement de tous les imports par `@expo/vector-icons` ;
- validation par `expo config --type prebuild`, `expo prebuild`, les exports Android/iOS/Web et un lancement réel de `eas build:configure`.

La commande EAS ne peut pas être menée jusqu’à l’écriture distante sans authentification Expo. Dans l’environnement d’audit, elle atteint maintenant correctement la demande de connexion au compte, ce qui confirme la disparition de l’erreur de résolution du faux plugin.

## 5. Architecture de la version corrigée

- `src/contexts` : session et profil courant ;
- `src/providers` : React Query, Paper, Safe Area et Auth ;
- `src/hooks` : logique applicative, Realtime, notifications et localisation ;
- `src/services` : accès Supabase, géocodage et notifications ;
- `src/navigation` : routes par domaine et navigation depuis les notifications ;
- `src/screens/system` : configuration manquante et compte suspendu ;
- `supabase/migrations` : schéma V0 actif et durcissement ;
- `supabase/functions` : envoi serveur des notifications ;
- `supabase/optional` : fonctions explicitement hors V0.

## 6. Contrôles exécutés

- analyse syntaxique de **63 fichiers source** ;
- vérification de **232 imports relatifs** : aucun import introuvable ;
- `npm ls --depth=0` : arbre direct cohérent ;
- `npm audit --omit=dev --audit-level=high` : aucune vulnérabilité haute ou critique ; les alertes modérées restantes sont transitives et liées à l’outillage Expo ;
- `npx expo install --check` : dépendances alignées avec le SDK ;
- ESLint : aucune erreur ni aucun avertissement ;
- parse PostgreSQL des migrations actives et optionnelles : syntaxe valide ;
- export Web Expo réussi ;
- export Android Expo réussi ;
- export iOS Expo réussi ;
- `expo prebuild --platform all --no-install --clean` réussi dans une copie temporaire : génération des projets natifs Android et iOS et résolution complète des Config Plugins ;
- `eas build:configure --platform all` testé : la commande franchit désormais la résolution des plugins et s’arrête uniquement à la demande de connexion au compte Expo, indisponible dans l’environnement d’audit ;
- contrôle exhaustif de `app.json`, `metro.config.js`, `package.json`, `package-lock.json` et des sources : aucune référence à `@react-native-vector-icons/material-design-icons` ;
- 13 fichiers utilisent l’import Expo officiel `import { MaterialCommunityIcons } from '@expo/vector-icons';` ;
- `expo-doctor` : contrôles locaux validés ; deux contrôles distants peuvent dépendre de l’accès réseau aux services Expo/React Native Directory.

## 7. Décisions techniques

### Expo SDK 56 plutôt que SDK 57

Le projet a été placé sur SDK 56, version moderne et compatible avec React Native 0.85 / React 19.2, plutôt que de basculer immédiatement sur SDK 57 fraîchement publié. Cette décision réduit le risque de régression au moment de l’audit tout en évitant de conserver SDK 51.

### Web

`react-native-maps` reste une dépendance native. Le Web n’est pas présenté comme une plateforme fonctionnellement équivalente : l’application y compile, mais l’écran Carte affiche un fallback explicite. Android et iOS restent les cibles produit.

### Nominatim

L’endpoint public convient à une V0 à faible trafic seulement. Le code permet de changer d’endpoint sans réécrire les écrans. Une application diffusée à grande échelle doit utiliser un proxy avec cache, une instance dédiée ou un fournisseur respectant la politique OSM.

## 8. Opérations encore obligatoires hors dépôt

1. Sauvegarder la base Supabase existante.
2. Exécuter `005_security_hardening.sql`, puis `006_push_notifications.sql`.
3. Vérifier le rôle du premier administrateur dans `profiles`.
4. Renseigner le vrai `.env` sans le commiter, notamment une adresse de contact réelle pour Nominatim public.
5. Exécuter `npx eas-cli@20.5.1 init` et reporter le `projectId`.
6. Déployer l’Edge Function et créer le Database Webhook sécurisé.
7. Configurer FCM Android et APNs iOS dans EAS.
8. Tester au minimum deux utilisateurs, un administrateur et un compte suspendu sur une base de recette.
9. Tester les notifications avec l’application en premier plan, en arrière-plan et fermée.
10. Produire un APK de prévisualisation puis les builds signés de production.

## 9. Limites et risques résiduels

- Aucun accès au projet Supabase distant n’a été fourni : les migrations n’ont pas été exécutées sur la base réelle.
- Aucun credential EAS/FCM/APNs n’a été fourni : aucune notification distante réelle ni build signé n’a pu être vérifié.
- Il n’existe pas encore de suite de tests unitaires ou end-to-end ; le lint, les exports et l’analyse statique ne remplacent pas une recette métier.
- La position utilisée pour la proximité est la dernière position enregistrée en premier plan, pas un suivi de localisation en arrière-plan.
- L’historique du chat est volontairement plafonné aux 200 messages récents dans cette V0 sans pagination.
- L’endpoint public OSM/Nominatim n’est pas dimensionné pour une forte charge commerciale.

## 10. Verdict

**Avant correction :** prototype généré, non validé, comportant des failles de confidentialité et des fonctionnalités annoncées mais incomplètes.  
**Après correction :** base V0 cohérente, sécurisée au niveau applicatif et SQL, exportable sur les trois plateformes, prête pour l’intégration à la base Supabase réelle et la recette sur appareils.
