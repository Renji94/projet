module.exports = ({ config }) => {
  const projectId = (process.env.EXPO_PUBLIC_EAS_PROJECT_ID || '').trim();
  const existingExtra = config.extra || {};
  const existingEas = existingExtra.eas || {};

  return {
    ...config,
    extra: {
      ...existingExtra,
      ...(projectId
        ? {
            eas: {
              ...existingEas,
              projectId,
            },
          }
        : {}),
    },
  };
};
