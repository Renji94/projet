import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';


Deno.serve(async (request) => {
  if (request.method !== 'POST') return new Response('Method not allowed', { status: 405 });

  const expectedSecret = Deno.env.get('PUSH_WEBHOOK_SECRET');
  if (!expectedSecret || request.headers.get('x-webhook-secret') !== expectedSecret) {
    return new Response('Unauthorized', { status: 401 });
  }

  const payload = await request.json();
  if (payload.type !== 'INSERT' || payload.table !== 'notifications' || !payload.record?.user_id) {
    return Response.json({ skipped: true });
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL'),
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'),
    { auth: { persistSession: false } }
  );

  const { data: tokens, error } = await supabase
    .from('push_tokens')
    .select('expo_push_token')
    .eq('user_id', payload.record.user_id);

  if (error) return Response.json({ error: error.message }, { status: 500 });
  if (!tokens?.length) return Response.json({ delivered: 0 });

  const messages = tokens.map(({ expo_push_token }) => ({
    to: expo_push_token,
    sound: 'default',
    title: payload.record.titre,
    body: payload.record.corps,
    data: payload.record.data || {},
    channelId: 'default',
  }));

  const response = await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Accept-Encoding': 'gzip, deflate',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(messages),
  });

  const result = await response.json();
  if (!response.ok) return Response.json(result, { status: response.status });

  const tickets = Array.isArray(result?.data) ? result.data : [result?.data];
  const invalidTokens = tickets
    .map((ticket, index) =>
      ticket?.status === 'error' && ticket?.details?.error === 'DeviceNotRegistered'
        ? tokens[index]?.expo_push_token
        : null
    )
    .filter(Boolean);

  if (invalidTokens.length) {
    await supabase.from('push_tokens').delete().in('expo_push_token', invalidTokens);
  }

  return Response.json({ delivered: messages.length, invalidated: invalidTokens.length });
});
