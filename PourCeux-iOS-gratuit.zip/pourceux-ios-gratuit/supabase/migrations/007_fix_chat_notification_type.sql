-- ============================================================
-- POURCEUX - CORRECTIF NOTIFICATIONS DE CHAT
-- Migration 007
-- Bug corrigé : "column "type" is of type public.notification_type
-- but expression is of type text" à l'envoi d'un message de chat.
-- Cause : SELECT DISTINCT force la résolution du littéral
-- 'nouveau_message' en text avant la coercion vers la colonne
-- enum notifications.type (VALUES/SELECT simples ne font pas ça).
-- Fix : cast explicite + DISTINCT retiré (redondant : recipient_id
-- est déjà unique grâce aux UNION de la sous-requête recipients).
-- ============================================================

CREATE OR REPLACE FUNCTION public.notify_chat_message()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_chat public.chats;
  v_title text;
BEGIN
  SELECT * INTO v_chat FROM public.chats WHERE id = NEW.chat_id;

  IF v_chat.type = 'maraude' THEN
    SELECT titre INTO v_title FROM public.maraudes WHERE id = v_chat.maraude_id;
    INSERT INTO public.notifications (user_id, type, titre, corps, data)
    SELECT recipient_id, 'nouveau_message'::public.notification_type, 'Nouveau message',
           'Un nouveau message a été envoyé dans « ' || coalesce(v_title, 'Maraude') || ' »',
           jsonb_build_object('maraude_id', v_chat.maraude_id, 'chat_id', NEW.chat_id)
    FROM (
      SELECT createur_id AS recipient_id FROM public.maraudes WHERE id = v_chat.maraude_id
      UNION
      SELECT user_id FROM public.maraude_participants WHERE maraude_id = v_chat.maraude_id
    ) recipients
    WHERE recipient_id <> NEW.user_id;
  ELSE
    SELECT titre INTO v_title FROM public.signalements WHERE id = v_chat.signalement_id;
    INSERT INTO public.notifications (user_id, type, titre, corps, data)
    SELECT recipient_id, 'nouveau_message'::public.notification_type, 'Nouveau message',
           'Un nouveau message a été envoyé dans « ' || coalesce(v_title, 'Signalement') || ' »',
           jsonb_build_object('signalement_id', v_chat.signalement_id, 'chat_id', NEW.chat_id)
    FROM (
      SELECT createur_id AS recipient_id FROM public.signalements WHERE id = v_chat.signalement_id
      UNION
      SELECT pris_en_charge_par FROM public.signalements
      WHERE id = v_chat.signalement_id AND pris_en_charge_par IS NOT NULL
    ) recipients
    WHERE recipient_id <> NEW.user_id;
  END IF;

  RETURN NEW;
END;
$$;
