-- ============================================================
-- POURCEUX - SCHEMA PRINCIPAL
-- Migration 001 : Tables, types, index, clés étrangères
-- ============================================================

-- Extension pour UUID
-- ============================================================
-- TYPES ENUM
-- ============================================================

CREATE TYPE user_role AS ENUM ('user', 'admin');

CREATE TYPE maraude_statut AS ENUM ('programmee', 'en_cours', 'terminee', 'annulee');

CREATE TYPE niveau_difficulte AS ENUM ('facile', 'moyen', 'difficile');

CREATE TYPE signalement_urgence AS ENUM ('faible', 'moyenne', 'haute', 'critique');

CREATE TYPE signalement_statut AS ENUM (
  'ouvert',
  'pris_en_charge',
  'resolu',
  'toujours_present',
  'introuvable',
  'fausse_alerte'
);

CREATE TYPE chat_type AS ENUM ('maraude', 'signalement');

CREATE TYPE message_type AS ENUM ('texte', 'localisation');

CREATE TYPE notification_type AS ENUM (
  'nouvelle_maraude',
  'maraude_modifiee',
  'maraude_annulee',
  'nouveau_signalement',
  'signalement_pris_en_charge',
  'signalement_statut',
  'nouveau_message',
  'participant_rejoint'
);

-- ============================================================
-- TABLE : profiles
-- ============================================================

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  pseudo TEXT NOT NULL UNIQUE CHECK (char_length(pseudo) BETWEEN 3 AND 30),
  prenom TEXT NOT NULL CHECK (char_length(prenom) BETWEEN 1 AND 50),
  nom TEXT NOT NULL CHECK (char_length(nom) BETWEEN 1 AND 50),
  telephone TEXT CHECK (telephone IS NULL OR telephone ~ '^\+?[0-9 ]{6,20}$'),
  ville TEXT NOT NULL CHECK (char_length(ville) BETWEEN 1 AND 100),
  role user_role NOT NULL DEFAULT 'user',
  is_suspended BOOLEAN NOT NULL DEFAULT FALSE,
  expo_push_token TEXT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_profiles_pseudo ON public.profiles (pseudo);
CREATE INDEX idx_profiles_role ON public.profiles (role);
CREATE INDEX idx_profiles_position ON public.profiles (latitude, longitude);

-- ============================================================
-- TABLE : maraudes
-- ============================================================

CREATE TABLE public.maraudes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  titre TEXT NOT NULL CHECK (char_length(titre) BETWEEN 3 AND 150),
  description TEXT NOT NULL CHECK (char_length(description) BETWEEN 10 AND 5000),
  date_maraude DATE NOT NULL,
  heure_debut TIME NOT NULL,
  heure_fin TIME NOT NULL,
  ville TEXT NOT NULL,
  adresse TEXT NOT NULL,
  latitude DOUBLE PRECISION NOT NULL CHECK (latitude BETWEEN -90 AND 90),
  longitude DOUBLE PRECISION NOT NULL CHECK (longitude BETWEEN -180 AND 180),
  max_participants INTEGER NOT NULL CHECK (max_participants BETWEEN 1 AND 500),
  current_participants INTEGER NOT NULL DEFAULT 0 CHECK (current_participants >= 0),
  materiel_recommande TEXT[] NOT NULL DEFAULT '{}',
  difficulte niveau_difficulte NOT NULL DEFAULT 'facile',
  statut maraude_statut NOT NULL DEFAULT 'programmee',
  createur_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT heure_fin_apres_debut CHECK (heure_fin > heure_debut)
);

CREATE INDEX idx_maraudes_statut ON public.maraudes (statut);
CREATE INDEX idx_maraudes_date ON public.maraudes (date_maraude);
CREATE INDEX idx_maraudes_ville ON public.maraudes (ville);
CREATE INDEX idx_maraudes_createur ON public.maraudes (createur_id);
CREATE INDEX idx_maraudes_position ON public.maraudes (latitude, longitude);

-- ============================================================
-- TABLE : maraude_participants
-- ============================================================

CREATE TABLE public.maraude_participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  maraude_id UUID NOT NULL REFERENCES public.maraudes(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT unique_participation UNIQUE (maraude_id, user_id)
);

CREATE INDEX idx_participants_maraude ON public.maraude_participants (maraude_id);
CREATE INDEX idx_participants_user ON public.maraude_participants (user_id);

-- ============================================================
-- TABLE : signalements
-- ============================================================

CREATE TABLE public.signalements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  titre TEXT NOT NULL CHECK (char_length(titre) BETWEEN 3 AND 150),
  description TEXT NOT NULL CHECK (char_length(description) BETWEEN 5 AND 5000),
  urgence signalement_urgence NOT NULL DEFAULT 'moyenne',
  latitude DOUBLE PRECISION NOT NULL CHECK (latitude BETWEEN -90 AND 90),
  longitude DOUBLE PRECISION NOT NULL CHECK (longitude BETWEEN -180 AND 180),
  adresse TEXT,
  nb_personnes INTEGER NOT NULL DEFAULT 1 CHECK (nb_personnes BETWEEN 1 AND 100),
  age_approximatif TEXT,
  animaux BOOLEAN NOT NULL DEFAULT FALSE,
  besoins TEXT[] NOT NULL DEFAULT '{}',
  commentaires TEXT,
  statut signalement_statut NOT NULL DEFAULT 'ouvert',
  createur_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  pris_en_charge_par UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  pris_en_charge_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_signalements_statut ON public.signalements (statut);
CREATE INDEX idx_signalements_urgence ON public.signalements (urgence);
CREATE INDEX idx_signalements_createur ON public.signalements (createur_id);
CREATE INDEX idx_signalements_position ON public.signalements (latitude, longitude);
CREATE INDEX idx_signalements_created ON public.signalements (created_at DESC);

-- ============================================================
-- TABLE : chats
-- ============================================================

CREATE TABLE public.chats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type chat_type NOT NULL,
  maraude_id UUID UNIQUE REFERENCES public.maraudes(id) ON DELETE CASCADE,
  signalement_id UUID UNIQUE REFERENCES public.signalements(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chat_source_valide CHECK (
    (type = 'maraude' AND maraude_id IS NOT NULL AND signalement_id IS NULL) OR
    (type = 'signalement' AND signalement_id IS NOT NULL AND maraude_id IS NULL)
  )
);

CREATE INDEX idx_chats_maraude ON public.chats (maraude_id);
CREATE INDEX idx_chats_signalement ON public.chats (signalement_id);

-- ============================================================
-- TABLE : messages
-- ============================================================

CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id UUID NOT NULL REFERENCES public.chats(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type message_type NOT NULL DEFAULT 'texte',
  contenu TEXT CHECK (contenu IS NULL OR char_length(contenu) <= 2000),
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT message_valide CHECK (
    (type = 'texte' AND contenu IS NOT NULL AND char_length(contenu) > 0) OR
    (type = 'localisation' AND latitude IS NOT NULL AND longitude IS NOT NULL)
  )
);

CREATE INDEX idx_messages_chat ON public.messages (chat_id, created_at DESC);
CREATE INDEX idx_messages_user ON public.messages (user_id);

-- ============================================================
-- TABLE : message_reads (lecture des messages)
-- ============================================================

CREATE TABLE public.message_reads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id UUID NOT NULL REFERENCES public.chats(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  last_read_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT unique_read UNIQUE (chat_id, user_id)
);

CREATE INDEX idx_message_reads_chat ON public.message_reads (chat_id);
CREATE INDEX idx_message_reads_user ON public.message_reads (user_id);

-- ============================================================
-- TABLE : notifications
-- ============================================================

CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type notification_type NOT NULL,
  titre TEXT NOT NULL,
  corps TEXT NOT NULL,
  data JSONB NOT NULL DEFAULT '{}',
  lu BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_user ON public.notifications (user_id, created_at DESC);
CREATE INDEX idx_notifications_lu ON public.notifications (user_id, lu);