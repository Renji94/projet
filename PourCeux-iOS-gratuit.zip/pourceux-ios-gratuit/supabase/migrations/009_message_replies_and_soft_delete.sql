-- ============================================================
-- POURCEUX - RÉPONSE À UN MESSAGE + SUPPRESSION LOGIQUE
-- Migration 009
-- Ajoute la possibilité de répondre à un message précis (reply_to)
-- et de le supprimer logiquement (is_deleted) sans jamais casser les
-- réponses déjà liées à ce message. Aucune suppression physique de
-- message ne reste possible depuis l'application après cette migration.
-- ============================================================

-- La réponse ne peut cibler qu'un message du même chat que le nouveau message.
-- reply_to est en RESTRICT : aucune suppression physique n'étant plus permise
-- depuis l'app (voir plus bas), cette contrainte ne devrait jamais se déclencher
-- en usage normal — elle protège contre toute suppression physique faite hors
-- de l'app (accès direct à la base, outil d'administration, etc.).
ALTER TABLE public.messages
  ADD COLUMN reply_to UUID REFERENCES public.messages(id) ON DELETE RESTRICT;

ALTER TABLE public.messages
  ADD COLUMN is_deleted BOOLEAN NOT NULL DEFAULT false;

CREATE INDEX idx_messages_reply_to ON public.messages (reply_to) WHERE reply_to IS NOT NULL;

-- Une réponse doit obligatoirement cibler un message du même chat.
CREATE OR REPLACE FUNCTION public.enforce_reply_same_chat()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF NEW.reply_to IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.messages m
      WHERE m.id = NEW.reply_to AND m.chat_id = NEW.chat_id
    ) THEN
      RAISE EXCEPTION 'Le message cité doit appartenir au même chat.';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_reply_same_chat ON public.messages;
CREATE TRIGGER trg_enforce_reply_same_chat
  BEFORE INSERT ON public.messages
  FOR EACH ROW EXECUTE FUNCTION public.enforce_reply_same_chat();

-- Seule la transition is_deleted false -> true est autorisée (pas de
-- "dé-suppression", pas de suppression d'un message déjà supprimé).
CREATE OR REPLACE FUNCTION public.enforce_message_soft_delete_only()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF OLD.is_deleted = true THEN
    RAISE EXCEPTION 'Ce message est déjà supprimé.';
  END IF;
  IF NEW.is_deleted IS DISTINCT FROM true THEN
    RAISE EXCEPTION 'Seule la suppression du message est autorisée.';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_message_soft_delete ON public.messages;
CREATE TRIGGER trg_enforce_message_soft_delete
  BEFORE UPDATE ON public.messages
  FOR EACH ROW EXECUTE FUNCTION public.enforce_message_soft_delete_only();

-- Verrou par privilège de colonne (même schéma déjà utilisé pour profiles,
-- 005_security_hardening.sql:40-43) : un utilisateur authentifié ne peut
-- physiquement modifier que la colonne is_deleted, jamais contenu/reply_to/
-- chat_id/etc., quelle que soit la requête envoyée.
REVOKE UPDATE ON public.messages FROM authenticated;
GRANT UPDATE (is_deleted) ON public.messages TO authenticated;

CREATE POLICY "messages_update_soft_delete"
  ON public.messages FOR UPDATE
  TO authenticated
  USING (public.can_access_chat(chat_id) AND (user_id = auth.uid() OR public.is_admin()))
  WITH CHECK (public.can_access_chat(chat_id) AND (user_id = auth.uid() OR public.is_admin()));

-- Suppression physique : plus aucun chemin possible depuis l'app, y compris
-- pour un admin. Toute suppression passe désormais par is_deleted = true.
DROP POLICY IF EXISTS "messages_delete_admin" ON public.messages;
