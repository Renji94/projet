-- ============================================================
-- POURCEUX - TOKENS ET EVENEMENTS PUSH
-- Migration 006
-- ============================================================

CREATE TABLE IF NOT EXISTS public.push_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  expo_push_token text NOT NULL UNIQUE
    CHECK (expo_push_token ~ '^(ExponentPushToken|ExpoPushToken)'),
  platform text NOT NULL CHECK (platform IN ('android', 'ios', 'unknown')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_push_tokens_user ON public.push_tokens(user_id);
ALTER TABLE public.push_tokens ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.push_tokens TO authenticated;

DROP POLICY IF EXISTS "push_tokens_select_own" ON public.push_tokens;
DROP POLICY IF EXISTS "push_tokens_insert_own" ON public.push_tokens;
DROP POLICY IF EXISTS "push_tokens_update_own" ON public.push_tokens;
DROP POLICY IF EXISTS "push_tokens_delete_own" ON public.push_tokens;
CREATE POLICY "push_tokens_select_own" ON public.push_tokens FOR SELECT TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "push_tokens_insert_own" ON public.push_tokens FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND public.is_not_suspended());
CREATE POLICY "push_tokens_update_own" ON public.push_tokens FOR UPDATE TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid() AND public.is_not_suspended());
CREATE POLICY "push_tokens_delete_own" ON public.push_tokens FOR DELETE TO authenticated
  USING (user_id = auth.uid());

-- Migration douce depuis l'ancien champ unique par profil.
INSERT INTO public.push_tokens (user_id, expo_push_token, platform)
SELECT id, expo_push_token, 'unknown'
FROM public.profiles
WHERE expo_push_token IS NOT NULL
ON CONFLICT (expo_push_token) DO UPDATE
SET user_id = EXCLUDED.user_id, updated_at = now();

-- Un token Expo peut être réattribué au même appareil après changement de compte.
-- Le client ne manipule donc pas directement user_id lors de l'enregistrement.
CREATE OR REPLACE FUNCTION public.register_push_token(
  p_token text,
  p_platform text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_not_suspended() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Non autorisé.');
  END IF;
  IF p_token IS NULL OR p_token !~ '^(ExponentPushToken|ExpoPushToken)' THEN
    RETURN jsonb_build_object('success', false, 'error', 'Token Expo invalide.');
  END IF;
  IF p_platform NOT IN ('android', 'ios') THEN
    RETURN jsonb_build_object('success', false, 'error', 'Plateforme invalide.');
  END IF;

  INSERT INTO public.push_tokens (user_id, expo_push_token, platform)
  VALUES (auth.uid(), p_token, p_platform)
  ON CONFLICT (expo_push_token) DO UPDATE
  SET user_id = auth.uid(),
      platform = EXCLUDED.platform,
      updated_at = now();

  RETURN jsonb_build_object('success', true);
END;
$$;

CREATE OR REPLACE FUNCTION public.notify_chat_message()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_chat public.chats;
  v_title text;
BEGIN
  SELECT * INTO v_chat FROM public.chats WHERE id = NEW.chat_id;

  IF v_chat.type = 'maraude' THEN
    SELECT titre INTO v_title FROM public.maraudes WHERE id = v_chat.maraude_id;
    INSERT INTO public.notifications (user_id, type, titre, corps, data)
    SELECT DISTINCT recipient_id, 'nouveau_message', 'Nouveau message',
           'Un nouveau message a été envoyé dans « ' || coalesce(v_title, 'Maraude') || ' »',
           jsonb_build_object('maraude_id', v_chat.maraude_id, 'chat_id', NEW.chat_id)
    FROM (
      SELECT createur_id AS recipient_id FROM public.maraudes WHERE id = v_chat.maraude_id
      UNION
      SELECT user_id FROM public.maraude_participants WHERE maraude_id = v_chat.maraude_id
    ) recipients
    WHERE recipient_id <> NEW.user_id;
  ELSE
    SELECT titre INTO v_title FROM public.signalements WHERE id = v_chat.signalement_id;
    INSERT INTO public.notifications (user_id, type, titre, corps, data)
    SELECT DISTINCT recipient_id, 'nouveau_message', 'Nouveau message',
           'Un nouveau message a été envoyé dans « ' || coalesce(v_title, 'Signalement') || ' »',
           jsonb_build_object('signalement_id', v_chat.signalement_id, 'chat_id', NEW.chat_id)
    FROM (
      SELECT createur_id AS recipient_id FROM public.signalements WHERE id = v_chat.signalement_id
      UNION
      SELECT pris_en_charge_par FROM public.signalements
      WHERE id = v_chat.signalement_id AND pris_en_charge_par IS NOT NULL
    ) recipients
    WHERE recipient_id <> NEW.user_id;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_chat_message ON public.messages;
CREATE TRIGGER trg_notify_chat_message
  AFTER INSERT ON public.messages
  FOR EACH ROW EXECUTE FUNCTION public.notify_chat_message();

REVOKE EXECUTE ON FUNCTION public.register_push_token(text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.register_push_token(text, text) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.notify_chat_message() FROM PUBLIC, anon, authenticated;

-- Les notifications doivent être diffusées au client en temps réel.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'notifications'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
  END IF;
END $$;
