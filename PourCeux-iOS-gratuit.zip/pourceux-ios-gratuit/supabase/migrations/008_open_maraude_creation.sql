-- ============================================================
-- POURCEUX - OUVERTURE DE LA CRÉATION DE MARAUDE À TOUS LES UTILISATEURS
-- Migration 008
-- La création de maraude était réservée aux admins. Décision produit :
-- tout utilisateur authentifié non suspendu peut désormais créer une
-- maraude, comme c'est déjà le cas pour les signalements
-- (signalements_insert_user, 003_rls_policies.sql:85-88).
-- Les policies UPDATE/DELETE restent admin-only (maraudes_update_admin,
-- maraudes_delete_admin, inchangées) : volontairement hors périmètre —
-- un utilisateur peut créer une maraude mais ne peut pas la modifier/
-- annuler lui-même ensuite, seul un admin le peut.
-- ============================================================

DROP POLICY IF EXISTS "maraudes_insert_admin" ON public.maraudes;
CREATE POLICY "maraudes_insert_user"
  ON public.maraudes FOR INSERT
  TO authenticated
  WITH CHECK (createur_id = auth.uid() AND public.is_not_suspended());
