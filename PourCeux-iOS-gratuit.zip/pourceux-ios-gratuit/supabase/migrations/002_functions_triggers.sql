-- ============================================================
-- POURCEUX - FONCTIONS ET TRIGGERS
-- Migration 002
-- ============================================================

-- ============================================================
-- FONCTION : mise à jour automatique de updated_at
-- ============================================================

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER trg_maraudes_updated_at
  BEFORE UPDATE ON public.maraudes
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER trg_signalements_updated_at
  BEFORE UPDATE ON public.signalements
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============================================================
-- FONCTION : création automatique du profil à l'inscription
-- Les métadonnées (pseudo, prenom, nom, ville) sont passées
-- via options.data lors du signUp côté client.
-- ============================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, pseudo, prenom, nom, telephone, ville)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'pseudo', 'user_' || substr(NEW.id::text, 1, 8)),
    COALESCE(NEW.raw_user_meta_data->>'prenom', 'Prénom'),
    COALESCE(NEW.raw_user_meta_data->>'nom', 'Nom'),
    NULLIF(NEW.raw_user_meta_data->>'telephone', ''),
    COALESCE(NEW.raw_user_meta_data->>'ville', 'Non renseignée')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- FONCTION : vérifier si l'utilisateur courant est admin
-- ============================================================

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin' AND is_suspended = FALSE
  );
END;
$$ LANGUAGE plpgsql STABLE;

-- ============================================================
-- FONCTION : vérifier si l'utilisateur courant est suspendu
-- ============================================================

CREATE OR REPLACE FUNCTION public.is_not_suspended()
RETURNS BOOLEAN
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND is_suspended = FALSE
  );
END;
$$ LANGUAGE plpgsql STABLE;

-- ============================================================
-- FONCTION : distance haversine en kilomètres
-- ============================================================

CREATE OR REPLACE FUNCTION public.haversine_km(
  lat1 DOUBLE PRECISION, lon1 DOUBLE PRECISION,
  lat2 DOUBLE PRECISION, lon2 DOUBLE PRECISION
)
RETURNS DOUBLE PRECISION AS $$
DECLARE
  r DOUBLE PRECISION := 6371;
  dlat DOUBLE PRECISION;
  dlon DOUBLE PRECISION;
  a DOUBLE PRECISION;
BEGIN
  dlat := radians(lat2 - lat1);
  dlon := radians(lon2 - lon1);
  a := sin(dlat / 2) ^ 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2) ^ 2;
  RETURN r * 2 * atan2(sqrt(a), sqrt(1 - a));
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- ============================================================
-- TRIGGER : création automatique du chat pour une maraude
-- ============================================================

CREATE OR REPLACE FUNCTION public.create_maraude_chat()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.chats (type, maraude_id) VALUES ('maraude', NEW.id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_maraude_chat
  AFTER INSERT ON public.maraudes
  FOR EACH ROW EXECUTE FUNCTION public.create_maraude_chat();

-- ============================================================
-- TRIGGER : création automatique du chat pour un signalement
-- + notification des bénévoles proches (rayon 20 km)
-- ============================================================

CREATE OR REPLACE FUNCTION public.handle_new_signalement()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Création du chat
  INSERT INTO public.chats (type, signalement_id) VALUES ('signalement', NEW.id);

  -- Notification des bénévoles dans un rayon de 20 km
  INSERT INTO public.notifications (user_id, type, titre, corps, data)
  SELECT
    p.id,
    'nouveau_signalement',
    'Signalement à proximité (' || NEW.urgence || ')',
    NEW.titre || ' — ' || COALESCE(NEW.adresse, 'adresse inconnue'),
    jsonb_build_object('signalement_id', NEW.id, 'urgence', NEW.urgence)
  FROM public.profiles p
  WHERE p.id <> NEW.createur_id
    AND p.is_suspended = FALSE
    AND p.latitude IS NOT NULL
    AND p.longitude IS NOT NULL
    AND public.haversine_km(p.latitude, p.longitude, NEW.latitude, NEW.longitude) <= 20;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_signalement_created
  AFTER INSERT ON public.signalements
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_signalement();

-- ============================================================
-- TRIGGER : compteur de participants d'une maraude
-- ============================================================

CREATE OR REPLACE FUNCTION public.update_participants_count()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.maraudes
    SET current_participants = current_participants + 1
    WHERE id = NEW.maraude_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.maraudes
    SET current_participants = GREATEST(current_participants - 1, 0)
    WHERE id = OLD.maraude_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_participants_count
  AFTER INSERT OR DELETE ON public.maraude_participants
  FOR EACH ROW EXECUTE FUNCTION public.update_participants_count();

-- ============================================================
-- RPC : rejoindre une maraude (validation côté serveur)
-- ============================================================

CREATE OR REPLACE FUNCTION public.rejoindre_maraude(p_maraude_id UUID)
RETURNS JSONB
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_maraude RECORD;
  v_pseudo TEXT;
BEGIN
  IF NOT public.is_not_suspended() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Compte suspendu.');
  END IF;

  SELECT * INTO v_maraude FROM public.maraudes WHERE id = p_maraude_id FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Maraude introuvable.');
  END IF;

  IF v_maraude.statut NOT IN ('programmee', 'en_cours') THEN
    RETURN jsonb_build_object('success', false, 'error', 'Cette maraude n''est plus ouverte aux inscriptions.');
  END IF;

  IF v_maraude.current_participants >= v_maraude.max_participants THEN
    RETURN jsonb_build_object('success', false, 'error', 'La maraude est complète.');
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.maraude_participants
    WHERE maraude_id = p_maraude_id AND user_id = auth.uid()
  ) THEN
    RETURN jsonb_build_object('success', false, 'error', 'Vous participez déjà à cette maraude.');
  END IF;

  INSERT INTO public.maraude_participants (maraude_id, user_id)
  VALUES (p_maraude_id, auth.uid());

  SELECT pseudo INTO v_pseudo FROM public.profiles WHERE id = auth.uid();

  -- Notifier le créateur
  INSERT INTO public.notifications (user_id, type, titre, corps, data)
  VALUES (
    v_maraude.createur_id,
    'participant_rejoint',
    'Nouveau participant',
    v_pseudo || ' a rejoint la maraude « ' || v_maraude.titre || ' »',
    jsonb_build_object('maraude_id', p_maraude_id)
  );

  RETURN jsonb_build_object('success', true);
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- RPC : quitter une maraude
-- ============================================================

CREATE OR REPLACE FUNCTION public.quitter_maraude(p_maraude_id UUID)
RETURNS JSONB
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.maraude_participants
  WHERE maraude_id = p_maraude_id AND user_id = auth.uid();

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Vous ne participez pas à cette maraude.');
  END IF;

  RETURN jsonb_build_object('success', true);
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- RPC : prendre en charge un signalement
-- ============================================================

CREATE OR REPLACE FUNCTION public.prendre_en_charge_signalement(p_signalement_id UUID)
RETURNS JSONB
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_sig RECORD;
  v_pseudo TEXT;
BEGIN
  IF NOT public.is_not_suspended() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Compte suspendu.');
  END IF;

  SELECT * INTO v_sig FROM public.signalements WHERE id = p_signalement_id FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Signalement introuvable.');
  END IF;

  IF v_sig.statut <> 'ouvert' THEN
    RETURN jsonb_build_object('success', false, 'error', 'Ce signalement est déjà pris en charge ou clôturé.');
  END IF;

  UPDATE public.signalements
  SET statut = 'pris_en_charge',
      pris_en_charge_par = auth.uid(),
      pris_en_charge_at = NOW()
  WHERE id = p_signalement_id;

  SELECT pseudo INTO v_pseudo FROM public.profiles WHERE id = auth.uid();

  INSERT INTO public.notifications (user_id, type, titre, corps, data)
  VALUES (
    v_sig.createur_id,
    'signalement_pris_en_charge',
    'Signalement pris en charge',
    v_pseudo || ' prend en charge « ' || v_sig.titre || ' »',
    jsonb_build_object('signalement_id', p_signalement_id)
  );

  RETURN jsonb_build_object('success', true);
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- RPC : clôturer un signalement (résolu / toujours présent /
--       introuvable / fausse alerte)
-- ============================================================

CREATE OR REPLACE FUNCTION public.cloturer_signalement(
  p_signalement_id UUID,
  p_statut signalement_statut
)
RETURNS JSONB
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_sig RECORD;
BEGIN
  IF p_statut NOT IN ('resolu', 'toujours_present', 'introuvable', 'fausse_alerte') THEN
    RETURN jsonb_build_object('success', false, 'error', 'Statut invalide.');
  END IF;

  SELECT * INTO v_sig FROM public.signalements WHERE id = p_signalement_id FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Signalement introuvable.');
  END IF;

  IF v_sig.pris_en_charge_par <> auth.uid()
     AND v_sig.createur_id <> auth.uid()
     AND NOT public.is_admin() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Non autorisé.');
  END IF;

  -- "toujours_present" ré-ouvre le signalement
  IF p_statut = 'toujours_present' THEN
    UPDATE public.signalements
    SET statut = 'ouvert', pris_en_charge_par = NULL, pris_en_charge_at = NULL
    WHERE id = p_signalement_id;
  ELSE
    UPDATE public.signalements SET statut = p_statut WHERE id = p_signalement_id;
  END IF;

  INSERT INTO public.notifications (user_id, type, titre, corps, data)
  VALUES (
    v_sig.createur_id,
    'signalement_statut',
    'Mise à jour du signalement',
    'Le signalement « ' || v_sig.titre || ' » est maintenant : ' || p_statut,
    jsonb_build_object('signalement_id', p_signalement_id, 'statut', p_statut)
  );

  RETURN jsonb_build_object('success', true);
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- RPC : événements proches (carte avec filtre distance)
-- ============================================================

CREATE OR REPLACE FUNCTION public.get_evenements_proches(
  p_lat DOUBLE PRECISION,
  p_lon DOUBLE PRECISION,
  p_rayon_km DOUBLE PRECISION DEFAULT 50
)
RETURNS JSONB
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_maraudes JSONB;
  v_signalements JSONB;
BEGIN
  SELECT COALESCE(jsonb_agg(row_to_json(m)), '[]'::jsonb) INTO v_maraudes
  FROM (
    SELECT ma.*, public.haversine_km(p_lat, p_lon, ma.latitude, ma.longitude) AS distance_km
    FROM public.maraudes ma
    WHERE ma.statut IN ('programmee', 'en_cours')
      AND public.haversine_km(p_lat, p_lon, ma.latitude, ma.longitude) <= p_rayon_km
    ORDER BY distance_km
  ) m;

  SELECT COALESCE(jsonb_agg(row_to_json(s)), '[]'::jsonb) INTO v_signalements
  FROM (
    SELECT si.*, public.haversine_km(p_lat, p_lon, si.latitude, si.longitude) AS distance_km
    FROM public.signalements si
    WHERE si.statut IN ('ouvert', 'pris_en_charge')
      AND public.haversine_km(p_lat, p_lon, si.latitude, si.longitude) <= p_rayon_km
    ORDER BY distance_km
  ) s;

  RETURN jsonb_build_object('maraudes', v_maraudes, 'signalements', v_signalements);
END;
$$ LANGUAGE plpgsql STABLE;

-- ============================================================
-- RPC : statistiques du profil
-- ============================================================

CREATE OR REPLACE FUNCTION public.get_profile_stats(p_user_id UUID)
RETURNS JSONB
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN jsonb_build_object(
    'nb_maraudes', (SELECT COUNT(*) FROM public.maraude_participants WHERE user_id = p_user_id),
    'nb_signalements', (SELECT COUNT(*) FROM public.signalements WHERE createur_id = p_user_id),
    'nb_prises_en_charge', (SELECT COUNT(*) FROM public.signalements WHERE pris_en_charge_par = p_user_id)
  );
END;
$$ LANGUAGE plpgsql STABLE;

-- ============================================================
-- ACTIVATION REALTIME
-- ============================================================

ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.signalements;
ALTER PUBLICATION supabase_realtime ADD TABLE public.maraudes;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.maraude_participants;