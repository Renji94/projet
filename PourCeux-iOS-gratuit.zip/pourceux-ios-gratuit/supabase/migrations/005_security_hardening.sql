-- ============================================================
-- POURCEUX - DURCISSEMENT SECURITE ET CONFIDENTIALITE
-- Migration 005 - à exécuter après 001 à 003. Elle est aussi
-- compatible avec une base existante ayant déjà exécuté l’ancien 004.
-- ============================================================

-- Réconcilie le compteur dénormalisé avant de poser l'invariant.
UPDATE public.maraudes m
SET current_participants = (
  SELECT count(*)::integer
  FROM public.maraude_participants mp
  WHERE mp.maraude_id = m.id
);
UPDATE public.maraudes
SET max_participants = current_participants
WHERE current_participants > max_participants;

ALTER TABLE public.maraudes
  DROP CONSTRAINT IF EXISTS participants_ne_depassent_pas_maximum;
ALTER TABLE public.maraudes
  ADD CONSTRAINT participants_ne_depassent_pas_maximum
  CHECK (current_participants <= max_participants) NOT VALID;
ALTER TABLE public.maraudes
  VALIDATE CONSTRAINT participants_ne_depassent_pas_maximum;

-- Les contraintes GPS sont appliquées aux nouvelles écritures sans rendre la
-- migration destructive si une ancienne ligne contient déjà une valeur invalide.
ALTER TABLE public.messages
  DROP CONSTRAINT IF EXISTS message_latitude_valide;
ALTER TABLE public.messages
  ADD CONSTRAINT message_latitude_valide
  CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90) NOT VALID;
ALTER TABLE public.messages
  DROP CONSTRAINT IF EXISTS message_longitude_valide;
ALTER TABLE public.messages
  ADD CONSTRAINT message_longitude_valide
  CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180) NOT VALID;

-- Les données privées du profil ne doivent pas être lisibles via SELECT *.
REVOKE SELECT, UPDATE ON public.profiles FROM authenticated;
GRANT SELECT (
  id, pseudo, prenom, nom, ville, avatar_url, created_at, updated_at
) ON public.profiles TO authenticated;

-- Les modifications de profil et d'administration passent par des RPC dédiées.
DROP POLICY IF EXISTS "profiles_update_own" ON public.profiles;
DROP POLICY IF EXISTS "profiles_update_admin" ON public.profiles;

-- Les comptes suspendus ne peuvent plus parcourir les données de l'application.
DROP POLICY IF EXISTS "profiles_select_authenticated" ON public.profiles;
CREATE POLICY "profiles_select_active"
  ON public.profiles FOR SELECT TO authenticated
  USING (public.is_not_suspended() OR id = auth.uid());

DROP POLICY IF EXISTS "maraudes_select_all" ON public.maraudes;
CREATE POLICY "maraudes_select_active"
  ON public.maraudes FOR SELECT TO authenticated
  USING (public.is_not_suspended());

DROP POLICY IF EXISTS "participants_select_all" ON public.maraude_participants;
CREATE POLICY "participants_select_active"
  ON public.maraude_participants FOR SELECT TO authenticated
  USING (public.is_not_suspended());

DROP POLICY IF EXISTS "signalements_select_all" ON public.signalements;
CREATE POLICY "signalements_select_active"
  ON public.signalements FOR SELECT TO authenticated
  USING (public.is_not_suspended());

-- Un créateur ne peut pas modifier directement le responsable ou le statut.
DROP POLICY IF EXISTS "signalements_update_owner_or_admin" ON public.signalements;
CREATE POLICY "signalements_update_admin"
  ON public.signalements FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "signalements_delete_owner_or_admin" ON public.signalements;
CREATE POLICY "signalements_delete_owner_or_admin_active"
  ON public.signalements FOR DELETE TO authenticated
  USING (public.is_not_suspended() AND (createur_id = auth.uid() OR public.is_admin()));

-- Helpers d'autorisation, sans récursion RLS.
CREATE OR REPLACE FUNCTION public.can_access_chat(p_chat_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT public.is_not_suspended() AND (
    public.is_admin()
    OR EXISTS (
      SELECT 1
      FROM public.chats c
      WHERE c.id = p_chat_id
        AND c.type = 'signalement'
    )
    OR EXISTS (
      SELECT 1
      FROM public.chats c
      JOIN public.maraudes m ON m.id = c.maraude_id
      WHERE c.id = p_chat_id
        AND c.type = 'maraude'
        AND (
          m.createur_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM public.maraude_participants mp
            WHERE mp.maraude_id = m.id AND mp.user_id = auth.uid()
          )
        )
    )
  );
$$;

DROP POLICY IF EXISTS "chats_select_all" ON public.chats;
CREATE POLICY "chats_select_authorized"
  ON public.chats FOR SELECT TO authenticated
  USING (public.can_access_chat(id));

DROP POLICY IF EXISTS "messages_select_authenticated" ON public.messages;
DROP POLICY IF EXISTS "messages_insert_authorized" ON public.messages;
CREATE POLICY "messages_select_authorized"
  ON public.messages FOR SELECT TO authenticated
  USING (public.can_access_chat(chat_id));
CREATE POLICY "messages_insert_authorized"
  ON public.messages FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND public.can_access_chat(chat_id)
  );

DROP POLICY IF EXISTS "reads_select_own" ON public.message_reads;
DROP POLICY IF EXISTS "reads_insert_own" ON public.message_reads;
DROP POLICY IF EXISTS "reads_update_own" ON public.message_reads;
CREATE POLICY "reads_select_own_authorized"
  ON public.message_reads FOR SELECT TO authenticated
  USING (user_id = auth.uid() AND public.can_access_chat(chat_id));
CREATE POLICY "reads_insert_own_authorized"
  ON public.message_reads FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND public.can_access_chat(chat_id));
CREATE POLICY "reads_update_own_authorized"
  ON public.message_reads FOR UPDATE TO authenticated
  USING (user_id = auth.uid() AND public.can_access_chat(chat_id))
  WITH CHECK (user_id = auth.uid() AND public.can_access_chat(chat_id));

-- Profil courant : lecture complète exclusivement pour le propriétaire.
CREATE OR REPLACE FUNCTION public.get_my_profile()
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_profile jsonb;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Authentification requise';
  END IF;

  SELECT to_jsonb(p) INTO v_profile
  FROM public.profiles p
  WHERE p.id = auth.uid();

  IF v_profile IS NULL THEN
    RAISE EXCEPTION 'Profil introuvable';
  END IF;

  RETURN v_profile;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_my_profile(
  p_pseudo text,
  p_prenom text,
  p_nom text,
  p_telephone text,
  p_ville text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_profile public.profiles;
BEGIN
  IF NOT public.is_not_suspended() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Compte suspendu.');
  END IF;

  UPDATE public.profiles
  SET pseudo = trim(p_pseudo),
      prenom = trim(p_prenom),
      nom = trim(p_nom),
      telephone = nullif(trim(p_telephone), ''),
      ville = trim(p_ville)
  WHERE id = auth.uid()
  RETURNING * INTO v_profile;

  RETURN jsonb_build_object('success', true, 'profile', to_jsonb(v_profile));
EXCEPTION WHEN unique_violation THEN
  RETURN jsonb_build_object('success', false, 'error', 'Ce pseudo est déjà utilisé.');
END;
$$;

CREATE OR REPLACE FUNCTION public.update_my_position(
  p_latitude double precision,
  p_longitude double precision
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF NOT public.is_not_suspended() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Compte suspendu.');
  END IF;
  IF p_latitude NOT BETWEEN -90 AND 90 OR p_longitude NOT BETWEEN -180 AND 180 THEN
    RETURN jsonb_build_object('success', false, 'error', 'Coordonnées invalides.');
  END IF;

  UPDATE public.profiles
  SET latitude = p_latitude, longitude = p_longitude
  WHERE id = auth.uid();

  RETURN jsonb_build_object('success', true);
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_list_users(p_search text DEFAULT NULL)
RETURNS TABLE (
  id uuid,
  pseudo text,
  prenom text,
  nom text,
  ville text,
  role public.user_role,
  is_suspended boolean,
  avatar_url text,
  created_at timestamptz
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'Non autorisé'; END IF;
  RETURN QUERY
  SELECT p.id, p.pseudo, p.prenom, p.nom, p.ville, p.role, p.is_suspended,
         p.avatar_url, p.created_at
  FROM public.profiles p
  WHERE p_search IS NULL
     OR p.pseudo ILIKE '%' || p_search || '%'
     OR p.prenom ILIKE '%' || p_search || '%'
     OR p.nom ILIKE '%' || p_search || '%'
  ORDER BY p.created_at DESC
  LIMIT 200;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_set_user_suspended(
  p_user_id uuid,
  p_suspended boolean
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Non autorisé.');
  END IF;
  IF p_user_id = auth.uid() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Vous ne pouvez pas suspendre votre propre compte.');
  END IF;
  UPDATE public.profiles SET is_suspended = p_suspended WHERE id = p_user_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('success', false, 'error', 'Utilisateur introuvable.'); END IF;
  RETURN jsonb_build_object('success', true);
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_set_user_role(
  p_user_id uuid,
  p_role public.user_role
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_current_role public.user_role;
  v_admin_count integer;
BEGIN
  IF NOT public.is_admin() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Non autorisé.');
  END IF;
  IF p_user_id = auth.uid() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Vous ne pouvez pas modifier votre propre rôle.');
  END IF;

  SELECT role INTO v_current_role FROM public.profiles WHERE id = p_user_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('success', false, 'error', 'Utilisateur introuvable.'); END IF;

  IF v_current_role = 'admin' AND p_role = 'user' THEN
    SELECT count(*) INTO v_admin_count
    FROM public.profiles WHERE role = 'admin' AND is_suspended = false;
    IF v_admin_count <= 1 THEN
      RETURN jsonb_build_object('success', false, 'error', 'Impossible de retirer le dernier administrateur actif.');
    END IF;
  END IF;

  UPDATE public.profiles SET role = p_role WHERE id = p_user_id;
  RETURN jsonb_build_object('success', true);
END;
$$;

-- Correction des deux RPC historiques qui autorisaient encore des actions
-- depuis un compte suspendu. IS DISTINCT FROM évite aussi qu'un responsable
-- NULL permette à n'importe quel utilisateur de clôturer un signalement ouvert.
CREATE OR REPLACE FUNCTION public.quitter_maraude(p_maraude_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF NOT public.is_not_suspended() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Compte suspendu.');
  END IF;

  DELETE FROM public.maraude_participants
  WHERE maraude_id = p_maraude_id AND user_id = auth.uid();

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Vous ne participez pas à cette maraude.');
  END IF;

  RETURN jsonb_build_object('success', true);
END;
$$;

CREATE OR REPLACE FUNCTION public.cloturer_signalement(
  p_signalement_id uuid,
  p_statut public.signalement_statut
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_sig public.signalements;
BEGIN
  IF NOT public.is_not_suspended() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Compte suspendu.');
  END IF;
  IF p_statut NOT IN ('resolu', 'toujours_present', 'introuvable', 'fausse_alerte') THEN
    RETURN jsonb_build_object('success', false, 'error', 'Statut invalide.');
  END IF;

  SELECT * INTO v_sig
  FROM public.signalements
  WHERE id = p_signalement_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Signalement introuvable.');
  END IF;

  IF v_sig.pris_en_charge_par IS DISTINCT FROM auth.uid()
     AND v_sig.createur_id IS DISTINCT FROM auth.uid()
     AND NOT public.is_admin() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Non autorisé.');
  END IF;

  IF p_statut = 'toujours_present' THEN
    UPDATE public.signalements
    SET statut = 'ouvert', pris_en_charge_par = NULL, pris_en_charge_at = NULL
    WHERE id = p_signalement_id;
  ELSE
    UPDATE public.signalements SET statut = p_statut WHERE id = p_signalement_id;
  END IF;

  IF v_sig.createur_id IS DISTINCT FROM auth.uid() THEN
    INSERT INTO public.notifications (user_id, type, titre, corps, data)
    VALUES (
      v_sig.createur_id,
      'signalement_statut',
      'Mise à jour du signalement',
      'Le signalement « ' || v_sig.titre || ' » est maintenant : ' || p_statut,
      jsonb_build_object('signalement_id', p_signalement_id, 'statut', p_statut)
    );
  END IF;

  RETURN jsonb_build_object('success', true);
END;
$$;

-- Profil créé sans faire échouer l'inscription en cas de pseudo déjà pris.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_pseudo text;
BEGIN
  v_pseudo := coalesce(nullif(trim(NEW.raw_user_meta_data->>'pseudo'), ''), 'user_' || substr(NEW.id::text, 1, 8));
  IF EXISTS (SELECT 1 FROM public.profiles p WHERE lower(p.pseudo) = lower(v_pseudo)) THEN
    v_pseudo := left(v_pseudo, 21) || '_' || substr(NEW.id::text, 1, 8);
  END IF;

  INSERT INTO public.profiles (id, pseudo, prenom, nom, telephone, ville)
  VALUES (
    NEW.id,
    v_pseudo,
    coalesce(nullif(trim(NEW.raw_user_meta_data->>'prenom'), ''), 'Prénom'),
    coalesce(nullif(trim(NEW.raw_user_meta_data->>'nom'), ''), 'Nom'),
    nullif(trim(NEW.raw_user_meta_data->>'telephone'), ''),
    coalesce(nullif(trim(NEW.raw_user_meta_data->>'ville'), ''), 'Non renseignée')
  );
  RETURN NEW;
END;
$$;

-- Carte : bornes strictes, utilisateur actif et données minimales.
CREATE OR REPLACE FUNCTION public.get_evenements_proches(
  p_lat double precision,
  p_lon double precision,
  p_rayon_km double precision DEFAULT 50
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_maraudes jsonb;
  v_signalements jsonb;
BEGIN
  IF NOT public.is_not_suspended() THEN RAISE EXCEPTION 'Non autorisé'; END IF;
  IF p_lat NOT BETWEEN -90 AND 90 OR p_lon NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'Coordonnées invalides';
  END IF;
  IF p_rayon_km < 1 OR p_rayon_km > 100 THEN RAISE EXCEPTION 'Rayon invalide'; END IF;

  SELECT coalesce(jsonb_agg(to_jsonb(m)), '[]'::jsonb) INTO v_maraudes
  FROM (
    SELECT ma.id, ma.titre, ma.date_maraude, ma.heure_debut, ma.ville, ma.adresse,
           ma.latitude, ma.longitude, ma.statut, ma.max_participants,
           ma.current_participants,
           public.haversine_km(p_lat, p_lon, ma.latitude, ma.longitude) AS distance_km
    FROM public.maraudes ma
    WHERE ma.statut IN ('programmee', 'en_cours')
      AND public.haversine_km(p_lat, p_lon, ma.latitude, ma.longitude) <= p_rayon_km
    ORDER BY distance_km
    LIMIT 500
  ) m;

  SELECT coalesce(jsonb_agg(to_jsonb(s)), '[]'::jsonb) INTO v_signalements
  FROM (
    SELECT si.id, si.titre, si.urgence, si.adresse, si.latitude, si.longitude,
           si.statut, si.created_at,
           public.haversine_km(p_lat, p_lon, si.latitude, si.longitude) AS distance_km
    FROM public.signalements si
    WHERE si.statut IN ('ouvert', 'pris_en_charge')
      AND public.haversine_km(p_lat, p_lon, si.latitude, si.longitude) <= p_rayon_km
    ORDER BY distance_km
    LIMIT 500
  ) s;

  RETURN jsonb_build_object('maraudes', v_maraudes, 'signalements', v_signalements);
END;
$$;

CREATE OR REPLACE FUNCTION public.get_profile_stats(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF p_user_id <> auth.uid() AND NOT public.is_admin() THEN RAISE EXCEPTION 'Non autorisé'; END IF;
  RETURN jsonb_build_object(
    'nb_maraudes', (SELECT count(*) FROM public.maraude_participants WHERE user_id = p_user_id),
    'nb_signalements', (SELECT count(*) FROM public.signalements WHERE createur_id = p_user_id),
    'nb_prises_en_charge', (SELECT count(*) FROM public.signalements WHERE pris_en_charge_par = p_user_id)
  );
END;
$$;

-- Verrouillage du search_path des anciennes fonctions SECURITY DEFINER.
ALTER FUNCTION public.is_admin() SET search_path = '';
ALTER FUNCTION public.is_not_suspended() SET search_path = '';
ALTER FUNCTION public.create_maraude_chat() SET search_path = '';
ALTER FUNCTION public.handle_new_signalement() SET search_path = '';
ALTER FUNCTION public.update_participants_count() SET search_path = '';
ALTER FUNCTION public.rejoindre_maraude(uuid) SET search_path = '';
ALTER FUNCTION public.quitter_maraude(uuid) SET search_path = '';
ALTER FUNCTION public.prendre_en_charge_signalement(uuid) SET search_path = '';
ALTER FUNCTION public.cloturer_signalement(uuid, public.signalement_statut) SET search_path = '';

-- Les fonctions ne sont plus exécutables par défaut.
REVOKE EXECUTE ON ALL FUNCTIONS IN SCHEMA public FROM PUBLIC, anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_not_suspended() TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_access_chat(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_my_profile() TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_my_profile(text, text, text, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_my_position(double precision, double precision) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_list_users(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_set_user_suspended(uuid, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_set_user_role(uuid, public.user_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rejoindre_maraude(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.quitter_maraude(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.prendre_en_charge_signalement(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.cloturer_signalement(uuid, public.signalement_statut) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_evenements_proches(double precision, double precision, double precision) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_profile_stats(uuid) TO authenticated;
