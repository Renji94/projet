-- ============================================================
-- POURCEUX - ROW LEVEL SECURITY
-- Migration 003
-- ============================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.maraudes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.maraude_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.signalements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_reads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- PROFILES
-- ============================================================

CREATE POLICY "profiles_select_authenticated"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_update_own"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (
    id = auth.uid()
    AND role = (SELECT role FROM public.profiles WHERE id = auth.uid())
    AND is_suspended = (SELECT is_suspended FROM public.profiles WHERE id = auth.uid())
  );

CREATE POLICY "profiles_update_admin"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- ============================================================
-- MARAUDES
-- ============================================================

CREATE POLICY "maraudes_select_all"
  ON public.maraudes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "maraudes_insert_admin"
  ON public.maraudes FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin() AND createur_id = auth.uid());

CREATE POLICY "maraudes_update_admin"
  ON public.maraudes FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "maraudes_delete_admin"
  ON public.maraudes FOR DELETE
  TO authenticated
  USING (public.is_admin());

-- ============================================================
-- MARAUDE_PARTICIPANTS
-- (insertion/suppression via RPC SECURITY DEFINER uniquement,
--  mais on autorise la lecture)
-- ============================================================

CREATE POLICY "participants_select_all"
  ON public.maraude_participants FOR SELECT
  TO authenticated
  USING (true);

-- ============================================================
-- SIGNALEMENTS
-- ============================================================

CREATE POLICY "signalements_select_all"
  ON public.signalements FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "signalements_insert_user"
  ON public.signalements FOR INSERT
  TO authenticated
  WITH CHECK (createur_id = auth.uid() AND public.is_not_suspended());

CREATE POLICY "signalements_update_owner_or_admin"
  ON public.signalements FOR UPDATE
  TO authenticated
  USING (createur_id = auth.uid() OR public.is_admin())
  WITH CHECK (createur_id = auth.uid() OR public.is_admin());

CREATE POLICY "signalements_delete_owner_or_admin"
  ON public.signalements FOR DELETE
  TO authenticated
  USING (createur_id = auth.uid() OR public.is_admin());

-- ============================================================
-- CHATS
-- ============================================================

CREATE POLICY "chats_select_all"
  ON public.chats FOR SELECT
  TO authenticated
  USING (true);

-- ============================================================
-- MESSAGES
-- Lecture : tout utilisateur authentifié non suspendu.
-- Écriture chat maraude : participants + créateur + admin.
-- Écriture chat signalement : tout utilisateur non suspendu.
-- ============================================================

CREATE POLICY "messages_select_authenticated"
  ON public.messages FOR SELECT
  TO authenticated
  USING (public.is_not_suspended());

CREATE POLICY "messages_insert_authorized"
  ON public.messages FOR INSERT
  TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND public.is_not_suspended()
    AND (
      public.is_admin()
      OR EXISTS (
        SELECT 1 FROM public.chats c
        WHERE c.id = chat_id AND c.type = 'signalement'
      )
      OR EXISTS (
        SELECT 1
        FROM public.chats c
        JOIN public.maraudes m ON m.id = c.maraude_id
        LEFT JOIN public.maraude_participants mp
          ON mp.maraude_id = m.id AND mp.user_id = auth.uid()
        WHERE c.id = chat_id
          AND c.type = 'maraude'
          AND (mp.id IS NOT NULL OR m.createur_id = auth.uid())
      )
    )
  );

CREATE POLICY "messages_delete_admin"
  ON public.messages FOR DELETE
  TO authenticated
  USING (public.is_admin());

-- ============================================================
-- MESSAGE_READS
-- ============================================================

CREATE POLICY "reads_select_own"
  ON public.message_reads FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "reads_insert_own"
  ON public.message_reads FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "reads_update_own"
  ON public.message_reads FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- ============================================================
-- NOTIFICATIONS
-- ============================================================

CREATE POLICY "notifications_select_own"
  ON public.notifications FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "notifications_update_own"
  ON public.notifications FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "notifications_delete_own"
  ON public.notifications FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());