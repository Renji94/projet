# Créer l’IPA gratuitement, sans Mac

Ce projet contient un workflow GitHub Actions qui compile **PourCeux pour un
iPhone physique** sur un Mac distant. Le résultat est
`PourCeux-unsigned.ipa`. L’IPA est volontairement non signée afin de ne pas
nécessiter d’abonnement Apple Developer pendant la compilation.

## 1. Mettre le projet sur GitHub

1. Crée un dépôt GitHub vide, public ou privé.
2. Décompresse ce ZIP puis envoie **le contenu du dossier** dans le dépôt.
3. Ne publie jamais ton ancien fichier `.env`. Il a été retiré de cette copie.

Un dépôt public utilise gratuitement les runners GitHub standards. Un dépôt
privé utilise le quota GitHub Actions inclus dans ton compte.

## 2. Ajouter les trois secrets

Dans le dépôt, ouvre :

`Settings > Secrets and variables > Actions > New repository secret`

Ajoute exactement ces trois secrets à partir de ton fichier `.env` original :

- `EXPO_PUBLIC_SUPABASE_URL`
- `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
- `EXPO_PUBLIC_APP_CONTACT_EMAIL`

Ces valeurs sont injectées uniquement pendant la compilation. Ne les recopie
pas directement dans le workflow.

## 3. Lancer la compilation

1. Ouvre l’onglet `Actions` du dépôt.
2. Choisis **Créer IPA iPhone gratuite**.
3. Clique sur `Run workflow`, puis encore sur `Run workflow`.
4. Attends la fin du job **Compiler PourCeux pour iPhone**.
5. Dans la page du job terminé, télécharge l’artefact `PourCeux-IPA`.
6. Décompresse l’artefact pour obtenir `PourCeux-unsigned.ipa`.

Le workflow vérifie automatiquement que le résultat cible `iPhoneOS` et
l’architecture `arm64`. Cela empêche de reproduire le précédent fichier
`iPhoneSimulator`.

## 4. Installer l’IPA depuis Windows

Installe AltStore Classic/AltServer sur Windows, branche l’iPhone, puis ajoute
`PourCeux-unsigned.ipa` depuis l’onglet **My Apps**. AltStore signe l’application
avec ton identifiant Apple gratuit.

Avec un compte Apple gratuit :

- l’application doit être renouvelée au maximum tous les sept jours ;
- Apple limite le nombre d’applications installées de cette manière ;
- les notifications push distantes ne sont normalement pas disponibles, car
  le profil Apple gratuit ne fournit pas l’autorisation APNs ;
- cette IPA ne peut pas être publiée sur l’App Store ou TestFlight.

La carte, Supabase, l’authentification, la géolocalisation et les fonctions
principales restent compilées dans l’application.

## Dépannage rapide

- **Secret GitHub manquant** : vérifie le nom exact des trois secrets.
- **npm ci échoue** : relance une fois le workflow ; une panne temporaire du
  registre npm peut interrompre le téléchargement des dépendances.
- **AltStore refuse l’installation** : active le mode développeur sur l’iPhone,
  redémarre-le si iOS le demande, puis renouvelle AltStore et l’application.
- **L’application expire** : ouvre AltStore et utilise `Refresh All` avant la
  fin des sept jours.
