import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { TransformRequestManager } from '@maplibre/maplibre-react-native';
import { AppProviders } from './src/providers/AppProviders';
import { RootNavigator } from './src/navigation/RootNavigator';
import { CONFIG } from './src/constants/config';

// Les tuiles OpenStreetMap appliquent leur propre politique d'usage et
// peuvent limiter silencieusement les clients sans en-tête d'identification
// (même exigence que Nominatim, déjà traitée via CONFIG.NOMINATIM_USER_AGENT).
TransformRequestManager.addHeader({
  id: 'osm-tiles-user-agent',
  match: /tile\.openstreetmap\.org/,
  name: 'User-Agent',
  value: `PourCeux/1.0 (${CONFIG.APP_CONTACT_EMAIL})`,
});

export default function App() {
  return (
    <AppProviders>
      <StatusBar style="light" />
      <RootNavigator />
    </AppProviders>
  );
}