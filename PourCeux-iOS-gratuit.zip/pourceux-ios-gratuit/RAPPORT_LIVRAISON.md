# Rapport de livraison — PourCeux

## Livrable

Cette archive contient le projet React Native / Expo / Supabase renommé **PourCeux**, sans `node_modules`, sans dépôt `.git`, sans cache `.expo` et sans fichier `.env` réel. L'installation doit être refaite avec `npm install` à partir du `package-lock.json` fourni.

## Modifications de marque

- nom Expo : `PourCeux` ;
- slug et schéma de deep link : `pourceux` ;
- package Android et bundle identifier iOS : `com.pourceux.app` ;
- redirection d'authentification : `pourceux://auth/callback` ;
- textes visibles et User-Agent Nominatim harmonisés ;
- palette bleu nuit / vert menthe appliquée ;
- logo, marque seule, icône, adaptive icon, favicon, icône de notification et splash générés à partir des visuels fournis ;
- logo intégré à l'écran de connexion et à l'écran de chargement applicatif.

## Correctifs techniques de cette livraison

- valeurs réelles supprimées de `.env.example` ;
- `projectId` EAS rendu strictement dépendant de `EXPO_PUBLIC_EAS_PROJECT_ID` ;
- suppression de `tsconfig.json` et conversion de l'Edge Function Supabase en JavaScript (`index.js`) ;
- bootstrap de `react-native-gesture-handler` séparé entre natif et Web ;
- rendu des icônes React Native Paper explicitement relié à `@expo/vector-icons` ;
- ajout d'un paquet npm local de compatibilité pour l'import statique de React Native Paper, sans ajout d'un faux Expo Config Plugin ;
- section `expo.plugins` limitée à `expo-location` et `expo-notifications`.

## Revalidation effectuée

- `npm install --ignore-scripts` : réussi ;
- `npm ls --depth=0` : arbre direct cohérent ;
- ESLint : réussi sans avertissement ;
- parsing Babel : 68 fichiers JavaScript valides ;
- résolution statique : 240 imports et ressources relatifs contrôlés ;
- `expo config --type public` : configuration résolue correctement ;
- `expo install --check` : dépendances indiquées à jour avec la table locale Expo ;
- `expo start --offline --clear` : Metro démarre et attend sur `http://localhost:8081` ;
- recherche de secrets connus et d'ancien branding : aucune occurrence restante hors vocabulaire métier « maraude » ;
- aucun fichier TypeScript ou `tsconfig.json` dans le livrable ;
- `npm audit --omit=dev --audit-level=high` : aucune vulnérabilité haute ou critique ; 11 alertes modérées transitives liées à l'outillage Expo restent signalées.

## Limites de l'environnement de validation

`expo-doctor` a validé 19 contrôles sur 21. Les deux contrôles restants nécessitaient l'accès aux services Expo / React Native Directory et ont échoué sur une erreur réseau DNS, pas sur une erreur de projet.

L'export Web a démarré Metro mais n'a pas terminé dans la fenêtre d'exécution disponible. Aucun message d'erreur de résolution de module n'a été remonté avant l'expiration. Les builds EAS signés, les credentials FCM/APNs et l'exécution des migrations sur un projet Supabase réel restent à valider dans votre environnement connecté.
