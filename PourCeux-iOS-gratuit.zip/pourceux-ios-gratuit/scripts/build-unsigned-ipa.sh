#!/usr/bin/env bash
set -Eeuo pipefail

root_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root_dir"

required_variables=(
  EXPO_PUBLIC_SUPABASE_URL
  EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY
  EXPO_PUBLIC_APP_CONTACT_EMAIL
)

for variable in "${required_variables[@]}"; do
  if [[ -z "${!variable:-}" ]]; then
    echo "Variable requise absente : ${variable}" >&2
    exit 1
  fi
done

for command in node npm npx pod xcodebuild ditto zip; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "Commande requise introuvable : ${command}" >&2
    exit 1
  fi
done

echo "Installation des dependances JavaScript"
npm ci

echo "Verification de la configuration Expo"
npx expo-doctor

echo "Generation du projet iOS natif"
npx expo prebuild --platform ios --no-install

echo "Installation des dependances CocoaPods"
(
  cd ios
  pod install --repo-update
)

workspace="$(find ios -maxdepth 1 -type d -name '*.xcworkspace' -print -quit)"
if [[ -z "$workspace" ]]; then
  echo "Aucun workspace Xcode genere dans ios/." >&2
  exit 1
fi

scheme="${IOS_SCHEME:-$(basename "$workspace" .xcworkspace)}"
derived_data="$root_dir/ios/build/DerivedData"

echo "Compilation iPhoneOS non signee du scheme ${scheme}"
xcodebuild \
  -workspace "$workspace" \
  -scheme "$scheme" \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$derived_data" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  DEVELOPMENT_TEAM="" \
  COMPILER_INDEX_STORE_ENABLE=NO \
  build

products_dir="$derived_data/Build/Products/Release-iphoneos"
app_path="$(find "$products_dir" -maxdepth 1 -type d -name '*.app' -print -quit)"
if [[ -z "$app_path" ]]; then
  echo "Application .app iPhone introuvable apres compilation." >&2
  exit 1
fi

platform="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleSupportedPlatforms:0' "$app_path/Info.plist")"
if [[ "$platform" != "iPhoneOS" ]]; then
  echo "Plateforme incorrecte : ${platform}. Le build doit cibler iPhoneOS." >&2
  exit 1
fi

executable="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$app_path/Info.plist")"
if ! lipo -info "$app_path/$executable" | grep -q 'arm64'; then
  echo "Le binaire produit ne contient pas l'architecture arm64 pour iPhone." >&2
  exit 1
fi

artifact_dir="$root_dir/artifacts"
ipa_path="$artifact_dir/PourCeux-unsigned.ipa"
checksum_path="$ipa_path.sha256"
temporary_dir="$(mktemp -d "$root_dir/.ipa-build.XXXXXX")"
trap 'rm -rf "$temporary_dir"' EXIT

mkdir -p "$artifact_dir" "$temporary_dir/Payload"
rm -f "$ipa_path" "$checksum_path"
ditto "$app_path" "$temporary_dir/Payload/$(basename "$app_path")"

(
  cd "$temporary_dir"
  zip -qry "$ipa_path" Payload
)

(
  cd "$artifact_dir"
  shasum -a 256 "$(basename "$ipa_path")" > "$(basename "$checksum_path")"
)

echo "IPA iPhone creee : $ipa_path"
echo "Elle est non signee et doit etre installee avec AltStore/Sideloadly."
